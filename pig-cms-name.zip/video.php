<?php
/* 
 * 🐷 PIG-CMS 
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

// www/video.php
require_once __DIR__ . '/core/config.php';

// 🔥 ВЫТАСКИВАЕМ СУВЕРЕННЫЙ БРЕНД ИЗ МАТРИЦЫ НАСТРОЕК
$site_brand = htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS');

// Автоматически создаем папку для хранения видео-постов, если её нет
$DIR_VIDEO_POSTS = __DIR__ . '/data/video_posts/';
if (!is_dir($DIR_VIDEO_POSTS)) mkdir($DIR_VIDEO_POSTS, 0755, true);

$view_single = isset($_GET['view']) ? trim($_GET['view']) : '';
// Заменили жесткий дефолтный заголовок
$page_title = "Видеоинструкции и Блоги — " . $site_brand; 
$posts_data = [];

// Сбор видео-материалов
$files = glob($DIR_VIDEO_POSTS . "*.json");
if (!empty($files)) {
    array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
    foreach ($files as $file) {
        $basename = basename($file, '.json'); 
        if (!empty($view_single) && $basename !== $view_single) continue;
        $p = json_decode(file_get_contents($file), true);
        if ($p) { $p['id'] = $basename; $posts_data[] = $p; }
    }
}

if (!empty($view_single) && !empty($posts_data)) {
    $post = $posts_data[0]; 
    // Заменили жесткий хвост одиночного просмотра видео
    $page_title = htmlspecialchars($post['title']) . " — Видео-Хаб " . $site_brand;
    $meta_description = mb_substr(strip_tags($post['description']), 0, 160, 'UTF-8') . "...";
} else { 
    $meta_description = "Смотреть творческие блоги, видеоклипы и полезные инструкции от авторов сообщества."; 
}

$hub_title = "📹 Видео-Хаб";
$hub_subtitle = "Пространство видеоинструкций, блогов и клипов нашего коллектива";

include_once __DIR__ . '/core/header.php';

?>

<?php if (!empty($view_single) && !empty($posts_data)): ?>
    <div style="text-align:center; margin-bottom:20px;">
        <a href="video.php" style="color:#007bff; font-weight:bold; text-decoration:none;">← Назад к списку видео</a>
    </div>
    
    <div class="single-post-wrap">
        <!-- Адаптивный контейнер для видео-плеера (YouTube, VK или iframe) -->
        <div class="video-container" style="position:relative; padding-bottom:56.25%; height:0; overflow:hidden; border-radius:8px; background:#000; margin-bottom:20px; border:1px solid #333;">
            <?php 
            $v_url = htmlspecialchars($post['video_url']);
            if (strpos($v_url, 'youtube.com') !== false || strpos($v_url, 'youtu.be') !== false) {
                // Преобразуем обычную ссылку YouTube во встраиваемую embed-ссылку
                $embed_url = str_replace(['watch?v=', 'youtu.be/'], ['embed/', '://youtube.com'], $v_url);
                echo '<iframe src="'.$embed_url.'" style="position:absolute; top:0; left:0; width:100%; height:100%;" frameborder="0" allowfullscreen></iframe>';
            } else {
                // Резервный вариант для других плееров или прямых iframe-кодов
                echo '<iframe src="'.$v_url.'" style="position:absolute; top:0; left:0; width:100%; height:100%;" frameborder="0" allowfullscreen></iframe>';
            }
            ?>
        </div>

        <div class="single-post-title"><?php echo htmlspecialchars($post['title']); ?></div>
        <div class="single-post-meta" style="font-size:12px; color:#666; margin-bottom:15px;">
            Автор: <b>@<?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></b> | 📅 Опубликовано: <?php echo date('d.m.Y H:i', $post['date']); ?>
        </div>
        <div class="single-post-desc" style="white-space: pre-wrap; color:#ccc; line-height:1.6; font-size:15px;"><?php echo nl2br(htmlspecialchars($post['description'])); ?></div>
    </div>

<?php else: ?>
    <h2>Все видеоинструкции и клипы:</h2>
    <div class="grid-container">
        <?php if (!empty($posts_data)): foreach ($posts_data as $v): ?>
            <div class="card">
                <a href="video.php?view=<?php echo $v['id']; ?>" class="card-link" style="position:relative; display:block; background:#000;">
                    <!-- Заглушка обложки видео с иконкой плей -->
                    <div style="width:100%; height:160px; background:#222; display:flex; align-items:center; justify-content:center; color:#ffc107; font-size:40px;">▶️</div>
                    <span class="card-title"><?php echo htmlspecialchars($v['title']); ?></span>
                </a>
                <div style="padding:0 12px 10px 12px; font-size:11px; color:#666;">Автор: @<?php echo htmlspecialchars($v['author'] ?? 'Admin'); ?></div>
                <div class="card-desc" style="padding-top:0; font-size:13px; color:#aaa;">
                    <?php echo mb_strimwidth(strip_tags($v['description']), 0, 90, "..."); ?>
                </div>
            </div>
        <?php endforeach; else: ?>
            <p style="grid-column: 1/-1; text-align:center; color:#555; padding:30px 0;">Видео-публикаций в хабе пока нет.</p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php 
include_once __DIR__ . '/core/footer.php'; 
?>
