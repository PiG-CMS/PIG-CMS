<?php
/*
 * 📬 PIG-MAIL — Децентрализованная Межсайтовая P2P-Почта
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

require_once __DIR__ . '/core/config.php';
require_once __DIR__ . '/core/pig_net.php';

$MAIL_FILE  = __DIR__ . '/data/mail_box.json';
$CACHE_FILE = __DIR__ . '/data/galaxy_mail_cache.json';

$is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
            || ($_SERVER['SERVER_PORT'] ?? 80) == 443 
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$my_host = strtolower(preg_replace('/^www\./i', '', $_SERVER['HTTP_HOST'] ?? 'localhost'));
$my_url  = ($is_https ? "https" : "http") . "://" . $my_host;

$my_title = !empty($APP_SETTINGS['site_title']) ? $APP_SETTINGS['site_title'] : $my_host;

// =========================================================================
// 🛸 1. P2P-ПРИЕМНИК ВХОДЯЩИХ ПИСЕМ (С АТОМАРНОЙ БЛОКИРОВКОЙ FLOCK)
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] === 'receive') {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');

    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input || empty($input['from_url']) || empty($input['text'])) {
        echo json_encode(['status' => 'error', 'message' => 'Пустой пакет данных.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $from_url   = filter_var(trim($input['from_url']), FILTER_SANITIZE_URL);
    $from_title = htmlspecialchars(strip_tags(trim($input['from_title'] ?? $from_url)), ENT_QUOTES, 'UTF-8');
    $subject    = htmlspecialchars(strip_tags(trim($input['subject'] ?? 'Без темы')), ENT_QUOTES, 'UTF-8');
    $text       = htmlspecialchars(strip_tags(trim($input['text'])), ENT_QUOTES, 'UTF-8');

    if (mb_strlen($text) > 3000) {
        echo json_encode(['status' => 'error', 'message' => 'Письмо слишком длинное (макс. 3000 символов).'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $spam_blocked = false;
    $saved = pig_json_update($MAIL_FILE, function($mailbox) use ($from_url, $from_title, $my_url, $subject, $text, &$spam_blocked) {
        $recent_count = 0;
        foreach ($mailbox as $m) {
            if (($m['type'] ?? '') === 'in' && ($m['from_url'] ?? '') === $from_url && (time() - ($m['time'] ?? 0)) < 3600) {
                $recent_count++;
            }
        }
        if ($recent_count >= 5) {
            $spam_blocked = true;
            return null;
        }

        array_unshift($mailbox, [
            'id'         => uniqid('msg_'),
            'type'       => 'in',
            'from_url'   => $from_url,
            'from_title' => $from_title,
            'to_url'     => $my_url,
            'subject'    => $subject,
            'text'       => $text,
            'time'       => time(),
            'date'       => date('d.m.Y H:i'),
            'read'       => false
        ]);

        return array_slice($mailbox, 0, 100);
    }, []);

    if ($spam_blocked) {
        echo json_encode(['status' => 'error', 'message' => 'Превышен лимит: макс. 5 писем в час на одну планету.'], JSON_UNESCAPED_UNICODE);
    } elseif ($saved !== false) {
        echo json_encode(['status' => 'success', 'message' => 'Письмо доставлено в бортовой журнал получателя!'], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Ошибка записи в бортовой журнал получателя.'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// =========================================================================
// 🔒 2. ИНТЕРФЕЙС АДМИНИСТРАТОРА (Только для авторизованного админа)
// =========================================================================
if (empty($_SESSION['auth']) || ($_SESSION['username'] ?? '') !== 'admin') {
    header('Location: admin/index.php');
    exit;
}

$alert = '';

function getPlanetsList($cache_file, $my_url) {
    $local_hub_map = __DIR__ . '/data/galaxy_map.json';
    if (file_exists($local_hub_map)) {
        $planets = json_decode(file_get_contents($local_hub_map), true) ?: [];
    } else {
        if (file_exists($cache_file) && (time() - filemtime($cache_file)) < 21600) {
            $planets = json_decode(file_get_contents($cache_file), true) ?: [];
        } else {
            $planets = [];
            $res = pig_curl_request(PIG_HUB . '/core/pig_net.php?action=get_galaxy', null, 4);
            $decoded = $res['body'] ? json_decode($res['body'], true) : null;
            if (is_array($decoded)) {
                $planets = $decoded;
                @file_put_contents($cache_file, json_encode($planets, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
            }
            if (empty($planets) && file_exists($cache_file)) {
                $planets = json_decode(file_get_contents($cache_file), true) ?: [];
            }
        }
    }
    return $planets;
}

if (isset($_GET['refresh_planets']) && file_exists($CACHE_FILE) && (time() - filemtime($CACHE_FILE)) > 300) {
    @unlink($CACHE_FILE);
    header('Location: mail.php');
    exit;
}

if (isset($_GET['del'])) {
    $del_id = $_GET['del'];
    pig_json_update($MAIL_FILE, function($mailbox) use ($del_id) {
        return array_values(array_filter($mailbox, fn($m) => ($m['id'] ?? '') !== $del_id));
    }, []);
    header('Location: mail.php');
    exit;
}

$mailbox = pig_json_update($MAIL_FILE, function($box) {
    $has_unread = false;
    foreach ($box as &$m) {
        if (($m['type'] ?? '') === 'in' && empty($m['read'])) {
            $m['read'] = true;
            $has_unread = true;
        }
    }
    unset($m);
    return $has_unread ? $box : null;
}, []);

if ($mailbox === false) {
    $mailbox = file_exists($MAIL_FILE) ? (json_decode(file_get_contents($MAIL_FILE), true) ?: []) : [];
}

if (isset($_POST['send_mail'])) {
    $target_url = rtrim(trim($_POST['target_url'] ?? ''), '/');
    if (empty($target_url) && !empty($_POST['custom_url'])) {
        $target_url = rtrim(trim($_POST['custom_url']), '/');
    }
    if (!preg_match('#^https?://#i', $target_url)) {
        $target_url = 'https://' . $target_url;
    }

    $subject = trim($_POST['subject'] ?? 'Привет из Квадранта!');
    $text    = trim($_POST['text'] ?? '');

    if (empty($target_url) || empty($text)) {
        $alert = "<div style='color:#ff6b6b; margin-bottom:15px;'>❌ Укажи адрес планеты и текст сообщения!</div>";
    } elseif (!function_exists('curl_init')) {
        $alert = "<div style='color:#ff6b6b; margin-bottom:15px;'>❌ На твоем хостинге отключен cURL.</div>";
    } else {
        $payload = json_encode([
            'from_url'   => $my_url,
            'from_title' => $my_title,
            'subject'    => $subject,
            'text'       => $text
        ], JSON_UNESCAPED_UNICODE);

        $res = pig_curl_request($target_url . '/mail.php?action=receive', $payload, 6);
        $http_code = $res['code'];
        $res_data = $res['body'] ? json_decode($res['body'], true) : null;

        if ($http_code === 200 && ($res_data['status'] ?? '') === 'success') {
            $new_box = pig_json_update($MAIL_FILE, function($box) use ($my_url, $my_title, $target_url, $subject, $text) {
                array_unshift($box, [
                    'id'         => uniqid('out_'),
                    'type'       => 'out',
                    'from_url'   => $my_url,
                    'from_title' => $my_title,
                    'to_url'     => $target_url,
                    'subject'    => htmlspecialchars($subject, ENT_QUOTES, 'UTF-8'),
                    'text'       => htmlspecialchars($text, ENT_QUOTES, 'UTF-8'),
                    'time'       => time(),
                    'date'       => date('d.m.Y H:i'),
                    'read'       => true
                ]);
                return array_slice($box, 0, 100);
            }, []);

            if ($new_box !== false) $mailbox = $new_box;
            $alert = "<div style='color:#28a745; margin-bottom:15px;'>✅ " . htmlspecialchars($res_data['message']) . "</div>";
        } else {
            $err = $res_data['message'] ?? "Планета не отвечает или там ещё не установлен модуль mail.php (HTTP $http_code).";
            $alert = "<div style='color:#ff6b6b; margin-bottom:15px;'>⚠️ Ошибка доставки: " . htmlspecialchars($err) . "</div>";
        }
    }
}

$planets = getPlanetsList($CACHE_FILE, $my_url);
$reply_to = htmlspecialchars($_GET['reply'] ?? '', ENT_QUOTES, 'UTF-8');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📬 Галактическая Почта — PIG-CMS</title>
    <link rel="stylesheet" href="assets/css/admin.css">
    <style>
        .mail-wrap { max-width: 800px; margin: 20px auto; background: #1e1e1e; padding: 20px; border-radius: 8px; border: 1px solid #444; color: #fff; font-family: monospace; }
        .mail-box { background: #2a2a2a; border: 1px solid #444; padding: 15px; border-radius: 6px; margin-bottom: 15px; }
        .mail-in { border-left: 4px solid #28a745; }
        .mail-out { border-left: 4px solid #007bff; opacity: 0.85; }
        .mail-meta { font-size: 12px; color: #aaa; margin-bottom: 8px; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 10px; }
        .mail-subj { font-size: 15px; color: #ffb703; font-weight: bold; margin-bottom: 8px; }
        .mail-text { font-size: 14px; line-height: 1.5; white-space: pre-wrap; color: #eee; background: #222; padding: 10px; border-radius: 4px; }
        .mail-actions { margin-top: 10px; display: flex; gap: 15px; font-size: 12px; }
        .mail-actions a { text-decoration: none; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 10px; margin-bottom: 12px; background: #2d2d2d; color: #fff; border: 1px solid #555; border-radius: 4px; font-family: monospace; box-sizing: border-box; }
        button { background: #ffb703; color: #111; border: none; padding: 12px 20px; font-weight: bold; border-radius: 4px; cursor: pointer; width: 100%; text-transform: uppercase; }
        button:hover { background: #e0a800; }
    </style>
</head>
<body>
<div class="mail-wrap">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; border-bottom:1px dashed #444; padding-bottom:10px;">
        <h2 style="margin:0; color:#ffb703;">📬 Галактическая P2P-Почта</h2>
        <a href="admin/index.php" style="color:#aaa; text-decoration:none;">⬅️ В админку</a>
    </div>

    <?php echo $alert; ?>

    <form method="POST" style="background:#252525; padding:15px; border-radius:6px; border:1px solid #333; margin-bottom:25px;">
        <h3 style="margin-top:0; color:#00b4d8; font-size:14px;">🚀 Отправить радиограмму напрямую на другой сайт</h3>
        
        <label style="font-size:12px; color:#ccc;">Выбери планету из сети PIG-NET (<a href="?refresh_planets=1" style="color:#ffb703;">обновить список</a>):</label>
        <select name="target_url">
            <option value="">-- Выбрать из списка Квадранта --</option>
            <?php foreach ($planets as $p): 
                $p_url = $p['url'] ?? '';
                if (empty($p_url) || $p_url === $my_url) continue;
                $selected = ($reply_to === $p_url) ? 'selected' : '';
            ?>
                <option value="<?php echo htmlspecialchars($p_url); ?>" <?php echo $selected; ?>>
                    🪐 <?php echo htmlspecialchars($p['title'] ?? $p_url); ?> (<?php echo htmlspecialchars($p_url); ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <input type="text" name="custom_url" value="<?php echo $reply_to; ?>" placeholder="Или введи адрес вручную (например: https://sosed-site.ru)">
        <input type="text" name="subject" placeholder="Тема сообщения (например: Привет с соседней планеты!)" required>
        <textarea name="text" rows="4" placeholder="Текст письма (отправляется напрямую P2P без нагрузки на Главный Хаб)..." required></textarea>
        <button type="submit" name="send_mail">📡 Отправить P2P-письмо</button>
    </form>

    <h3 style="color:#ccc; font-size:14px; margin-bottom:15px;">📥 Бортовой журнал сообщений (<?php echo count($mailbox); ?>)</h3>
    
    <?php if (empty($mailbox)): ?>
        <p style="color:#777; text-align:center; padding:20px;">Почтовый ящик пуст. Отправь первое письмо соседям по Квадранту!</p>
    <?php else: ?>
        <?php foreach ($mailbox as $msg): 
            $is_in = ($msg['type'] ?? 'in') === 'in';
        ?>
            <div class="mail-box <?php echo $is_in ? 'mail-in' : 'mail-out'; ?>">
                <div class="mail-meta">
                    <span>
                        <?php if ($is_in): ?>
                            📥 <b>От:</b> <?php echo $msg['from_title']; ?> (<a href="<?php echo htmlspecialchars($msg['from_url']); ?>" target="_blank" style="color:#00b4d8;"><?php echo htmlspecialchars($msg['from_url']); ?></a>)
                        <?php else: ?>
                            📤 <b>Кому:</b> <a href="<?php echo htmlspecialchars($msg['to_url']); ?>" target="_blank" style="color:#00b4d8;"><?php echo htmlspecialchars($msg['to_url']); ?></a>
                        <?php endif; ?>
                    </span>
                    <span>🕒 <?php echo htmlspecialchars($msg['date'] ?? ''); ?></span>
                </div>
                <div class="mail-subj"><?php echo $msg['subject']; ?></div>
                <div class="mail-text"><?php echo $msg['text']; ?></div>
                <div class="mail-actions">
                    <?php if ($is_in): ?>
                        <a href="?reply=<?php echo urlencode($msg['from_url']); ?>" style="color:#28a745;">↩️ Ответить</a>
                    <?php endif; ?>
                    <a href="?del=<?php echo urlencode($msg['id']); ?>" style="color:#d9534f;" onclick="return confirm('Удалить письмо?');">🗑️ Удалить</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>
