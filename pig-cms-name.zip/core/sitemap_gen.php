<?php
/* 
 * 🐷 PIG-CMS 
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

// Защита: если конфиг не подключен, подключаем его относительно ядра
if (!isset($DIR_SNYAT_POSTS)) {
    require_once __DIR__ . '/config.php';
}

// Получаем базовый URL сайта динамически
$base_url = "https://" . $_SERVER['HTTP_HOST'];

// Начало XML-документа карты сайта
$xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
$xml .= '<urlset xmlns="http://' . 'www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

// 1. СТАТИЧНЫЕ СТРАНИЦЫ И ДЕМО-РАЗДЕЛЫ ПЛАТФОРМЫ
$xml .= '  <url>' . "\n" . '    <loc>' . $base_url . '/index.php</loc>' . "\n" . '    <priority>1.0</priority>' . "\n" . '  </url>' . "\n";
$xml .= '  <url>' . "\n" . '    <loc>' . $base_url . '/radio.php</loc>' . "\n" . '    <priority>0.9</priority>' . "\n" . '  </url>' . "\n";
$xml .= '  <url>' . "\n" . '    <loc>' . $base_url . '/market.php</loc>' . "\n" . '    <priority>0.9</priority>' . "\n" . '  </url>' . "\n";
$xml .= '  <url>' . "\n" . '    <loc>' . $base_url . '/video.php</loc>' . "\n" . '    <priority>0.8</priority>' . "\n" . '  </url>' . "\n";
$xml .= '  <url>' . "\n" . '    <loc>' . $base_url . '/tasks/</loc>' . "\n" . '    <priority>0.8</priority>' . "\n" . '  </url>' . "\n";
$xml .= '  <url>' . "\n" . '    <loc>' . $base_url . '/games.php</loc>' . "\n" . '    <priority>0.7</priority>' . "\n" . '  </url>' . "\n";
$xml .= '  <url>' . "\n" . '    <loc>' . $base_url . '/index.php?cat=rules</loc>' . "\n" . '    <priority>0.5</priority>' . "\n" . '  </url>' . "\n";


// 2. ДИНАМИЧЕСКИЕ СТРАНИЦЫ: Посты авторов (Витрина Хаба)
if (is_dir($DIR_SNYAT_POSTS)) {
    $snyat_files = glob($DIR_SNYAT_POSTS . "*.json");
    foreach ($snyat_files as $file) {
        $id = basename($file, '.json');
        $xml .= '  <url>' . "\n";
        $xml .= '    <loc>' . $base_url . '/index.php?view=' . $id . '</loc>' . "\n";
        $xml .= '    <priority>0.8</priority>' . "\n";
        $xml .= '  </url>' . "\n";
    }
}

// 3. ДИНАМИЧЕСКИЕ СТРАНИЦЫ: Треки независимого Радио
if (is_dir($DIR_RADIO_POSTS)) {
    $radio_files = glob($DIR_RADIO_POSTS . "*.json");
    foreach ($radio_files as $file) {
        $id = basename($file, '.json');
        $xml .= '  <url>' . "\n";
        $xml .= '    <loc>' . $base_url . '/radio.php?view=' . $id . '</loc>' . "\n";
        $xml .= '    <priority>0.7</priority>' . "\n";
        $xml .= '  </url>' . "\n";
    }
}

// Закрываем тег urlset
$xml .= '</urlset>';

// Записываем готовую карту в корень сайта
$sitemap_path = __DIR__ . '/../sitemap.xml';
file_put_contents($sitemap_path, $xml);
