<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

if (session_status() === PHP_SESSION_NONE) { session_start(); }
date_default_timezone_set('Europe/Moscow');
require_once __DIR__ . '/config.php';

$data_dir = __DIR__ . '/../tasks/data_posts';

// 1. ДОБАВЛЕНИЕ ЗАДАЧИ ОТ ЮЗЕРА
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_post') {
    if (isset($_SESSION['last_post_time']) && (time() - $_SESSION['last_post_time']) < 300) {
        $_SESSION['task_err'] = 'Ошибка: отправлять сообщения можно раз в 5 минут!';
    } else {
        $title = trim(strip_tags($_POST['title'] ?? ''));
        $name = trim(strip_tags($_POST['name'] ?? ''));
        $rubric = trim(strip_tags($_POST['rubric'] ?? ''));
        $text = trim(strip_tags($_POST['text'] ?? ''));
        $captcha = trim($_POST['captcha'] ?? '');

        if (empty($title) || empty($text) || empty($rubric)) { 
            $_SESSION['task_err'] = 'Заполните обязательные поля!'; 
        } elseif (intval($captcha) !== ($_SESSION['captcha_num1'] + $_SESSION['captcha_num2'])) { 
            $_SESSION['task_err'] = 'Неверный ответ капчи! 🤔'; 
        } else {
            if (empty($name)) { $name = 'Аноним'; }
            $post_data = ['id' => time() . '_' . rand(100, 999), 'title' => $title, 'name' => $name, 'rubric' => $rubric, 'text' => $text, 'date' => date('d.m.Y H:i'), 'status' => 0, 'replies' => []];
            if (!is_dir($data_dir)) { mkdir($data_dir, 0755, true); }
            file_put_contents($data_dir . '/post_' . $post_data['id'] . '.json', json_encode($post_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            unset($_SESSION['captcha_num1']); unset($_SESSION['captcha_num2']); 
            $_SESSION['last_post_time'] = time();
            $_SESSION['task_ok'] = 'Задача успешно отправлена на модерацию!';
        }
    }
    header("Location: ../tasks/index.php" . (isset($_POST['rubric']) ? "?rubric=".urlencode($_POST['rubric']) : ""));
    exit;
}

// 2. ОТВЕТ АВТОРА НА ЗАДАНИЕ ИЗ ЛЕНТЫ
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'author_reply') {
    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
        $post_id = preg_replace('/[^0-9_]/', '', $_POST['post_id'] ?? ''); 
        $file = $data_dir . '/post_' . $post_id . '.json';
        $reply_text = trim(strip_tags($_POST['reply_text'] ?? '')); 
        $reply_url = trim(strip_tags($_POST['reply_url'] ?? ''));
        
        if ($post_id !== '' && file_exists($file) && !empty($reply_text)) {
            $updated = pig_json_update($file, function($content) use ($reply_text, $reply_url) {
                if (empty($content)) return null;
                if (!isset($content['replies']) || !is_array($content['replies'])) {
                    $content['replies'] = [];
                }
                $content['replies'][] = [
                    'author'     => $_SESSION['username'] ?? 'Admin',
                    'reply_text' => $reply_text,
                    'reply_url'  => $reply_url
                ];
                return $content;
            }, null);

            if ($updated !== false) {
                $_SESSION['task_ok'] = 'Готовое решение успешно прикреплено к промту! 🚀';
            }
        }
    }
    header("Location: ../tasks/index.php?page=" . intval($_POST['current_page'] ?? 1) . "#post-" . ($post_id ?? ''));
    exit;
}
header("Location: ../tasks/index.php");
exit;

