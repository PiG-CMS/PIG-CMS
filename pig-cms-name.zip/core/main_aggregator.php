<?php
/* 
 * 🐷 PIG-CMS — Модульный Агрегатор Главной
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

// Функция для быстрого сбора N последних JSON-постов из любой папки data
function get_latest_module_posts($dir, $limit = 3) {
    if (!is_dir($dir)) return [];
    $files = glob($dir . "*.json");
    if (empty($files)) return [];
    
    // Сортировка по времени изменения (новые сверху)
    array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
    $files = array_slice($files, 0, $limit);
    
    $result = [];
    foreach ($files as $file) {
        $data = json_decode(file_get_contents($file), true);
        if ($data) {
            $data['id'] = basename($file, '.json');
            $result[] = $data;
        }
    }
    return $result;
}

// Собираем данные из активных модулей
$latest_snyat  = get_latest_module_posts($DIR_SNYAT_POSTS, 3);
$latest_market = get_latest_module_posts($DIR_MARKET_POSTS, 3);
$latest_radio  = get_latest_module_posts($DIR_RADIO_POSTS, 3);
?>

<div class="aggregator-wrap" style="font-family: monospace; color: #fff; max-width: 900px; margin: 0 auto; padding: 0 10px;">
    
    <h2 style="text-align: center; color: #ffb703; border-bottom: 1px dashed #333; padding-bottom: 15px; text-transform: uppercase;">
        📡 Лента обновлений децентрализованного Хаба
    </h2>

    <!-- СЕКЦИЯ 1: БЛОГИ АВТОРОВ -->
    <section style="margin-bottom: 40px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #007bff; margin-bottom: 15px;">
            <h3 style="color: #007bff; margin: 5px 0;">👥 Свежее в портфолио</h3>
            <a href="index.php?set_view=grid" style="color: #aaa; text-decoration: none; font-size: 13px;">Все посты →</a>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
            <?php if(!empty($latest_snyat)): foreach($latest_snyat as $post): ?>
                <div style="background: #1e1e1e; border: 1px solid #333; padding: 12px; border-radius: 6px;">
                    <a href="index.php?view=<?php echo $post['id']; ?>" style="color: #ffc107; font-weight: bold; text-decoration: none; display: block; margin-bottom: 5px;">
                        🎬 <?php echo htmlspecialchars($post['title']); ?>
                    </a>
                    <span style="font-size: 11px; color: #888;">Автор: @<?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></span>
                </div>
            <?php endforeach; else: ?><p style="color:#666;">Постов пока нет.</p><?php endif; ?>
        </div>
    </section>

    <!-- СЕКЦИЯ 2: МАРКЕТПЛЕЙС -->
    <section style="margin-bottom: 40px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e67e22; margin-bottom: 15px;">
            <h3 style="color: #e67e22; margin: 5px 0;">🛍️ Новое на Витрине / Доске</h3>
            <a href="market.php" style="color: #aaa; text-decoration: none; font-size: 13px;">В маркет →</a>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
            <?php if(!empty($latest_market)): foreach($latest_market as $item): ?>
                <div style="background: #1e1e1e; border: 1px solid #333; padding: 12px; border-radius: 6px;">
                    <a href="market.php?view=<?php echo $item['id']; ?>" style="color: #e67e22; font-weight: bold; text-decoration: none; display: block; margin-bottom: 5px;">
                        💎 <?php echo htmlspecialchars($item['title']); ?>
                    </a>
                    <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 5px;">
                        <span style="color: #28a745; font-weight: bold;"><?php echo htmlspecialchars($item['price'] ?? 'Договорная'); ?></span>
                        <span style="color: #888;">@<?php echo htmlspecialchars($item['author'] ?? 'Seller'); ?></span>
                    </div>
                </div>
            <?php endforeach; else: ?><p style="color:#666;">Объявлений пока нет.</p><?php endif; ?>
        </div>
    </section>

    <!-- СЕКЦИЯ 3: РАДИО -->
    <section style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #002bfa; margin-bottom: 15px;">
            <h3 style="color: #002bfa; margin: 5px 0;">📻 Эфир Радио Доктора Шрам</h3>
            <a href="radio.php" style="color: #aaa; text-decoration: none; font-size: 13px;">Слушать эфир →</a>
        </div>
        <div style="background: #111; border: 1px dashed #002bfa; padding: 15px; border-radius: 6px;">
            <?php if(!empty($latest_radio)): ?>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <?php foreach($latest_radio as $track): ?>
                        <li style="padding: 8px 0; border-bottom: 1px solid #222; display: flex; justify-content: space-between; align-items: center;">
                            <span style="color: #fff;">🎵 <?php echo htmlspecialchars($track['artist'] ?? 'ИИ-Исполнитель'); ?> — <b><?php echo htmlspecialchars($track['title']); ?></b></span>
                            <span style="font-size: 11px; background: #222; padding: 3px 8px; border-radius: 4px; color: #ffb703;">NEW</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?><p style="color:#666; margin: 0;">Музыкальная база пуста.</p><?php endif; ?>
        </div>
    </section>
</div>
