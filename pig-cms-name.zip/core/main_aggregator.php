<?php
/* 
 * 🐷 PIG-CMS — Модульный Агрегатор Главной (5 модулей + Адаптив под планшеты)
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

// === БЛОК 1: ФУНКЦИИ СБОРА ДАННЫХ И ПОИСКА ОБЛОЖЕК ===
function get_latest_module_posts($dir, $limit = 3, $only_active_status = false) {
    if (!is_dir($dir)) return [];
    $files = glob(rtrim($dir, '/') . "/*.json");
    if (empty($files)) return [];
    
    array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
    
    $result = [];
    foreach ($files as $file) {
        $data = json_decode(file_get_contents($file), true);
        if (!$data) continue;
        
        if ($only_active_status && (!isset($data['status']) || $data['status'] !== 1)) {
            continue;
        }
        
        if (empty($data['id'])) {
            $data['id'] = basename($file, '.json');
        }
        $result[] = $data;
        if (count($result) >= $limit) break;
    }
    return $result;
}

function get_aggregator_video_poster($post) {
    if (!empty($post['poster_url'])) return $post['poster_url'];
    $path = parse_url($post['video_url'] ?? '', PHP_URL_PATH);
    $name = pathinfo($path, PATHINFO_FILENAME);
    if (!empty($name)) {
        foreach (['jpg', 'jpeg', 'png', 'webp'] as $ext) {
            $rel = "media/images/{$name}-poster.{$ext}";
            if (file_exists(__DIR__ . '/../' . $rel)) return $rel;
        }
    }
    return '';
}

$DIR_TASKS_POSTS = __DIR__ . '/../tasks/data_posts/';

$latest_snyat  = get_latest_module_posts($DIR_SNYAT_POSTS, 3);
$latest_videos = get_latest_module_posts($DIR_VIDEO_POSTS, 3);
$latest_tasks  = get_latest_module_posts($DIR_TASKS_POSTS, 3, true);
$latest_market = get_latest_module_posts($DIR_MARKET_POSTS, 3);
$latest_radio  = get_latest_module_posts($DIR_RADIO_POSTS, 3);
?>

<style>
/* Адаптивная сетка: ПК = 3, Планшет = 2 (3-я скрыта), Телефон = 1 */
.agg-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; }
@media (max-width: 820px) and (min-width: 521px) {
    .agg-grid { grid-template-columns: repeat(2, 1fr); }
    .agg-grid > div:nth-child(3) { display: none !important; }
}
@media (max-width: 520px) {
    .agg-grid { grid-template-columns: 1fr; }
}
</style>

<div class="aggregator-wrap" style="font-family: monospace; color: #fff; max-width: 900px; margin: 0 auto; padding: 0 10px;">
    
    <h2 style="text-align: center; color: #ffb703; border-bottom: 1px dashed #333; padding-bottom: 15px; text-transform: uppercase;">
        📡 Лента обновлений децентрализованного Хаба
    </h2>

    <!-- === БЛОК 2: СЕКЦИЯ БЛОГОВ АВТОРОВ === -->
    <section style="margin-bottom: 35px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #007bff; margin-bottom: 15px;">
            <h3 style="color: #007bff; margin: 5px 0;">👥 Свежее в портфолио</h3>
            <a href="index.php?set_view=grid" style="color: #aaa; text-decoration: none; font-size: 13px;">Все посты →</a>
        </div>
        <div class="agg-grid">
            <?php if(!empty($latest_snyat)): foreach($latest_snyat as $post): ?>
                <div style="background: #1e1e1e; border: 1px solid #333; padding: 12px; border-radius: 6px;">
                    <a href="index.php?view=<?php echo htmlspecialchars($post['id']); ?>" style="color: #ffc107; font-weight: bold; text-decoration: none; display: block; margin-bottom: 5px;">
                        📝 <?php echo htmlspecialchars($post['title']); ?>
                    </a>
                    <span style="font-size: 11px; color: #888;">Автор: @<?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></span>
                </div>
            <?php endforeach; else: ?><p style="color:#666;">Постов пока нет.</p><?php endif; ?>
        </div>
    </section>

    <!-- === БЛОК 3: СЕКЦИЯ ВИДЕО-ХАБА === -->
    <section style="margin-bottom: 35px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e74c3c; margin-bottom: 15px;">
            <h3 style="color: #e74c3c; margin: 5px 0;">📹 Новое в Видео-Хабе</h3>
            <a href="video.php" style="color: #aaa; text-decoration: none; font-size: 13px;">Все видео →</a>
        </div>
        <div class="agg-grid">
            <?php if(!empty($latest_videos)): foreach($latest_videos as $vid): $v_poster = get_aggregator_video_poster($vid); ?>
                <div style="background: #1e1e1e; border: 1px solid #333; border-radius: 6px; overflow: hidden; display: flex; flex-direction: column;">
                    <a href="video.php?view=<?php echo htmlspecialchars($vid['id']); ?>" style="text-decoration: none; display: block; position: relative; height: 95px; background: #111;">
                        <?php if(!empty($v_poster)): ?>
                            <img src="<?php echo htmlspecialchars($v_poster); ?>" alt="" style="width: 100%; height: 100%; object-fit: cover; display: block;">
                        <?php endif; ?>
                        <div style="position: absolute; inset: 0; background: rgba(0,0,0,0.35); display: flex; align-items: center; justify-content: center;">
                            <span style="width: 34px; height: 34px; border-radius: 50%; background: rgba(231, 76, 60, 0.9); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 14px;">▶</span>
                        </div>
                    </a>
                    <div style="padding: 10px 12px;">
                        <a href="video.php?view=<?php echo htmlspecialchars($vid['id']); ?>" style="color: #ff7675; font-weight: bold; text-decoration: none; display: block; margin-bottom: 4px; font-size: 13px;">
                            <?php echo htmlspecialchars($vid['title']); ?>
                        </a>
                        <span style="font-size: 11px; color: #888;">Автор: @<?php echo htmlspecialchars($vid['author'] ?? 'Admin'); ?></span>
                    </div>
                </div>
            <?php endforeach; else: ?><p style="color:#666;">Видеороликов пока нет.</p><?php endif; ?>
        </div>
    </section>

      <!-- === БЛОК 4: СЕКЦИЯ ЗАДАЧ И ПРОМТОВ === -->
    <section style="margin-bottom: 35px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #9b59b6; margin-bottom: 15px;">
            <h3 style="color: #bb8fce; margin: 5px 0;">🤪 Свежие Задачи и Промты</h3>
            <a href="tasks/" style="color: #aaa; text-decoration: none; font-size: 13px;">Все промты →</a>
        </div>
        <div class="agg-grid">
            <?php if(!empty($latest_tasks)): foreach($latest_tasks as $tsk): $rep_cnt = isset($tsk['replies']) && is_array($tsk['replies']) ? count($tsk['replies']) : 0; ?>
                <div style="background: #1e1e1e; border: 1px solid #333; padding: 12px; border-radius: 6px; display: flex; flex-direction: column; justify-content: space-between;">
                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                            <span style="font-size: 10px; background: #2c1e38; color: #d2b4de; border: 1px solid #8e44ad; padding: 1px 6px; border-radius: 4px;">
                                <?php echo htmlspecialchars($tsk['rubric'] ?? 'Промт'); ?>
                            </span>
                            <span style="font-size: 10px; color: <?php echo $rep_cnt > 0 ? '#2ecc71' : '#777'; ?>;">
                                ✅ Решений: <?php echo $rep_cnt; ?>
                            </span>
                        </div>
                        <a href="tasks/index.php#post-<?php echo htmlspecialchars($tsk['id']); ?>" style="color: #e0b0ff; font-weight: bold; text-decoration: none; display: block; margin-bottom: 6px; font-size: 13px;">
                            🎯 <?php echo htmlspecialchars($tsk['title']); ?>
                        </a>
                    </div>
                    <span style="font-size: 11px; color: #888;">От: <?php echo htmlspecialchars($tsk['name'] ?? 'Аноним'); ?></span>
                </div>
            <?php endforeach; else: ?><p style="color:#666;">Активных задач пока нет.</p><?php endif; ?>
        </div>
    </section>

    <!-- === БЛОК 5: СЕКЦИЯ МАРКЕТПЛЕЙСА === -->
    <section style="margin-bottom: 35px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #e67e22; margin-bottom: 15px;">
            <h3 style="color: #e67e22; margin: 5px 0;">🛍️ Новое на Витрине / Доске</h3>
            <a href="market.php" style="color: #aaa; text-decoration: none; font-size: 13px;">В маркет →</a>
        </div>
        <div class="agg-grid">
            <?php if(!empty($latest_market)): foreach($latest_market as $item): ?>
                <div style="background: #1e1e1e; border: 1px solid #333; padding: 12px; border-radius: 6px;">
                    <a href="market.php?view=<?php echo htmlspecialchars($item['id']); ?>" style="color: #e67e22; font-weight: bold; text-decoration: none; display: block; margin-bottom: 5px;">
                        💎 <?php echo htmlspecialchars($item['title']); ?>
                    </a>
                    <div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 5px;">
                        <span style="color: #28a745; font-weight: bold;"><?php echo htmlspecialchars($item['price'] ?? 'Договорная'); ?></span>
                        <span style="color: #888;">@<?php echo htmlspecialchars($item['author'] ?? 'Seller'); ?></span>
                    </div>
                </div>
            <?php endforeach; else: ?><p style="color:#666;">Объявлений пока нет.</p><?php endif; ?>
        </div>
    </section>

    <!-- === БЛОК 6: СЕКЦИЯ РАДИОЭФИРА === -->
    <section style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #002bfa; margin-bottom: 15px;">
            <h3 style="color: #002bfa; margin: 5px 0;">📻 Эфир Радио <?php echo htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG-CMS'); ?></h3>
            <a href="radio.php" style="color: #aaa; text-decoration: none; font-size: 13px;">Слушать эфир →</a>
        </div>
        <div style="background: #111; border: 1px dashed #002bfa; padding: 15px; border-radius: 6px;">
            <?php if(!empty($latest_radio)): ?>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    <?php foreach($latest_radio as $track): ?>
                        <li style="padding: 8px 0; border-bottom: 1px solid #222; display: flex; justify-content: space-between; align-items: center;">
                            <span style="color: #fff;">🎵 <?php echo htmlspecialchars($track['artist'] ?? 'ИИ-Исполнитель'); ?> — <b><?php echo htmlspecialchars($track['title']); ?></b></span>
                            <span style="font-size: 11px; background: #222; padding: 3px 8px; border-radius: 4px; color: #ffb703;">NEW</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?><p style="color:#666; margin: 0;">Музыкальная база пуста.</p><?php endif; ?>
        </div>
    </section>
</div>

  