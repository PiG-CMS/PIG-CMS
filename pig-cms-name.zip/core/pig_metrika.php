<?php
/* 
 * 🐷 PIG-МЕТРИКА — Легковесный суверенный счетчик сети PiTi & Google Hub
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

$metrika_dir = __DIR__ . '/../data/metrika_logs/';
if (!is_dir($metrika_dir)) { @mkdir($metrika_dir, 0755, true); }

$today = date('Y-m-d');
$stats_file = $metrika_dir . $today . '.json';
$user_ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

// Загружаем статистику за текущий день
$stats = file_exists($stats_file) ? json_decode(file_get_contents($stats_file), true) ?: [] : [];

if (!isset($stats['views'])) $stats['views'] = 0;
if (!isset($stats['ips'])) $stats['ips'] = [];

// Считаем общий просмотр страницы
$stats['views']++;

// Если такой IP сегодня еще не заходил — считаем уникального посетителя
if (!in_array($user_ip, $stats['ips'])) {
    $stats['ips'][] = $user_ip;
}

// Сохраняем обратно на диск
file_put_contents($stats_file, json_encode([
    'views' => $stats['views'],
    'uniques' => count($stats['ips']),
    'ips' => $stats['ips'] // Храним список IP для точного подсчета
], JSON_PRETTY_PRINT));
