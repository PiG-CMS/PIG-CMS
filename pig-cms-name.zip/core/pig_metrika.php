<?php
/* 
 * 🐷 PIG-МЕТРИКА — Легковесный суверенный счетчик сети PiTi & Google Hub
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

$metrika_dir = __DIR__ . '/../data/metrika_logs/';
$today = date('Y-m-d');
$stats_file = $metrika_dir . $today . '.json';

$salt = $APP_SETTINGS['privacy_salt'] ?? 'pig_metrika_salt';
$raw_ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

$visitor_hash = substr(hash('sha256', $raw_ip . '|' . $ua . '|' . $today . '|' . $salt), 0, 24);

pig_json_update($stats_file, function($stats) use ($visitor_hash) {
    $views = isset($stats['views']) ? (int)$stats['views'] : 0;
    $hashes = isset($stats['hashes']) && is_array($stats['hashes']) ? $stats['hashes'] : [];

    $views++;
    if (!in_array($visitor_hash, $hashes, true)) {
        $hashes[] = $visitor_hash;
    }

    return [
        'views'   => $views,
        'uniques' => count($hashes),
        'hashes'  => $hashes
    ];
}, ['views' => 0, 'uniques' => 0, 'hashes' => []]);

