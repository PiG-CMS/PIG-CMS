<?php
/* 
 * 🐷 PIG-CMS 
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/config.php';

$salt = $APP_SETTINGS['privacy_salt'] ?? 'pig_vote_salt';
$user_hash = substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') . $salt), 0, 24);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['version'])) {
    $post_id = preg_replace('/[^a-zA-Z0-9_-]/', '', trim($_POST['id']));
    $v_num = intval($_POST['version']);
    $file_path = $DIR_RADIO_POSTS . $post_id . '.json';

    if ($post_id !== '' && file_exists($file_path)) {
        $already_voted = false;
        $updated_post = pig_json_update($file_path, function($p) use ($user_hash, $v_num, &$already_voted) {
            if (empty($p)) return null;
            if (!isset($p['votes_ip'])) $p['votes_ip'] = [];
            
            if (in_array($user_hash, $p['votes_ip'], true)) {
                $already_voted = true;
                return null;
            }
            
            $p['votes_ip'][] = $user_hash;
            $key = 'votes_' . $v_num;
            $p[$key] = (isset($p[$key]) ? intval($p[$key]) : 0) + 1;
            return $p;
        }, null);

        if ($already_voted) {
            $p = json_decode(file_get_contents($file_path), true) ?: [];
            $p['status'] = 'already';
            echo json_encode($p);
            exit;
        } elseif ($updated_post !== false && is_array($updated_post)) {
            $updated_post['status'] = 'success';
            echo json_encode($updated_post);
            exit;
        }
    }
}
echo json_encode(['status' => 'error']);
exit;

