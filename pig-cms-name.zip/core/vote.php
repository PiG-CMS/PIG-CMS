<?php
/* 
 * 🐷 PIG-CMS 
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/config.php';

$user_ip = $_SERVER['REMOTE_ADDR'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['version'])) {
    $post_id = trim($_POST['id']);
    $v_num = intval($_POST['version']);
    $file_path = $DIR_RADIO_POSTS . $post_id . '.json';

    if (file_exists($file_path)) {
        $p = json_decode(file_get_contents($file_path), true);
        if ($p) {
            if (!isset($p['votes_ip'])) $p['votes_ip'] = [];
            
            if (in_array($user_ip, $p['votes_ip'])) {
                $p['status'] = 'already';
                echo json_encode($p);
                exit;
            }
            
            $p['votes_ip'][] = $user_ip;
            $key = 'votes_' . $v_num;
            $p[$key] = (isset($p[$key]) ? intval($p[$key]) : 0) + 1;
            
            file_put_contents($file_path, json_encode($p, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            $p['status'] = 'success';
            echo json_encode($p);
            exit;
        }
    }
}
echo json_encode(['status' => 'error']);
exit;
