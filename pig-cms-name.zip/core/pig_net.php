<?php
/*
 * 🪐 СЕТЕВОЙ ШЛЮЗ «МЕЖСАЙТОВЫЕ БОРТПОРТАЛЫ ХРЮНЛОКА» — PIG-NET
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

define('PIG_HUB', 'https://' . 'pig-cms.name');

/**
  * 📡 ИМПУЛЬС СЕТИ: Регистрация ссылки сайта в глобальном Квадранте
 */
function pingPigHub() {
    $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
                || ($_SERVER['SERVER_PORT'] ?? 80) == 443 
                || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $protocol = $is_https ? "https" : "http";

    $my_host = strtolower(preg_replace('/^www\./i', '', $_SERVER['HTTP_HOST'] ?? ''));
    if (empty($my_host) || strpos($my_host, 'localhost') !== false || strpos($my_host, '127.0.0.1') !== false) return;

    $my_url = $protocol . "://" . $my_host;
    $hub_host = parse_url(PIG_HUB, PHP_URL_HOST);
 
    $settings_file = __DIR__ . '/../data/app_settings.json';
    $settings = file_exists($settings_file) ? (json_decode(file_get_contents($settings_file), true) ?: []) : [];

    $radio_cfg_file = __DIR__ . '/../data/radio_galaxy.json';
    $radio_cfg = file_exists($radio_cfg_file) ? (json_decode(file_get_contents($radio_cfg_file), true) ?: []) : [];

    $display_host = $my_host;
    if (function_exists('idn_to_utf8') && strpos($my_host, 'xn--') !== false) {
        $utf8_host = idn_to_utf8($my_host, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
        if ($utf8_host) $display_host = $utf8_host;
    }

    $site_title = !empty($settings['site_title']) ? $settings['site_title'] : $display_host;
    $radio_active = !empty($radio_cfg['allow_broadcast']);
    $guard_until = intval($settings['guard_until'] ?? 0);

    $data = [
        'url'          => $my_url,
        'title'        => $site_title,
        'radio_active' => $radio_active,
        'guard_until'  => $guard_until,
        'version'      => '2026.1_Teleport',
        'time'         => time()
    ];
    // 🔥 ЛОКАЛЬНЫЙ ОБХОД (Если это сам Главный Хаб) — через атомарный flock
    if ($hub_host === $my_host || empty($hub_host)) {
        $map_file = __DIR__ . '/../data/galaxy_map.json';
        pig_json_update($map_file, function($galaxy) use ($my_host, $my_url, $site_title, $radio_active, $guard_until) {
            $planet_id = md5($my_host);
            $galaxy[$planet_id] = [
                'url'          => $my_url,
                'title'        => $site_title,
                'radio_active' => $radio_active,
                'guard_until'  => $guard_until,
                'version'      => '2026.1_Hub',
                'last_ping'    => time(),
                'last_date'    => date('d.m.Y H:i:s'),
                'discovered'   => $galaxy[$planet_id]['discovered'] ?? time()
            ];
            return $galaxy;
        }, []);
        return; 
    }

    // 📡 ОТПРАВКА ИМПУЛЬСА НА ГЛАВНЫЙ ХАБ (со строгой проверкой SSL)
    $register_url = PIG_HUB . '/api/register.php';
    pig_curl_request($register_url, json_encode($data, JSON_UNESCAPED_UNICODE), 2);
}

/**
 * 🛸 ПРИЕМНИК ПОРТАЛА: Межсайтовый радар набегов
*/

if (isset($_GET['action']) && $_GET['action'] === 'portal') {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['thief_site'])) {
        echo json_encode(['status' => 'error', 'message' => 'Варп-канал пуст. Набег отклонен.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $settings_path = __DIR__ . '/../data/app_settings.json';
    $settings = file_exists($settings_path) ? (json_decode(file_get_contents($settings_path), true) ?: []) : [];
    
    $guard_until = isset($settings['guard_until']) ? intval($settings['guard_until']) : 0;
    $time_left = $guard_until - time();

    if ($time_left > 0) {
        echo json_encode([
            'status'  => 'success',
            'allowed' => false,
            'message' => 'Облом! Жители или админ этой планеты недавно зарядили щиты Охраны! Твой Хрюндик пойман за уши, оштрафован на 3% и катапультирован обратно!'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    } else {
        $loot = rand(20, 100);
        echo json_encode([
            'status'  => 'success',
            'allowed' => true,
            'loot'    => $loot,
            'message' => 'Защитный купол отключен, кнопку никто не нажимал больше суток! Телепорт качает ресурсы...'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

/**
 * 🌌 ОТДАЧА СПИСКА ПЛАНЕТ ДЛЯ ПОЧТОВОГО КЭША
 */
if (isset($_GET['action']) && $_GET['action'] === 'get_galaxy') {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    $map_file = __DIR__ . '/../data/galaxy_map.json';
    $galaxy = file_exists($map_file) ? (json_decode(file_get_contents($map_file), true) ?: []) : [];
    $clean_list = [];
    foreach ($galaxy as $planet) {
        if (!empty($planet['url'])) {
            $clean_list[] = [
                'url'   => $planet['url'],
                'title' => $planet['title'] ?? $planet['url']
            ];
        }
    }
    echo json_encode($clean_list, JSON_UNESCAPED_UNICODE);
    exit;
}
