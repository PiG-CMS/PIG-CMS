<?php
/*
 * 🪐 СЕТЕВОЙ ШЛЮЗ «МЕЖСАЙТОВЫЕ БОРТПОРТАЛЫ ХРЮНЛОКА» — PIG-NET
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

define('PIG_HUB', 'https://' . 'pig-cms.name');

/**
  * 📡 ИМПУЛЬС СЕТИ: Регистрация ссылки сайта в глобальном Квадранте
 */
function pingPigHub() {
    $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
                || ($_SERVER['SERVER_PORT'] ?? 80) == 443 
                || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $protocol = $is_https ? "https" : "http";

    $my_host = strtolower(preg_replace('/^www\./i', '', $_SERVER['HTTP_HOST'] ?? ''));
    if (empty($my_host)) return;

    $my_url = $protocol . "://" . $my_host;
    $hub_host = parse_url(PIG_HUB, PHP_URL_HOST);
 
    // Читаем локальные настройки сайта и статус Галактического Радио
    $settings_file = __DIR__ . '/../data/app_settings.json';
    $settings = file_exists($settings_file) ? (json_decode(file_get_contents($settings_file), true) ?: []) : [];

    $radio_cfg_file = __DIR__ . '/../data/radio_galaxy.json';
    $radio_cfg = file_exists($radio_cfg_file) ? (json_decode(file_get_contents($radio_cfg_file), true) ?: []) : [];

    // Для красивого отображения кириллического домена, если не задано название сайта
    $display_host = $my_host;
    if (function_exists('idn_to_utf8') && strpos($my_host, 'xn--') !== false) {
        $utf8_host = idn_to_utf8($my_host, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
        if ($utf8_host) $display_host = $utf8_host;
    }

    $site_title = !empty($settings['site_title']) ? $settings['site_title'] : $display_host;
    $radio_active = !empty($radio_cfg['allow_broadcast']);
    $guard_until = intval($settings['guard_until'] ?? 0);

    $data = [
        'url'          => $my_url,
        'title'        => $site_title,
        'radio_active' => $radio_active,
        'guard_until'  => $guard_until,
        'version'      => '2026.1_Teleport',
        'time'         => time()
    ];

    // 🔥 ЛОКАЛЬНЫЙ ОБХОД (Если это сам Главный Хаб)
    if ($hub_host === $my_host || empty($hub_host)) {
        $map_file = __DIR__ . '/../data/galaxy_map.json';
        $galaxy = file_exists($map_file) ? (json_decode(file_get_contents($map_file), true) ?: []) : [];
        $planet_id = md5($my_url);
        $galaxy[$planet_id] = [
            'url'          => $my_url,
            'title'        => $site_title,
            'radio_active' => $radio_active,
            'guard_until'  => $guard_until,
            'version'      => '2026.1_Hub',
            'last_ping'    => time(),
            'last_date'    => date('d.m.Y H:i:s'),
            'discovered'   => $galaxy[$planet_id]['discovered'] ?? time()
        ];
        @file_put_contents($map_file, json_encode($galaxy, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return; 
    }

    // 📡 ОТПРАВКА ИМПУЛЬСА НА ГЛАВНЫЙ ХАБ (для внешних узлов, включая кириллические)
    if (function_exists('curl_init')) {
        $register_url = PIG_HUB . '/api/register.php';
        $ch = curl_init($register_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data, JSON_UNESCAPED_UNICODE));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 4);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);
    }
}

/**
 * 🛸 ПРИЕМНИК ПОРТАЛА: Межсайтовый радар набегов
 * Вызывается удаленно: твой-сайт.ру/core/pig_net.php?action=portal
 */
if (isset($_GET['action']) && $_GET['action'] === 'portal') {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['thief_site'])) {
        echo json_encode(['status' => 'error', 'message' => 'Варп-канал пуст. Набег отклонен.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $settings_path = __DIR__ . '/../data/app_settings.json';
    $settings = file_exists($settings_path) ? (json_decode(file_get_contents($settings_path), true) ?: []) : [];
    
    // 🛡️ ПРОВЕРКА ОБЩЕСТВЕННОГО КУПОЛА ЗАЩИТЫ (24 ЧАСА)
    $guard_until = isset($settings['guard_until']) ? intval($settings['guard_until']) : 0;
    $time_left = $guard_until - time();

    if ($time_left > 0) {
        echo json_encode([
            'status'  => 'success',
            'allowed' => false,
            'message' => 'Облом! Жители или админ этой планеты недавно зарядили щиты Охраны! Твой Хрюндик пойман за уши, оштрафован на 3% и катапультирован обратно!'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    } else {
        $loot = rand(20, 100);
        echo json_encode([
            'status'  => 'success',
            'allowed' => true,
            'loot'    => $loot,
            'message' => 'Защитный купол отключен, кнопку никто не нажимал больше суток! Телепорт качает ресурсы...'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}


/**
 * 🌌 ОТДАЧА СПИСКА ПЛАНЕТ ДЛЯ ПОЧТОВОГО КЭША (Запрашивается соседями раз в 6 часов)
 */
if (isset($_GET['action']) && $_GET['action'] === 'get_galaxy') {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    $map_file = __DIR__ . '/../data/galaxy_map.json';
    $galaxy = file_exists($map_file) ? (json_decode(file_get_contents($map_file), true) ?: []) : [];
    $clean_list = [];
    foreach ($galaxy as $planet) {
        if (!empty($planet['url'])) {
            $clean_list[] = [
                'url'   => $planet['url'],
                'title' => $planet['title'] ?? $planet['url']
            ];
        }
    }
    echo json_encode($clean_list, JSON_UNESCAPED_UNICODE);
    exit;
}
