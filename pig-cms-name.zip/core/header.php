<?php
/* 
 * 🐷 PIG-CMS 
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

// Динамически вычисляем корень сайта для правильных переходов по ссылкам
$root_url = "https://" . $_SERVER['HTTP_HOST'] . "/";
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'PIG-CMS Hub'; ?></title>
    <?php if (!empty($meta_description)): ?>
        <meta name="description" content="<?php echo htmlspecialchars($meta_description); ?>">
    <?php endif; ?>

    <!-- 🔥 ДИНАМИЧЕСКИЙ ПОДБОР CSS-ШАБЛОНА PIG-CMS -->
    <?php 
    // Подтягиваем имя активной темы из глобального JSON
    $active_theme = $APP_SETTINGS['theme_style'] ?? 'pig_pink';
    
    // Подключаем базовый CSS-каркас (чтобы разметка не ломалась)
    echo '<link rel="stylesheet" href="' . $root_url . 'assets/css/snyat.css">';
    
    // Поверх него накатываем цветовую схему выбранной админом темы
    echo '<link rel="stylesheet" href="' . $root_url . 'assets/css/themes/' . htmlspecialchars($active_theme) . '.css">';
    
    // Адаптация радио-модуля
    if ($active_theme === 'light_free') {
        echo '<link rel="stylesheet" href="' . $root_url . 'assets/css/radio_light.css">';
    } else {
        echo '<link rel="stylesheet" href="' . $root_url . 'assets/css/radio.css">';
    }
    ?>
  
  <style>
  img { max-width: 100% !important; height: auto !important; }
</style>

</head>

<body>  
<div class="wrapper" style="padding-top: 15px;">
    <header class="site-header" style="margin-bottom: 20px;">
        
          <h1><a href="<?php echo $root_url; ?>index.php"><?php echo htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS'); ?></a></h1>
    <p><?php echo htmlspecialchars($APP_SETTINGS['site_slogan'] ?? 'PIG-CMS— твоя независимая экосистема'); ?></p>

      <!-- 👥 ОБНОВЛЕННОЕ СЕМАНТИЧЕСКОЕ МЕНЮ РАЗДЕЛОВ (ТЕГ NAV) -->
<nav class="category-menu menu-sections" style="margin-bottom: 0; display: flex; flex-wrap: wrap; gap: 8px;">
    
    <?php
    // Определяем, какие разделы сейчас активны
    $is_index  = (!isset($is_radio_page) && (!isset($_GET['cat']) || $_GET['cat'] === 'all') && basename($_SERVER['SCRIPT_NAME']) === 'index.php' && !strpos($_SERVER['REQUEST_URI'], 'tasks'));
    $is_market = (basename($_SERVER['SCRIPT_NAME']) === 'market.php');
    $is_radio  = (isset($is_radio_page) && $is_radio_page);
    $is_video  = (basename($_SERVER['SCRIPT_NAME']) === 'video.php');
    $is_tasks  = (strpos($_SERVER['REQUEST_URI'], '/tasks/') !== false);
    $is_games  = (basename($_SERVER['SCRIPT_NAME']) === 'games.php');
    $is_bot    = (basename($_SERVER['SCRIPT_NAME']) === 'bot.php'); // 🔥 Активный статус для бота
    $is_rules  = (!isset($is_radio_page) && isset($_GET['cat']) && $_GET['cat'] === 'rules');
    ?>

    <!-- 👥 Блоги Авторов -->
    <a href="<?php echo $root_url; ?>index.php" 
       class="<?php echo $is_index ? 'active' : ''; ?>" 
       style="border: 1px solid #007bff; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_index ? 'background: #007bff; color: #ffffff !important;' : 'color: #007bff; background: transparent;'; ?>">
       👥 Блоги Авторов
    </a>
  
    <!-- 🛍️ Объявления / Маркет -->
    <a href="<?php echo $root_url; ?>market.php" 
       class="<?php echo $is_market ? 'active' : ''; ?>" 
       style="border: 1px solid #e67e22; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_market ? 'background: #e67e22; color: #ffffff !important;' : 'color: #e67e22; background: transparent;'; ?>">
       🛍️ Объявления / Маркет
    </a>
  
    <!-- 📻 Фоновое Радио -->
    <a href="<?php echo $root_url; ?>radio.php" 
       class="<?php echo $is_radio ? 'active' : ''; ?>" 
       style="border: 1px solid #002bfa; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_radio ? 'background: #002bfa; color: #ffffff !important;' : 'color: #002bfa; background: transparent;'; ?>">
       📻 Фоновое Радио
    </a>
  
    <!-- 📹 Видео-Хаб -->
    <a href="<?php echo $root_url; ?>video.php" 
       class="<?php echo $is_video ? 'active' : ''; ?>" 
       style="border: 1px solid #28a745; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_video ? 'background: #28a745; color: #ffffff !important;' : 'color: #28a745; background: transparent;'; ?>">
       📹 Видео-Хаб
    </a>
  
    <!-- 🤪 Задачи и Промты -->
    <a href="<?php echo $root_url; ?>tasks/" 
       class="<?php echo $is_tasks ? 'active' : ''; ?>" 
       style="border: 1px solid #ffc107; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_tasks ? 'background: #ffc107; color: #111111 !important;' : 'color: #ffc107; background: transparent;'; ?>">
       🤪 <?php echo isset($ABSURD_MODULE_TITLE) ? $ABSURD_MODULE_TITLE : "Задачи и Промты"; ?>
    </a>
  
    <!-- 🎮 ИГРЫ -->
    <a href="<?php echo $root_url; ?>games.php" 
       class="<?php echo $is_games ? 'active' : ''; ?>" 
       style="border: 1px solid #ffb703; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_games ? 'background: #ffb703; color: #111111 !important;' : 'color: #ffb703; background: transparent;'; ?>">
       🎮 ИГРЫ
    </a> 

    <!-- 🤖 Бот Эволюция (Фиолетовый стиль под иконку браузера) -->
    <a href="<?php echo $root_url; ?>bot.php" 
       class="<?php echo $is_bot ? 'active' : ''; ?>" 
       style="border: 1px solid #9b5de5; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_bot ? 'background: #9b5de5; color: #ffffff !important;' : 'color: #9b5de5; background: transparent;'; ?>">
       🤖 Бот Эволюция
    </a>

     <!-- 📜 Правила -->
    <a href="<?php echo $root_url; ?>index.php?cat=rules" 
       class="<?php echo $is_rules ? 'active' : ''; ?>"
       style="border: 1px solid #6c757d; font-weight: bold; padding: 6px 12px; text-decoration: none; border-radius: 4px; 
              <?php echo $is_rules ? 'background: #6c757d; color: #ffffff !important;' : 'color: #6c757d; background: transparent;'; ?>">
       📜 Правила
    </a>
  
    <!-- Кнопки ... -->
    <?php if (isset($_SESSION['auth']) && $_SESSION['auth'] === true): ?>  
        <a href="<?php echo $root_url; ?>admin/index.php" class="add-btn" style="background: #28a745; color: #fff; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-weight: bold; margin-left: auto;">⚙️ В admin</a>
    <?php else: ?>
        <a href="<?php echo $root_url; ?>admin/index.php" class="login-btn" style="background: #007bff; color: #fff; padding: 6px 12px; text-decoration: none; border-radius: 4px; font-weight: bold; margin-left: auto;">🔑 Вход</a>
    <?php endif; ?>
</nav>
</header>
