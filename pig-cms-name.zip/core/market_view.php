<?php
/* 
 * 🐷 PIG-CMS
 * pig-cms.name 
 * Визуальное представление Доски Объявлений
 */
if (!defined('PIG-CMS Hub') && !isset($posts_data)) { exit; } // Защита от прямого вызова
?>

<!-- ==================== ШАБЛОН 1: ДЕТАЛЬНЫЙ ПРОСМОТР ТОВАРА ==================== -->
<?php if (!empty($view_single) && !empty($posts_data)): $post = $posts_data[0]; ?>
    <div style="text-align:center; margin-bottom:25px;"><a href="market.php" style="color:#007bff; font-weight:bold; text-decoration:none; font-family:monospace;">← Назад к объявлениям</a></div>
    
    <div class="single-post-wrap" style="font-family:monospace;">
        <img src="<?php echo htmlspecialchars($post['img_url']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" style="width:100%; max-height:450px; object-fit:cover; border-radius:6px;">
        <div style="font-size:11px; color:#555; margin:10px 0 20px 0; word-break:break-all;">Превью хостится на: <?php echo htmlspecialchars($post['img_url']); ?></div>
        
        <div class="single-post-title" style="font-size:24px; font-weight:bold; margin-bottom:15px; color:#ffc107;"><?php echo htmlspecialchars($post['title']); ?></div>
        <div style="font-size:13px; margin-bottom:20px; color:#aaa;">Автор: <a href="index.php?author=<?php echo urlencode($post['author'] ?? 'Admin'); ?>" style="color:#007bff; text-decoration:none;">@<?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></a></div>
        
        <div class="single-post-desc" style="white-space:pre-wrap; line-height:1.6; font-size:15px; color:#ddd;"><?php echo nl2br(htmlspecialchars($post['description'])); ?></div>
        
        <div style="text-align: center; margin: 30px 0;">
            <a href="<?php echo htmlspecialchars($post['target_url']); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-block; background:#28a745; color:white; padding:12px 28px; text-decoration:none; border-radius:4px; font-weight:bold; font-size:16px;">
                📦 Скачать →
            </a>
        </div>

        <div class="reactions-bar" style="padding-top:15px; border-top:1px solid #333;">
            <form method="POST" style="margin:0;" onsubmit="return checkVote(this, '<?php echo $post['id']; ?>', 'like')">
                <input type="hidden" name="action" value="like_useful">
                <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                <button type="submit" class="react-btn" style="background:#8e44ad; color:#fff; border:none; padding:8px 15px; font-weight:bold; border-radius:4px; cursor:pointer;">
                    👍 Респект автору (<?php echo $post['like_useful'] ?? 0; ?>)
                </button>
            </form>
        </div>

       
 <!--  просто удали строки 42 и 53 чтоб получать жалобы на посты админа оставь только дивы div -->
      
        <?php if (strtolower(trim($post['author'] ?? '')) !== 'admin' && strtolower(trim($post['status'] ?? '')) !== 'admin'): ?>
            <div class="report-block" style="background:#1a1a1a; padding:15px; border-radius:4px; margin-top:25px; border-left:4px solid #d9534f;">
                <h4 style="margin:0 0 10px 0; color:#d9534f; font-size:14px;">Заметили обман или спам?</h4>
                <form method="POST" style="display:flex; align-items:center; flex-wrap:wrap; gap:10px; margin:0;" onsubmit="return checkVote(this, '<?php echo $post['id']; ?>', 'report')">
                    <input type="hidden" name="action" value="report">
                    <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                    <span style="font-size:12px;">Капча: [ <?php echo $_SESSION['m_captcha_text']; ?> ] =</span>
                    <input type="number" name="report_captcha" required style="width:50px; padding:4px; background:#333; color:#fff; border:1px solid #555;">
                    <button type="submit" class="report-btn" style="background:#d9534f; color:#fff; border:none; padding:5px 10px; font-weight:bold; cursor:pointer; font-size:11px; border-radius:2px;">Пожаловаться (<?php echo $post['report_count'] ?? 0; ?>)</button>
                </form>
            </div>
        <?php endif; ?>

<!-- ==== ШАБЛОН 2: СЕТКА КАРТОЧЕК НА ГЛАВНОЙ МАРКЕТА === -->
<?php else: ?>
    <div class="grid-container">
        <?php if (!empty($posts_data)): ?>
            <?php 
            $per_page = 12; $total_posts = count($posts_data); $total_pages = ceil($total_posts / $per_page);
            $current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
            $sliced_posts = array_slice($posts_data, ($current_page - 1) * $per_page, $per_page);
            
            foreach ($sliced_posts as $post): 
            ?>
                <div class="card">
                    <a href="market.php?view=<?php echo $post['id']; ?>" class="card-link">
                        <img src="<?php echo htmlspecialchars($post['img_url']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>"> 
                        <span class="card-title"><?php echo htmlspecialchars($post['title']); ?></span>
                    </a>
                    <div style="font-size:11px; color:#888; padding:0 12px; font-family:monospace;">Автор: @<?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></div>
                    <?php if (!empty($post['description'])): ?>
                        <div class="card-desc">
                            <?php 
                            $s = strip_tags($post['description']);
                            echo (mb_strlen($s, 'UTF-8') > 120) ? mb_substr($s, 0, 120, 'UTF-8') . '...' : $s; 
                            ?>
                        </div>
                    <?php endif; ?>
                    <div style="background:#1f1f1f; padding:8px 12px; font-size:12px; display:flex; justify-content:space-between; font-weight:bold;">
                        <span style="color:#aaa;">👍 Респекты: <?php echo $post['like_useful'] ?? 0; ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align:center; grid-column:1/-1; font-family:monospace; color:#666;">Объявлений в маркете пока нет.</p>
        <?php endif; ?>
    </div>

    <?php if (isset($total_pages) && $total_pages > 1): ?>
        <div class="pagination" style="text-align:center; margin-top:30px;">
            <a href="market.php?page=<?php echo max(1, $current_page - 1); ?>" style="color:#fff; background:#222; padding:8px 15px; text-decoration:none; margin-right:10px; border-radius:4px; <?php echo $current_page <= 1 ? 'pointer-events:none; opacity:0.4;' : ''; ?>">← Назад</a>
            <a href="market.php?page=<?php echo min($total_pages, $current_page + 1); ?>" style="color:#fff; background:#222; padding:8px 15px; text-decoration:none; border-radius:4px; <?php echo $current_page >= $total_pages ? 'pointer-events:none; opacity:0.4;' : ''; ?>">Вперед →</a>
        </div>
    <?php endif; ?>
<?php endif; ?>

<script>
function checkVote(formElement, postId, type) {
    const storageKey = (type === 'like') ? 'voted_m_like_' + postId : 'voted_m_report_' + postId;
    if (localStorage.getItem(storageKey) || document.cookie.split('; ').find(row => row.startsWith(storageKey + '='))) {
        alert((type === 'like') ? 'Мнение уже учтено!' : 'Вы уже отправляли жалобу!');
        return false;
    }
    localStorage.setItem(storageKey, 'true');
    document.cookie = storageKey + "=true; max-age=31536000; path=/; SameSite=Strict";
    return true;
}
</script>
