<?php
/* 
 * 🐷 PIG-CMS — Конфигурация Ядра Экосистемы
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. НАСТРОЙКА ДОСТУПА ДЛЯ АДМИНКИ (Хранение хэшей в защищённом data/users.json без сброса OPcache)
function pig_hash_pass(string $pass): string {
    $salt = bin2hex(random_bytes(8));
    return 'sha256$' . $salt . '$' . hash('sha256', $salt . $pass);
}

function pig_verify_pass(string $pass, string $stored): bool {
    if (strpos($stored, 'sha256$') === 0) {
        $parts = explode('$', $stored);
        if (count($parts) !== 3) return false;
        list(, $salt, $saved_hash) = $parts;
        return hash_equals($saved_hash, hash('sha256', $salt . $pass));
    }
    return hash_equals($stored, $pass);
}

$FILE_USERS = __DIR__ . '/../data/users.json';
if (file_exists($FILE_USERS)) {
    $users = json_decode(file_get_contents($FILE_USERS), true) ?: ['admin' => '1234'];
} else {
    $users = [
        'admin' => '1234',
        // [USERS_ANCHOR]
    ];
}

/**
 * 🔒 АТОМАРНОЕ ЧТЕНИЕ-ИЗМЕНЕНИЕ-ЗАПИСЬ JSON С БЛОКИРОВКОЙ (FLOCK)
 */
function pig_json_update(string $filepath, callable $callback, $default = []) {
    $dir = dirname($filepath);
    if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
    $fp = @fopen($filepath, 'c+');
    if (!$fp) return false;

    $result = false;
    if (flock($fp, LOCK_EX)) {
        $content = stream_get_contents($fp);
        $data = ($content !== false && $content !== '') ? json_decode($content, true) : null;
        if (!is_array($data)) { $data = $default; }

        $new_data = $callback($data);

        if ($new_data !== null) {
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($new_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
            fflush($fp);
            $result = $new_data;
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);
    return $result;
}

/**
 * 🌐 БЕЗОПАСНЫЙ cURL-ЗАПРОС С ПРОВЕРКОЙ SSL (И ФОЛЛБЭКОМ ДЛЯ СТАРЫХ ХОСТИНГОВ)
 */
function pig_curl_request(string $url, ?string $json_payload = null, int $timeout = 5): array {
    if (!function_exists('curl_init')) {
        return ['body' => false, 'code' => 0, 'errno' => -1, 'error' => 'cURL disabled'];
    }

    $exec = function(bool $verify_ssl) use ($url, $json_payload, $timeout) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(2, $timeout));
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $verify_ssl);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $verify_ssl ? 2 : 0);

        if ($json_payload !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json_payload);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json; charset=utf-8']);
        }

        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return ['body' => $body, 'code' => $code, 'errno' => $errno, 'error' => $error];
    };

    $res = $exec(true);
    if ($res['body'] === false && in_array($res['errno'], array(35, 51, 60, 77), true)) {
        $res = $exec(false);
    }
    return $res;
}

// 2. ПОЛНЫЙ МАССИВ НАПРАВЛЕНИЙ ХАБА (Для фильтрации постов в ленте)
$allowed_categories = [
    "Блоги", 
    "Маркет", 
    "Радио", 
    "Видео",
    "Бот", 
    "Игры",
    "Связь",
    "Разное"
];

// 3. АБСОЛЮТНЫЕ ПУТИ К ДИРЕКТОРИЯМ DATA
$DIR_SNYAT_POSTS  = __DIR__ . '/../data/snyat_posts/';
$DIR_RADIO_POSTS  = __DIR__ . '/../data/radio_posts/';
$DIR_RADIO_AUDIO  = __DIR__ . '/../media/audio/';
$DIR_VIDEO_POSTS  = __DIR__ . '/../data/video_posts/';
$DIR_MARKET_POSTS = __DIR__ . '/../data/market_posts/';
$DIR_BOT_POSTS    = __DIR__ . '/../data/bot_posts/';

if (!is_dir($DIR_SNYAT_POSTS))  @mkdir($DIR_SNYAT_POSTS, 0755, true);
if (!is_dir($DIR_RADIO_POSTS))  @mkdir($DIR_RADIO_POSTS, 0755, true);
if (!is_dir($DIR_RADIO_AUDIO))  @mkdir($DIR_RADIO_AUDIO, 0755, true);
if (!is_dir($DIR_VIDEO_POSTS))  @mkdir($DIR_VIDEO_POSTS, 0755, true);
if (!is_dir($DIR_MARKET_POSTS)) @mkdir($DIR_MARKET_POSTS, 0755, true);
if (!is_dir($DIR_BOT_POSTS))    @mkdir($DIR_BOT_POSTS, 0755, true);

// 🔥 ПОДКЛЮЧЕНИЕ ГЛОБАЛЬНОЙ JSON-МАТРИЦЫ НАСТРОЕК (Через атомарную блокировку)
$FILE_SETTINGS = __DIR__ . '/../data/app_settings.json';

$APP_SETTINGS = pig_json_update($FILE_SETTINGS, function($data) {
    $changed = false;
    if (empty($data)) {
        $data = [
            "landing_page"     => "aggregator",
            "theme_style"      => "pig_pink",
            "last_admin_login" => time(),
            "banners"          => [
                ["text" => "🚀 Добро пожаловать в Матрицу Творчества! — Доктора Шрам", "url" => "index.php?cat=rules"]
            ]
        ];
        $changed = true;
    }
    if (empty($data['privacy_salt'])) {
        $data['privacy_salt'] = bin2hex(random_bytes(16));
        $changed = true;
    }
    if (isset($_SESSION['username']) && $_SESSION['username'] === 'admin') {
        if (!isset($data['last_admin_login']) || (time() - $data['last_admin_login']) > 3600) {
            $data['last_admin_login'] = time();
            $changed = true;
        }
    }
    return $changed ? $data : null;
}, []);

if ($APP_SETTINGS === false) {
    $APP_SETTINGS = file_exists($FILE_SETTINGS) ? (json_decode(file_get_contents($FILE_SETTINGS), true) ?: []) : [];
}

// 🔥 ПОДКЛЮЧЕНИЕ СОБСТВЕННОЙ НЕЗАВИСИМОЙ PIG-МЕТРИКИ (Только для публичных страниц)
if (!defined('PIG_ADMIN_AREA')) {
    require_once __DIR__ . '/pig_metrika.php';
}

// Интеграция с сетью Хрюнлока (Отстук на хаб раз в 24 часа)
require_once __DIR__ . '/pig_net.php';

$last_ping = $APP_SETTINGS['last_ping_time'] ?? 0;
if ((time() - $last_ping) > 86400) {
    pingPigHub();
    pig_json_update($FILE_SETTINGS, function($data) {
        $data['last_ping_time'] = time();
        return $data;
    }, $APP_SETTINGS);
}
