<?php
/* 
 * 🐷 PIG-CMS — Конфигурация Ядра Экосистемы
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. НАСТРОЙКА ДОСТУПА ДЛЯ АДМИНКИ (Базовая авторизация)
$users = [
    'admin' => '1234',
    // [USERS_ANCHOR]
];

 // 2. ПОЛНЫЙ МАССИВ НАПРАВЛЕНИЙ ХАБА (Для фильтрации постов в ленте)
$allowed_categories = [
    "Блоги", 
    "Маркет", 
    "Радио", 
    "Видео",
    "Бот", 
    "Игры",
    "Связь",
    "Разное"
];

// 3. АБСОЛЮТНЫЕ ПУТИ К ДИРЕКТОРИЯМ DATA НА СЕРВЕРЕ MAJORDOMO
$DIR_SNYAT_POSTS  = __DIR__ . '/../data/snyat_posts/';
$DIR_RADIO_POSTS  = __DIR__ . '/../data/radio_posts/';
$DIR_RADIO_AUDIO  = __DIR__ . '/../media/audio/';
$DIR_VIDEO_POSTS  = __DIR__ . '/../data/video_posts/';
$DIR_MARKET_POSTS = __DIR__ . '/../data/market_posts/';
$DIR_BOT_POSTS    = __DIR__ . '/../data/bot_posts/'; // 🔥 Добавили путь

// Автоматический контроль и создание директорий на сервере
if (!is_dir($DIR_SNYAT_POSTS))  mkdir($DIR_SNYAT_POSTS, 0755, true);
if (!is_dir($DIR_RADIO_POSTS))  mkdir($DIR_RADIO_POSTS, 0755, true);
if (!is_dir($DIR_RADIO_AUDIO))  mkdir($DIR_RADIO_AUDIO, 0755, true);
if (!is_dir($DIR_VIDEO_POSTS))  mkdir($DIR_VIDEO_POSTS, 0755, true);
if (!is_dir($DIR_MARKET_POSTS)) mkdir($DIR_MARKET_POSTS, 0755, true);
if (!is_dir($DIR_BOT_POSTS))    mkdir($DIR_BOT_POSTS, 0755, true); // 🔥 Контроль папки

// 🔥 ПОДКЛЮЧЕНИЕ ГЛОБАЛЬНОЙ JSON-МАТРИЦЫ НАСТРОЕК
$FILE_SETTINGS = __DIR__ . '/../data/app_settings.json';

// Если файла нет, генерируем базовый дефолт
if (!file_exists($FILE_SETTINGS)) {
    $default_settings = [
        "landing_page" => "aggregator",
        "theme_style" => "pig_pink",
        "last_admin_login" => time(), 
        "banners" => [
            ["text" => "🚀 Добро пожаловать в Матрицу Творчества! — Доктора Шрам", "url" => "index.php?cat=rules"]
        ]
    ];
    file_put_contents($FILE_SETTINGS, json_encode($default_settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// Загружаем настройки, которые будут сквозным образом доступны на всем сайте
$APP_SETTINGS = json_decode(file_get_contents($FILE_SETTINGS), true);

// 🎮 ИГРОВАЯ МЕХАНИКА: Фиксируем активность админа
if (isset($_SESSION['user']) && $_SESSION['user'] === 'admin') {
    if (!isset($APP_SETTINGS['last_admin_login']) || (time() - $APP_SETTINGS['last_admin_login']) > 3600) {
        $APP_SETTINGS['last_admin_login'] = time();
        file_put_contents($FILE_SETTINGS, json_encode($APP_SETTINGS, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
}

// 🔥 ПОДКЛЮЧЕНИЕ СОБСТВЕННОЙ НЕЗАВИСИМОЙ PIG-МЕТРИКИ
require_once __DIR__ . '/pig_metrika.php';

// Интеграция с сетью Хрюнлока (Отстук на хаб раз в 24 часа)
require_once __DIR__ . '/pig_net.php';

$app_settings_file = __DIR__ . '/../data/app_settings.json';
if (file_exists($app_settings_file)) {
    $settings = json_decode(file_get_contents($app_settings_file), true);
    $last_ping = isset($settings['last_ping_time']) ? $settings['last_ping_time'] : 0;
    
    if ((time() - $last_ping) > 86400) {
        pingPigHub(); 
        $settings['last_ping_time'] = time();
        file_put_contents($app_settings_file, json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
}
