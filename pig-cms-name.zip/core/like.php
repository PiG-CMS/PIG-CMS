<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/config.php';

$user_ip = $_SERVER['REMOTE_ADDR'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['post_id'])) {
    $post_id = trim($_POST['post_id']);
    $file_path = $DIR_SNYAT_POSTS . $post_id . '.json';

    if (file_exists($file_path)) {
        $p = json_decode(file_get_contents($file_path), true);
        if ($p) {
            if (!isset($p['likes_ip'])) $p['likes_ip'] = [];
            
            $allowed_actions = ['like_fire', 'like_show', 'like_useful', 'like_heart', 'like_ok'];
            if (in_array($_POST['action'], $allowed_actions)) {
                if (!in_array($user_ip, $p['likes_ip'])) {
                    $p['likes_ip'][] = $user_ip;
                    $p[$_POST['action']] = (isset($p[$_POST['action']]) ? $p[$_POST['action']] : 0) + 1;
                    file_put_contents($file_path, json_encode($p, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
                }
            }
        }
    }
    // Мгновенный красивый возврат обратно на страницу просмотра поста
    header("Location: ../index.php?view=" . $post_id);
    exit;
}
header("Location: ../index.php");
exit;
