<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/config.php';

$salt = $APP_SETTINGS['privacy_salt'] ?? 'pig_like_salt';
$user_hash = substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') . $salt), 0, 24);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['post_id'])) {
    $post_id = preg_replace('/[^a-zA-Z0-9_-]/', '', trim($_POST['post_id']));
    $action = $_POST['action'];
    $file_path = $DIR_SNYAT_POSTS . $post_id . '.json';

    $allowed_actions = ['like_fire', 'like_show', 'like_useful', 'like_heart', 'like_ok'];
    if ($post_id !== '' && file_exists($file_path) && in_array($action, $allowed_actions, true)) {
        pig_json_update($file_path, function($p) use ($user_hash, $action) {
            if (empty($p)) return null;
            if (!isset($p['likes_ip'])) $p['likes_ip'] = [];
            if (in_array($user_hash, $p['likes_ip'], true)) return null;

            $p['likes_ip'][] = $user_hash;
            $p[$action] = (isset($p[$action]) ? (int)$p[$action] : 0) + 1;
            return $p;
        }, null);
    }
    header("Location: ../index.php?view=" . urlencode($post_id));
    exit;
}
header("Location: ../index.php");
exit;
