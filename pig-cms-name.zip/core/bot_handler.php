<?php
/* 
 * 🐷 PIG-CMS — Обработчик ИИ-ответов чат-бота «Эволюция»
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 pig-cms.name & Доктор Шрам
 */

header('Content-Type: application/json; charset=utf-8');

$inputData = file_get_contents('php://input');
$userData = json_decode($inputData, true);
$question = isset($userData['question']) ? trim($userData['question']) : '';

if (empty($question)) {
    echo json_encode(["answer" => "Я внимательно слушаю твой сигнал. Задай вопрос по существу."], JSON_UNESCAPED_UNICODE);
    exit;
}

$cleanQuestion = mb_strtolower($question, 'UTF-8');

// Смотрим строго в изолированную директорию
$matrixFile = __DIR__ . '/../data/bot_posts/bot_matrix.json';
$botResponse = "Интересный сигнал... Моя матрица знаний пока не содержит ответа на этот вопрос. Попробуй спросить иначе или обратись к Администратору напрямую.";

if (file_exists($matrixFile)) {
    $matrixData = json_decode(file_get_contents($matrixFile), true);
    
    if (is_array($matrixData)) {
        foreach ($matrixData as $item) {
            if (isset($item['question']) && isset($item['answer'])) {
                $targetQuestion = mb_strtolower(trim($item['question']), 'UTF-8');
                
                // Проверяем точное совпадение или вхождение фразы
                if ($cleanQuestion === $targetQuestion || mb_strpos($cleanQuestion, $targetQuestion) !== false) {
                    $botResponse = $item['answer'];
                    break;
                }
            }
        }
    }
} else {
    $botResponse = "Системное уведомление: База знаний бота (data/bot_posts/bot_matrix.json) не найдена на сервере.";
}

echo json_encode(["answer" => $botResponse], JSON_UNESCAPED_UNICODE);
exit;
