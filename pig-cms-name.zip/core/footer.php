<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */
?>
    <!-- ======================================================== -->
    <!-- 🔥 ДИНАМИЧЕСКИЙ РОТАТОР БАННЕРОВ PIG-CMS                 -->
    <!-- ======================================================== -->
    <div class="pig-banner-zone" style="margin: 40px auto 20px auto; text-align: center; max-width: 728px; width: 100%;">
        <?php 
        // Проверяем, есть ли баннеры в глобальном массиве настроек Хаба
        if (!empty($APP_SETTINGS['banners']) && is_array($APP_SETTINGS['banners'])): 
            // Извлекаем случайный баннер для ротации при обновлении страницы
            $random_banner = $APP_SETTINGS['banners'][array_rand($APP_SETTINGS['banners'])];
            $b_text = htmlspecialchars($random_banner['text']);
            $b_url  = htmlspecialchars($random_banner['url']);
        else:
            // Резервный дефолтный вариант на случай пустого JSON
            $b_text = "🚀 Добро пожаловать в Матрицу Творчества! Присоединяйся к нашему клубу авторов →";
            $b_url  = "index.php?cat=rules";
        endif; 
        ?>
        <a href="<?php echo $b_url; ?>" style="text-decoration: none; display: inline-block; padding: 15px; background: #222; border: 1px dashed #007bff; border-radius: 6px; color: #ffc107; font-weight: bold; width: 100%; transition: border-color 0.2s;">
            <?php echo $b_text; ?>
        </a>
    </div>
    <!-- ======================================================== -->

    <footer>
        <p>© <?php echo date('Y'); ?> PIG-CMS <br></p>

        <!-- 🌐 ЧИСТЫЙ СУВЕРЕННЫЙ ПОДВАЛ БЕЗ РЕЕСТРОВ -->
        <p style="font-size: 11px; color: #666; margin-top: 10px; font-family: monospace; text-transform: uppercase; letter-spacing: 0.5px;">
            Powered by <a href="<?php echo $root_url; ?>index.php" style="color: #ffb703; font-weight: bold; text-decoration: none;">PIG-CMS</a> | Децентрализованная сеть авторов
        </p>
    </footer>
</div> <!-- /wrapper -->

<!-- сюда счетчик вставить-->

<!-- конец счетчика -->

<?php
// 📡 АВТО-ПИНГ ГАЛАКТИКИ PIG-NET (Раз в 10 минут при посещении сайта)
$pig_net_file = __DIR__ . '/pig_net.php';
if (file_exists($pig_net_file)) {
    $ping_cache = __DIR__ . '/../data/last_hub_ping.txt';
    $last_ping_time = file_exists($ping_cache) ? intval(file_get_contents($ping_cache)) : 0;
    if (time() - $last_ping_time > 600) {
        @file_put_contents($ping_cache, time());
        include_once $pig_net_file;
        if (function_exists('pingPigHub')) {
            pingPigHub();
        }
    }
}
?>
</body>
</html>
