<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

// 📡 1. ЛОКАЛЬНЫЙ ПРОКСИ ДЛЯ СПИСКА СТАНЦИЙ (Строго в самом верху, до любого вывода!)
if (isset($_GET['action']) && $_GET['action'] === 'get_galaxy_stations') {
    if (ob_get_length()) ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    
    $json = false;
    if (function_exists('curl_init')) {
        $hub_endpoint = 'https://' . 'pig-cms.name' . '/api/radio_list.php';
        $fetch = function(bool $verify_ssl) use ($hub_endpoint) {
            $ch = curl_init($hub_endpoint);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $verify_ssl);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $verify_ssl ? 2 : 0);
            $res = curl_exec($ch);
            $err = curl_errno($ch);
            curl_close($ch);
            return [$res, $err];
        };
        list($json, $errno) = $fetch(true);
        if ($json === false && in_array($errno, array(35, 51, 60, 77), true)) {
            list($json, ) = $fetch(false);
        }
    }
    
    if ($json && substr(trim($json), 0, 1) === '[') {
        echo $json;
    } else {
        echo json_encode([
            ['name' => 'Радио PIG-CMS', 'url' => 'https://pig-cms.name']
        ], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

require_once __DIR__ . '/core/config.php';


// 📡 2. ГАЛАКТИЧЕСКИЙ ШЛЮЗ РАДИО: Отдача плейлиста другим планетам PIG-NET
if (isset($_GET['action']) && $_GET['action'] === 'galaxy_stream') {
    if (ob_get_length()) ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    
    $galaxy_cfg_file = __DIR__ . '/data/radio_galaxy.json';
    $galaxy_cfg = file_exists($galaxy_cfg_file) ? json_decode(file_get_contents($galaxy_cfg_file), true) : ['allow_broadcast' => false];
    
    if (empty($galaxy_cfg['allow_broadcast'])) {
        echo json_encode(['status' => 'forbidden', 'message' => 'Админ этой планеты запретил внешнее вещание.']);
        exit;
    }

    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
    $base_url = $protocol . "://" . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/';
    
    $stream_tracks = [];
    $files = glob($DIR_RADIO_POSTS . "*.json");
    if (!empty($files)) {
        array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
        foreach ($files as $file) {
            $p = json_decode(file_get_contents($file), true);
            if ($p && !empty($p['audio_tracks'][0])) {
                $stream_tracks[] = [
                    'id'    => basename($file, '.json'),
                    'title' => ($p['title'] ?? 'Трек') . ' — ' . ($APP_SETTINGS['site_title'] ?? $_SERVER['HTTP_HOST']),
                    'src'   => $base_url . 'media/audio/' . $p['audio_tracks'][0]
                ];
            }
        }
    }
    
    echo json_encode([
        'status'  => 'ok',
        'station' => $APP_SETTINGS['site_title'] ?? $_SERVER['HTTP_HOST'],
        'tracks'  => $stream_tracks
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 🔥 ВЫТАСКИВАЕМ СУВЕРЕННЫЙ БРЕНД ИЗ МАТРИЦЫ НАСТРОЕК
$site_brand = htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS');

$view_single = isset($_GET['view']) ? trim($_GET['view']) : '';
$page_title = "Радио PiG CMS тексты и музыка в эфире" . $site_brand; 
$posts_data = [];

$files = glob($DIR_RADIO_POSTS . "*.json");
if (!empty($files)) {
    array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
    foreach ($files as $file) {
        $basename = basename($file, '.json'); 
        if (!empty($view_single) && $basename !== $view_single) continue;
        $p = json_decode(file_get_contents($file), true);
        if ($p) { 
            $p['id'] = $basename; 
            $posts_data[] = $p; 
        }
    }
}

if (!empty($view_single) && !empty($posts_data)) {
    $post = $posts_data[0]; 
    $page_title = "Текст и трек «" . htmlspecialchars($post['title'] ?? 'Без названия') . "» — " . $site_brand;
    if (!empty($post['meta_description'])) { 
        $meta_description = $post['meta_description']; 
    } else {
        $text_for_meta = (string)($post['lyrics'] ?? $post['description'] ?? '');
        $clean_text = strip_tags($text_for_meta); 
        $meta_description = mb_substr(str_replace(["\r", "\n", "\t"], " ", $clean_text), 0, 160, 'UTF-8') . "...";
    }
} else { 
    $meta_description = "Слушать треки онлайн и читать тексты произведений на платформе."; 
}

$is_radio_page = true;
$hub_title = "Паросёнок";
$hub_subtitle = "Произведения в текстовом и музыкальном формате";

include_once __DIR__ . '/core/header.php';
?>

    <?php if (!empty($view_single) && !empty($posts_data)): ?>
        <div style="text-align:center; margin-bottom:20px;">
            <a href="radio.php" style="color:#007bff; font-weight:bold; text-decoration:none;">← Вернуться к списку</a>
        </div>
        <h2>Слушать трек «<?php echo htmlspecialchars($post['title'] ?? 'Без названия'); ?>» онлайн</h2>

        <div class="player-box">
            <?php if (isset($post['audio_tracks']) && is_array($post['audio_tracks'])): ?>
                <?php foreach ($post['audio_tracks'] as $idx => $t_file): ?>
                    <div class="player-title" style="<?php echo $idx > 0 ? 'margin-top:15px;' : ''; ?>">Вариант #<?php echo ($idx+1); ?>:</div>
                    <audio controls src="media/audio/<?php echo htmlspecialchars($t_file); ?>"></audio>
                <?php endforeach; ?>
            <?php elseif (!empty($post['audio_url'])): ?>
                <div class="player-title">Слушать трек:</div>
                <audio controls src="<?php echo htmlspecialchars($post['audio_url']); ?>"></audio>
            <?php endif; ?>
        </div>

        <?php $tracks = isset($post['audio_tracks']) ? $post['audio_tracks'] : []; ?>
        <?php if (count($tracks) > 1): ?>
            <div class="vote-box">
                <h4>Какой вариант исполнения ИИ вам нравится больше?</h4>
                <div style="display:flex; justify-content:center; gap:10px; flex-wrap:wrap;">
                    <?php foreach ($tracks as $index => $t_file): $v_num = $index + 1; $v_count = isset($post['votes_'.$v_num]) ? intval($post['votes_'.$v_num]) : 0; ?>
                        <button id="voteBtn<?php echo $v_num; ?>" onclick="sendVote('<?php echo $post['id']; ?>', <?php echo $v_num; ?>)" class="vote-action-btn">
                            👍 Вариант #<?php echo $v_num; ?> (<span id="vCount<?php echo $v_num; ?>"><?php echo $v_count; ?></span>)
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="controls" style="margin:15px 0; text-align:center;">
            <input type="text" id="trackShareLink" value="https://<?php echo $_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'].'?view='.$post['id']; ?>" readonly style="position:absolute; left:-9999px;">
            <button onclick="copyTrackLink()" class="share-btn">🔗 Поделиться этим треком</button>
        </div>

        <div class="lyrics-container">
            <h3>Текст песни / стихотворения:</h3>
            <div class="lyrics-text"><?php echo nl2br(htmlspecialchars($post['lyrics'] ?? $post['description'] ?? '')); ?></div>
        </div>

    <?php else: ?>
        <div class="player-box">
            <p id="radio-status">Готов к запуску радио-потока</p>
            <audio id="shram-radio" controls></audio>
    
            <!-- Кнопка Галактического Эфира -->
            <div style="margin-top: 12px; padding-top: 12px; border-top: 1px dashed #444;">
                <button id="galaxy-radio-btn" onclick="toggleGalaxyRadio()" style="padding: 8px 15px; background: #16161e; color: #00ff66; border: 1px solid #00ff66; border-radius: 4px; cursor: pointer; font-family: monospace; font-weight: bold;">
                    📡 ПОЙМАТЬ ВОЛНУ ГАЛАКТИКИ
                </button>
              <button id="clear-radio-cache-btn" onclick="resetRadioCache()" style="padding: 8px 12px; background: #222; color: #ffb703; border: 1px solid #ffb703; border-radius: 4px; cursor: pointer; font-family: monospace; font-size: 12px; margin-left: 6px;">
    🔄 СБРОС КЕША
</button>
              
                <div id="galaxy-stations-box" style="display: none; margin-top: 10px; text-align: left; background: #1a1a1a; padding: 10px; border-radius: 4px; font-size: 13px;">
                    <div style="color: #aaa; margin-bottom: 6px;">Доступные радиовышки Квадранта:</div>
                    <div id="galaxy-stations-list">Сканирование эфира...</div>
                </div>
            </div>
        </div>
          
        <h2>Доступные произведения:</h2>
        <div class="songs-list">
            <?php if (!empty($posts_data)): foreach ($posts_data as $p): ?>
                <div class="song-item"><a href="?view=<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['title'] ?? 'Без названия'); ?></a></div>
            <?php endforeach; else: ?><p>Треков пока нет.</p><?php endif; ?>
        </div>
    <?php endif; ?>

<script>
// Генерируем компактный JSON-плейлист для внешнего JS-движка
var radioPlaylist = [
    <?php if(!empty($posts_data)){ foreach($posts_data as $p){
        $f_name = '';
        if (isset($p['audio_tracks']) && is_array($p['audio_tracks']) && !empty($p['audio_tracks'][0])) {
            $f_name = "media/audio/" . $p['audio_tracks'][0];
        } elseif (isset($p['audio_url'])) {
            $f_name = $p['audio_url'];
        }
        if(!empty($f_name)){ echo "{id:'".addslashes($p['id'])."',title:'".addslashes($p['title'] ?? 'Без названия')."',src:'".addslashes($f_name)."'},"; }
    }} ?>
];
</script>
<script src="assets/js/radio.js?v=<?php echo filemtime(__DIR__ . '/assets/js/radio.js'); ?>"></script>


<?php 
include_once __DIR__ . '/core/footer.php'; 
?>
