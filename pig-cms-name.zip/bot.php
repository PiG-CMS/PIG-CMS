<?php
/* 
 * 🐷 PIG-CMS — Чат-бот Эволюция (Полная изоляция от тем)
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 pig-cms.name & Доктор Шрам
 */

// 🔥 ВЫШЕ ВСЕГО: Если чат вызван внутри iframe, отдаем чистую, фиксированную верстку
if (isset($_GET['frame_mode']) && $_GET['frame_mode'] === '1') {
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>Чат-бот Эволюция</title>
        <style>
            html, body { background: #111111 !important; color: #ffffff !important; font-family: monospace; margin: 0; padding: 5px; box-sizing: border-box; width: 100%; height: 100%; overflow: hidden; }
            /* 🔥 ФИКС ВЫСОТЫ: Жестко фиксируем высоту окна сообщений в 300px с автоскроллом */
            #bot-chat-window { background: #050505 !important; border: 1px solid #444 !important; border-radius: 6px; padding: 15px; height: 300px; margin-bottom: 12px; font-size: 13px; line-height: 1.5; overflow-y: auto; color: #fff !important; box-sizing: border-box; }
            input { width: 100%; padding: 12px; background: #222222 !important; border: 1px solid #555 !important; color: #fff !important; border-radius: 4px; margin-bottom: 12px; box-sizing: border-box; font-family: monospace; font-size: 14px; }
            button { width: 100%; padding: 12px; background: #ffb703 !important; color: #111 !important; border: none !important; font-weight: bold; cursor: pointer; border-radius: 4px; text-transform: uppercase; font-size: 12px; font-family: monospace; letter-spacing: 0.5px; }
            button:hover { background: #fcaf00 !important; }
        </style>
    </head>
    <body>
    <div style="max-width: 580px; margin: 0 auto; background: #1e1e1e; border: 1px solid #333; border-radius: 8px; padding: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); box-sizing: border-box;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 12px; font-size: 12px; border-bottom: 1px solid #2d2d2d; padding-bottom: 8px;">
            <span style="color: #ffb703; font-weight: bold;">🤖 ОБУЧАЕМЫЙ ЧАТ-БОТ</span>
            <span style="color: #888;">ИИ-Ассистент</span>
        </div>
        
        <div id="bot-chat-window">
            <div style="color: #666; font-style: italic; text-align: center; margin-top: 100px;">Система готова. Введите ваш вопрос ниже...</div>
        </div>
        
        <input type="text" id="guest-question" placeholder="Например: pig-net или пароль" autocomplete="off">
        <button type="button" id="send-btn">Отправить вопрос боту 🚀</button>
    </div>

    <script>
    document.getElementById('send-btn').addEventListener('click', sendQuestion);
    document.getElementById('guest-question').addEventListener('keypress', function(e) { if (e.key === 'Enter') sendQuestion(); });

    function sendQuestion() {
        const input = document.getElementById('guest-question');
        const qText = input.value.trim();
        if (!qText) return;
        const chatWindow = document.getElementById('bot-chat-window');
        if(chatWindow.innerHTML.includes("Система готова")) { chatWindow.innerHTML = ""; }
        chatWindow.innerHTML += `<div style="margin-bottom:12px;text-align:right;"><span style="background:#3e444c;color:#fff;padding:6px 12px;border-radius:12px 12px 0 12px;display:inline-block;max-width:80%;"><b>Вы:</b> ${escapeHtml(qText)}</span></div>`;
        input.value = '';
        chatWindow.scrollTop = chatWindow.scrollHeight;
        
        fetch('core/bot_handler.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: qText }) })
        .then(res => res.json())
        .then(data => {
            chatWindow.innerHTML += `<div style="margin-bottom:12px;text-align:left;"><span style="background:#242424;border:1px solid #ffb703;color:#ffe082;padding:8px 12px;border-radius:12px 12px 12px 0;display:inline-block;max-width:80%;"><b>Эволюция:</b> ${data.answer}</span></div>`;
            chatWindow.scrollTop = chatWindow.scrollHeight;
        })
        .catch(() => {
            chatWindow.innerHTML += `<div style="color:#d9534f;margin-top:5px;font-size:11px;">⚠️ Ошибка связи с ботом. Обработчик core/bot_handler.php не отвечает.</div>`;
        });
    }
    function escapeHtml(text) { return text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;"); }
    </script>
    </body>
    </html>
    <?php
    exit; // Полностью отсекаем внешнюю разметку CMS во фрейме
}

// =====================================================
// ОСНОВНОЙ РЕЖИМ: Стандартный вывод страницы хаба со встроенным фреймом чата
// =====================================================
require_once __DIR__ . '/core/config.php';
$page_title = "Чат-бот Эволюция — База знаний PIG-CMS";
require_once __DIR__ . '/core/header.php';
?>

<div style="width: 100%; min-height: 70vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px 0; box-sizing: border-box;">
    <h2 style="text-align: center; color: #ffb703; font-size: 22px; text-transform: uppercase; margin-bottom: 5px; letter-spacing: 0.5px;">Спроси бота «Эволюция»</h2>
    <p style="color: #bbb; font-size: 13px; text-align: center; margin-bottom: 20px; max-width: 500px; line-height: 1.4; font-family: monospace;">
        Задай свой вопрос платформе, чтобы получить мгновенный ответ из суверенной матрицы знаний PIG-CMS.
    </p>
    
    <!-- 🔥 ФИКС ДЛЯ СМАРТФОНОВ: Выставили высоту фрейма в 510px, теперь ничего не уезжает вниз -->
    <iframe src="bot.php?frame_mode=1" style="width: 100%; max-width: 600px; height: 510px; border: none; background: transparent; overflow: hidden;" scrolling="no"></iframe>
</div>

<?php 
require_once __DIR__ . '/core/footer.php'; 
?>
