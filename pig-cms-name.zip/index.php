<?php
/* 
 * 🐷 PIG-CMS — Главный Переключатель Хаба (Часть 1)
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

require_once __DIR__ . '/core/config.php';

// Путь к файловой базе постов портфолио
$DIR_SNYAT_POSTS = __DIR__ . '/data/snyat_posts/';

// Переключение режимов отображения сетки через Top-Bar или Cookie
if (isset($_GET['set_view'])) {
    $view_type = trim($_GET['set_view']);
    setcookie('pig_view', $view_type, time() + (86400 * 30), "/");
    header("Location: index.php" . (isset($_GET['cat']) ? "?cat=".urlencode($_GET['cat']) : ""));
    exit;
}
$current_view = $_COOKIE['pig_view'] ?? 'grid';

// Сбор данных из JSON-файлов модулей
$files = is_dir($DIR_SNYAT_POSTS) ? glob($DIR_SNYAT_POSTS . "*.json") : [];
$posts_data = [];
$view_single = isset($_GET['view']) ? trim($_GET['view']) : '';
$current_author = isset($_GET['author']) ? trim($_GET['author']) : null;
$current_cat = isset($_GET['cat']) ? trim($_GET['cat']) : 'all';

$all_authors = [];

if (!empty($files)) {
    // Сортируем публикации по дате изменения (сначала новые)
    array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
    foreach ($files as $file) {
        $basename = basename($file, '.json');
        $p = json_decode(file_get_contents($file), true);
        if ($p) {
            $p['id'] = $basename;
            
            // Накапливаем авторов и их метаданные для режима 'blogs'
            if (!empty($p['author'])) {
                $a_name = $p['author'];
                if (!isset($all_authors[$a_name])) {
                    $all_authors[$a_name] = ['count' => 0, 'img' => $p['img_url'] ?? ''];
                }
                $all_authors[$a_name]['count']++;
            }

            // Накладываем фильтры выборки
            if (!empty($view_single) && $basename !== $view_single) continue;
            if ($current_author && (!isset($p['author']) || $p['author'] !== $current_author)) continue;
            if ($current_cat !== 'all' && (!isset($p['category']) || $p['category'] !== $current_cat)) continue;
            $posts_data[] = $p;
        }
    }
}

// Проверка: открыт ли детальный просмотр одной работы
$is_single_view = !empty($view_single) && !empty($posts_data);
// 🔥 ФИКС ОШИБКИ: Вытаскиваем конкретный первый элемент массива для детального просмотра
$single_post = $is_single_view ? $posts_data[0] : null;

// Динамические заголовки страниц (Суверенный вывод PIG-CMS)
$site_brand  = htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS');
$site_slogan = htmlspecialchars($APP_SETTINGS['site_slogan'] ?? 'Хаб децентрализованной экосистемы');

$page_title = $site_brand . " — " . $site_slogan;

if ($is_single_view) {
    $page_title = htmlspecialchars($single_post['title'] ?? 'Пост') . " — " . $site_brand;
}

if ($current_cat === 'rules') {
    $page_title = "Правила платформы — " . $site_brand;
}

include_once __DIR__ . '/core/header.php';
?>

<!-- ============ БЛОК ТЕМАТИЧЕСКИХ ХЭШТЕГОВ / КАТЕГОРИЙ ========== -->
<?php if (!$is_single_view && $current_cat !== 'rules'): ?>
    <div class="main-page-topics">
        <div class="category-menu menu-categories">
            <!-- Кнопка сброса фильтра -->
            <a href="index.php" class="<?php echo (!isset($_GET['cat']) || $_GET['cat'] === 'all') ? 'active' : ''; ?>"> ✨ Все темы</a>
            
            <!-- Выводим ВСЕ категории из твоего конфига core/config.php -->
            <?php foreach ($allowed_categories as $cat): ?>
                <a href="index.php?cat=<?php echo urlencode($cat); ?>" class="<?php echo (isset($_GET['cat']) && $_GET['cat'] === $cat) ? 'active' : ''; ?>"> #️ <?php echo htmlspecialchars($cat); ?></a>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<?php if ($current_author): ?>
    <div class="info-author" style="margin: 15px; font-family: monospace;">
        🚀 Автор: @<?php echo htmlspecialchars($current_author); ?> | <a href="index.php" style="color:#fff;">Сбросить фильтр</a>
    </div>
<?php endif; ?>


<!-- ========= ШАБЛОН 1: ДЕТАЛЬНЫЙ ПРОСМОТР ПОСТА ========= -->
<?php if ($is_single_view): $post = $single_post; ?>
    <div style="text-align:center; margin-bottom:25px;"><a href="index.php" style="color:#007bff; font-weight:bold; text-decoration:none; font-family:monospace;">← Назад в ленту</a></div>
    <div class="single-post-wrap">
        <img src="<?php echo htmlspecialchars($post['img_url'] ?? ''); ?>" alt="<?php echo htmlspecialchars($post['title'] ?? 'Пост'); ?>">
        <div class="single-post-title"><?php echo htmlspecialchars($post['title'] ?? 'Без названия'); ?></div>
        <div class="single-post-meta">Категория: <b><?php echo htmlspecialchars($post['category'] ?? 'Общее'); ?></b> | Автор: <a href="index.php?author=<?php echo urlencode($post['author'] ?? 'Admin'); ?>">@<?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></a></div>
        <div class="single-post-desc" style="white-space: pre-wrap;"><?php echo nl2br(htmlspecialchars($post['description'] ?? '')); ?></div>
        <div style="text-align: center; margin: 30px 0;"><a href="<?php echo htmlspecialchars($post['target_url'] ?? '#'); ?>" target="_blank" class="react-btn" style="background:#28a745; text-decoration:none; padding:12px 25px; display:inline-block;">🌐 Открыть портфолио автора →</a></div>
        
        <div class="reactions-bar">
            <?php foreach(['like_useful'=>'👍 Класс', 'like_fire'=>'🔥 Огонь', 'like_show'=>'👀 Смотрю', 'like_heart'=>'❤️ Топ', 'like_ok'=>'👌 Зачёт'] as $key => $label): ?>
                <form method="POST" action="core/like.php" style="margin:0; display:inline;"><input type="hidden" name="action" value="<?php echo $key; ?>"><input type="hidden" name="post_id" value="<?php echo $post['id']; ?>"><button type="submit" class="react-btn"><?php echo $label; ?> (<?php echo $post[$key] ?? 0; ?>)</button></form>
            <?php endforeach; ?>
        </div>
    </div>
    <div style="text-align: center; margin-top: 20px;">
        <input type="text" id="trackShareLink" value="https://<?php echo $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>" readonly style="position:absolute; left:-9999px;">
        <button onclick="copyTrackLink()" class="react-btn" style="background:#007bff;">🔗 Поделиться работой</button>
    </div>

<!-- ==================== ШАБЛОН 2: ПРАВИЛА ХАБА ==================== -->
<?php elseif ($current_cat === 'rules'): ?>
    <?php include_once __DIR__ . '/core/rules.php'; ?>

<!-- ==================== ШАБЛОН 3: СПИСОК БЛОГОВ / АВТОРОВ ==================== -->
<?php elseif ($current_view === 'blogs'): ?>
    <div class="blogs-container" style="padding: 15px; display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 20px; font-family: monospace;">
        <?php if (!empty($all_authors)): foreach ($all_authors as $author_name => $meta): ?>
            <div class="blog-card" style="background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 20px; text-align: center;">
                <div class="blog-avatar" style="width: 80px; height: 80px; margin: 0 auto 15px; border-radius: 50%; overflow: hidden; background: #2d2d2d; border: 2px solid #9b59b6;">
                    <?php if(!empty($meta['img'])): ?>
                        <img src="<?php echo htmlspecialchars($meta['img']); ?>" style="width:100%; height:100%; object-fit:cover;">
                    <?php endif; ?>
                </div>
                <h3 style="margin: 10px 0 5px 0; font-size:16px;">
                    <a href="index.php?author=<?php echo urlencode($author_name); ?>" style="color: #e0b0ff; text-decoration: none;">@<?php echo htmlspecialchars($author_name); ?></a>
                </h3>
                <p style="color: #666; font-size: 12px; margin-bottom: 15px;">Работ в хабе: <b style="color:#fff;"><?php echo $meta['count']; ?></b></p>
                <a href="index.php?author=<?php echo urlencode($author_name); ?>" style="display: block; background: #9b59b6; color: #fff; padding: 6px; text-decoration: none; font-size: 13px; border-radius: 4px; font-weight:bold;">Открыть blog</a>
            </div>
        <?php endforeach; else: ?><p style="text-align:center; width:100%;">Авторов пока нет.</p><?php endif; ?>
    </div>
<!-- ==================== ШАБЛОН 4: ГЛАВНАЯ СТРАНИЦА (УМНЫЙ ВЫБОР) ==================== -->
<?php else: ?>
    <?php 
    // Считываем тип главной из настроек JSON ($APP_SETTINGS объявлен в core/config.php)
    $landing_type = $APP_SETTINGS['landing_page'] ?? 'aggregator';
    
    // Если в конфиге активен агрегатор новостей всей сети И нет активных фильтров — подключаем модули
    if ($landing_type === 'aggregator' && $current_cat === 'all' && !$current_author && !isset($_GET['page'])): 
    ?>
        <!-- 🔥 МОДУЛЬНЫЙ АГРЕГАТОР ВСЕЙ СЕТИ PIG-NET -->
        <?php include_once __DIR__ . '/core/main_aggregator.php'; ?>
        
    <?php else: ?>
        <!-- СТАНДАРТНАЯ СЕТКА БЛОГОВ / ПОРТФОЛИО (ЕСЛИ ВКЛЮЧЕН РЕЖИМ GRID ИЛИ СРАБОТАЛ ФИЛЬТР) -->
        <?php 
        $per_page = 12; 
        $total_posts = count($posts_data); 
        $total_pages = ceil($total_posts / $per_page);
        $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $sliced_posts = array_slice($posts_data, (($current_page < 1 ? 1 : $current_page) - 1) * $per_page, $per_page);
        ?>
        <div class="grid-container">
            <?php if (!empty($sliced_posts)): foreach ($sliced_posts as $post): ?>
                <div class="card">
                    <a href="index.php?view=<?php echo $post['id']; ?>" class="card-link"><img src="<?php echo htmlspecialchars($post['img_url'] ?? ''); ?>"><span class="card-title"><?php echo htmlspecialchars($post['title'] ?? 'Без названия'); ?></span></a>
                    <div class="meta-author" style="padding:0 12px;">Автор: <a href="index.php?author=<?php echo urlencode($post['author'] ?? 'Admin'); ?>">@<?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></a></div>
                    <div class="card-desc"><?php $s = strip_tags($post['description'] ?? ''); echo (mb_strlen($s,'UTF-8')>100)?mb_substr($s,0,100,'UTF-8').'...':$s; ?></div>
                    <div style="background:#1f1f1f; padding:8px 12px; font-size:12px; display:flex; justify-content:space-between;">
                        <span>👍 <?php echo $post['like_useful'] ?? 0; ?></span><span>🔥 <?php echo $post['like_fire'] ?? 0; ?></span><span>👀 <?php echo $post['like_show'] ?? 0; ?></span><span>❤️ <?php echo $post['like_heart'] ?? 0; ?></span><span>👌 <?php echo $post['like_ok'] ?? 0; ?></span>
                    </div>
                </div>
            <?php endforeach; else: ?><p style="text-align:center; grid-column:1/-1;">Публикаций пока нет.</p><?php endif; ?>
        </div>
        
        <?php if ($total_pages > 1): ?>
            <div class="pagination" style="text-align:center; margin:20px; display:flex; justify-content:center; gap:10px;">
                <a href="index.php?page=<?php echo max(1, $current_page-1); ?>" style="color:#fff; background:#2d2d2d; padding:8px 15px; text-decoration:none; border-radius:5px;">← Назад</a>
                <span style="color:#aaa; padding:8px 0;">Страница <?php echo $current_page; ?> из <?php echo $total_pages; ?></span>
                <a href="index.php?page=<?php echo min($total_pages, $current_page+1); ?>" style="color:#fff; background:#2d2d2d; padding:8px 15px; text-decoration:none; border-radius:5px;">Вперед →</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>

<script src="assets/js/snyat.js"></script>
<?php 
include_once __DIR__ . '/core/footer.php'; 
?>
