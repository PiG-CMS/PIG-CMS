/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

let lastScrollTop = 0;
const header = document.getElementById('mainHeader');

window.addEventListener('scroll', function() {
    let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    if (scrollTop > lastScrollTop && scrollTop > 100) {
        if (header) header.classList.add('header-hidden');
    } else {
        if (header) header.classList.remove('header-hidden');
    }
    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});

function openModal() { document.getElementById('orderModal').style.display = 'flex'; }
function closeModal() { document.getElementById('orderModal').style.display = 'none'; }
window.onclick = function(event) {
    let modal = document.getElementById('orderModal');
    if (event.target == modal) { modal.style.display = 'none'; }
}

function sharePost(title, url) {
    if (navigator.share) { 
        navigator.share({ title: title, url: url }).catch(console.error); 
    } else { 
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function() {
                alert("Ссылка скопирована в буфер обмена! 📢\nТема: " + title);
            }).catch(function() {
                fallbackCopy(url, title);
            });
        } else {
            fallbackCopy(url, title);
        }
    }
}

function fallbackCopy(text, title) {
    var textArea = document.createElement("textarea");
    textArea.value = text; 
    textArea.style.position = "fixed";
    textArea.style.top = "0"; textArea.style.left = "0";
    textArea.style.width = "2em"; textArea.style.height = "2em";
    textArea.style.padding = "0"; textArea.style.border = "none";
    textArea.style.outline = "none"; textArea.style.boxShadow = "none";
    textArea.style.background = "transparent";
    
    document.body.appendChild(textArea);
    textArea.focus(); textArea.select();
    
    try {
        var successful = document.execCommand('copy');
        if (successful) {
            alert("Ссылка скопирована автоматически! 📢\nЗаголовок: " + title);
        } else {
            prompt("Браузер заблокировал автокопирование. Нажмите Ctrl+C:", text);
        }
    } catch (err) {
        prompt("Не удалось скопировать. Скопируйте отсюда (Ctrl+C):", text);
    }
    document.body.removeChild(textArea);
}
