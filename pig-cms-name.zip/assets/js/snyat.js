/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

function copyTrackLink() {
    var copyText = document.getElementById("trackShareLink");
    if (navigator.share) {
        navigator.share({ 
            title: document.title, 
            text: 'Посмотри, какую работу я нашёл на Снять.рус!', 
            url: copyText.value 
        }).catch(function() { performCopy(copyText); });
    } else { 
        performCopy(copyText); 
    }
}

function performCopy(elem) {
    var currentFocus = document.activeElement; 
    elem.style.left = "0px"; 
    elem.select(); 
    elem.setSelectionRange(0, 99999); 
    document.execCommand("copy"); 
    elem.style.left = "-9999px";
    if (currentFocus && typeof currentFocus.focus === "function") { 
        currentFocus.focus(); 
    }
    alert("Ссылка скопирована в буфер обмена!");
}
