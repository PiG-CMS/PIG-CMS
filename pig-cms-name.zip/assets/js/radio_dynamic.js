/* 
 * 🐷 PIG-CMS
 * [People, Internet, Global Hub]
 * © 2026 pig-cms.name & Доктор Шрам
 */

var cnt = 2;
function addTrack(){
    if(cnt > 10){ 
        alert('Максимум 10 вариантов!'); 
        return; 
    }
    var c = document.getElementById('dynamic-tracks-container');
    var d = document.createElement('div'); 
    d.style.marginTop = '10px';
    d.innerHTML = '<label>Вариант #' + cnt + ' (MP3):</label><input type="file" name="audio_files_alt[]" accept=".mp3">';
    c.appendChild(d); 
    cnt++;
    if(cnt > 10) document.getElementById('addTrackBtn').style.display = 'none';
}
