/* 
 * 🐷 PIG-CMS — Модуль PIG-NET JS (РАЗДАТОЧНАЯ ВЕРСИЯ ДЛЯ УЗЛОВ СЕТИ)
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME & Доктор Шрам
 */

document.addEventListener("DOMContentLoaded", function() {
    const pingBtn = document.getElementById("pig-ping-btn");
    if (pingBtn) {
        pingBtn.addEventListener("click", function() {
            const currentUrl = window.location.origin + window.location.pathname.replace('admin/index.php', '').replace('admin/market_add.php', '');
            const masterServer = "https://pig-cms.name"; 
            
            this.innerText = "СВЯЗЬ С ХАБОМ...";
            this.disabled = true;

            const beacon = new Image();
            beacon.src = `${masterServer}?url=${encodeURIComponent(currentUrl)}&nocache=${Date.now()}`;
            
            beacon.onload = () => {
                alert("Заявка успешно отправлена! Твой узел добавлен в общий реестр сети PIG-NET.");
                this.innerText = "ОТПРАВЛЕНО ✓";
                this.style.background = "#28a745";
                this.style.color = "#fff";
            };
            
            beacon.onerror = () => {
                alert("Сигнал отправлен! Проверь свой статус в общем каталоге на PIG-CMS.NAME.");
                this.innerText = "ОТПРАВЛЕНО ✓";
                this.style.background = "#28a745";
                this.style.color = "#fff";
            };
        });
    }
});
