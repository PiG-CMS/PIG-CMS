/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

function copyTrackLink(){
    var e = document.getElementById("trackShareLink");
    if(navigator.share){
        navigator.share({title:document.title, url:e.value}).catch(function(){perfCopy(e)});
    } else {
        perfCopy(e);
    }
}
function perfCopy(e){
    e.style.left = "0px"; e.select(); e.setSelectionRange(0,99999); 
    document.execCommand("copy"); e.style.left = "-9999px"; 
    alert("Ссылка скопирована!");
}

function sendVote(tId, vNum) {
    var f = new FormData(); f.append('id', tId); f.append('version', vNum);
    fetch('core/vote.php', { method: 'POST', body: f })
    .then(r => r.json())
    .then(d => {
        if (d.status === 'success' || d.status === 'already') {
            for (var i = 1; i <= 10; i++) { 
                var el = document.getElementById('vCount' + i); 
                if (el && d['votes_' + i] !== undefined) el.innerText = d['votes_' + i]; 
            }
            if (d.status === 'success') { alert('Спасибо! Ваш выбор учтён.'); } else { alert('Вы уже голосовали!'); }
        } else { alert('Ошибка.'); }
    }).catch(e => console.error(e));
}

// Запуск фонового радио-вещания PIG-CMS
var audioRadio = document.getElementById('shram-radio');
var radioStatus = document.getElementById('radio-status');
var currentTrackIndex = 0;

if (typeof radioPlaylist !== 'undefined' && radioPlaylist.length > 0) {
    var savedTrackId = localStorage.getItem('shram_radio_track');
    var savedTime = localStorage.getItem('shram_radio_time');
    
    if (savedTrackId) { 
        var foundIndex = radioPlaylist.findIndex(t => t.id === savedTrackId); 
        if (foundIndex !== -1) currentTrackIndex = foundIndex; 
    }
    
    loadRadioTrack(currentTrackIndex, savedTime ? parseFloat(savedTime) : 0);
    
    audioRadio.addEventListener('timeupdate', function() { 
        if (!audioRadio.paused) { 
            localStorage.setItem('shram_radio_track', radioPlaylist[currentTrackIndex].id); 
            localStorage.setItem('shram_radio_time', audioRadio.currentTime); 
        } 
    });
    
    audioRadio.addEventListener('ended', function() { 
        currentTrackIndex++; 
        if (currentTrackIndex >= radioPlaylist.length) currentTrackIndex = 0; 
        localStorage.removeItem('shram_radio_time'); 
        loadRadioTrack(currentTrackIndex, 0); 
        audioRadio.play(); 
    });
} else if(radioStatus) { 
    radioStatus.innerText = "Плейлист пуст."; 
}

function loadRadioTrack(idx, t) { 
    if (radioPlaylist[idx]) { 
        audioRadio.src = radioPlaylist[idx].src; 
        radioStatus.innerHTML = "Сейчас играет: <strong>" + radioPlaylist[idx].title + "</strong>"; 
        if (t > 0) audioRadio.currentTime = t; 
    } 
}

// 📡 ГАЛАКТИЧЕСКОЕ РАДИО PIG-NET
var localBackupPlaylist = (typeof radioPlaylist !== 'undefined' && Array.isArray(radioPlaylist)) ? [...radioPlaylist] : [];

function toggleGalaxyRadio() {
    var box = document.getElementById('galaxy-stations-box');
    var list = document.getElementById('galaxy-stations-list');
    if (!box || !list) {
        alert('Не найден блок galaxy-stations-box в шаблоне!');
        return;
    }

    if (box.style.display === 'block') {
        box.style.display = 'none';
        return;
    }
    box.style.display = 'block';
    list.innerHTML = '📡 Сканируем частоты Квадранта...';

    // Если мы на главном хабе — берем напрямую из API, иначе через локальный PHP-прокси
    var isHub = window.location.hostname.indexOf('pig-cms.name') !== -1;
    var apiUrl = isHub ? 'api/radio_list.php' : 'radio.php?action=get_galaxy_stations';

    fetch(apiUrl)
        .then(function(r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(function(stations) {
            var html = '<div style="margin-bottom:8px;"><a href="#" onclick="switchStation(\'local\'); return false;" style="color:#ffb703; text-decoration:none; font-weight:bold;">🏠 Вернуться на домашнюю волну</a></div>';
            
            if (!Array.isArray(stations) || stations.length === 0) {
                html += '<div style="color:#777;">Других активных радиовышек пока не найдено.</div>';
            } else {
                for (var i = 0; i < stations.length; i++) {
                    var st = stations[i];
                    html += '<div style="margin-bottom:6px;"><a href="#" onclick="switchStation(\'' + st.url + '\'); return false;" style="color:#00ff66; text-decoration:none;">📻 ' + st.name + '</a></div>';
                }
            }
            list.innerHTML = html;
        })
        .catch(function(err) {
            list.innerHTML = '<span style="color:#dc3545;">Ошибка связи с Хабом (' + err.message + ')</span>';
        });
}

function switchStation(siteUrl) {
    if (siteUrl === 'local') {
        radioPlaylist = [...localBackupPlaylist];
        currentTrackIndex = 0;
        if (radioPlaylist.length > 0) {
            loadRadioTrack(0, 0);
            audioRadio.play();
        }
        return;
    }

    if (radioStatus) radioStatus.innerText = "📡 Настраиваемся на волну " + siteUrl + "...";
    
    var isCurrentSite = siteUrl.indexOf(window.location.hostname) !== -1;
    var streamUrl = isCurrentSite ? 'radio.php?action=galaxy_stream' : (siteUrl.replace(/\/$/, '') + '/radio.php?action=galaxy_stream');

    fetch(streamUrl)
        .then(function(r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(function(data) {
            if (data.status === 'ok' && data.tracks && data.tracks.length > 0) {
                radioPlaylist = data.tracks;
                currentTrackIndex = 0;
                loadRadioTrack(0, 0);
                audioRadio.play();
            } else {
                if (radioStatus) radioStatus.innerText = "🔒 " + (data.message || "Эфир этой планеты закрыт или пуст.");
            }
        })
        .catch(function(err) {
            if (radioStatus) radioStatus.innerText = "❌ Ошибка приема волны (" + err.message + ")";
        });
}

// 🔄 ПРИНУДИТЕЛЬНЫЙ СБРОС КЕША ПЛЕЕРА И СТРАНИЦЫ
function resetRadioCache() {
    // Очищаем память плеера в браузере
    localStorage.removeItem('shram_radio_track');
    localStorage.removeItem('shram_radio_time');
    
    // Перезагружаем страницу в обход кеша браузера
    var cleanUrl = window.location.href.split('?')[0];
    window.location.replace(cleanUrl + '?nocache=' + Date.now());
}
