<?php

/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

// www/games.php
require_once 'core/config.php';

// ЕДИНЫЙ БЕЛЫЙ СПИСОК ВСЕХ НАШИХ ИГР
$allowed_games = [
    'clicker'       => 'games/pig_clicker/index.php',
    'guess'         => 'games/guess/index.php',
    'inspector'     => 'games/pig_inspector/index.php',
    'teleport'      => 'games/pig_teleport/index.php',
    'racer_v'       => 'games/pig_racer_v/index.php',
    'racer_h'       => 'games/pig_racer_h/index.php',
    'flappy'        => 'games/pig_flappy/index.php',
    'racer_rules'   => 'games/pig_racer_rules/index.php', // 🚔 Гонки с ГАИ и прерывистой line
    'snake'         => 'games/pig_snake/index.php',       // 🍏 Суверенная Змейка
    'lamp'          => 'games/pig_lamp/index.php',
    'invaders'      => 'games/pig_invaders/index.php'
];


$currentGame = $_GET['play'] ?? null;

// Если запущена конкретная игра
if ($currentGame && array_key_exists($currentGame, $allowed_games)) {
    // Если игра шлет AJAX-запрос рекорда, отдаем данные без HTML-шапки сайта
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        require_once $allowed_games[$currentGame];
        exit;
    }
    
    // Обычный запуск игры внутри шаблона CMS
    require_once 'core/header.php';
    require_once $allowed_games[$currentGame];
    require_once 'core/footer.php';
    exit;
}

// Защита: если ввели дичь в URL, шлем на системный шлюз ошибок
if ($currentGame) {
    include 'error.php'; 
    exit;
}

// --- ГЛАВНАЯ ВИТРИНА ИГР ---
require_once 'core/header.php';
?>

<div style="max-width: 800px; margin: 40px auto; font-family: monospace; padding: 0 15px;">
    <h1 style="text-align: center; color: #ffb703;">🎮 PIG-ARCADE  🎮</h1>
    <p style="text-align: center; color: #666;">Эко-гейминг: 0 байт текстур, чистый азарт и JSON-рекорды.</p>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 30px;">
        
        <!-- Карточка 1: Космический Телепорт и Оборона Квадранта -->
        <div style="border: 2px dashed #00ff66; padding: 20px; border-radius: 8px; text-align: center; background: #16161e; color: #fff; box-shadow: 0 0 10px rgba(0,255,102,0.05);">
            <span style="font-size: 40px;">🪐</span>
            <h3 style="margin: 10px 0; color: #00ff66;">PIG-Teleport</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Межсайтовые порталы. Активируй Сторожа и лови чужих Хрюндиков!</p>
            <a href="games.php?play=teleport" style="display: inline-block; padding: 8px 15px; background: #00ff66; color: #000; text-decoration: none; border-radius: 4px; font-weight: bold; text-transform: uppercase;">Запустить</a>
        </div>

        <!-- Карточка 2: Кликер -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">🐷</span>
            <h3 style="margin: 10px 0; color: #ffb703;">PIG-Clicker</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Тапай свинью, нанимай рабочих и фарми хрю-коины.</p>
            <a href="games.php?play=clicker" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ИГРАТЬ</a>
        </div>

        <!-- Карточка 3: Новая игра Угадай число -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">🎲</span>
            <h3 style="margin: 10px 0; color: #ffb703;">Угадай число</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Математическая дуэль с ИИ. Угадай число за минимум попыток.</p>
            <a href="games.php?play=guess" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ИГРАТЬ</a>
        </div>

        <!-- Карточка 4: PIG-Inspector -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">🕵️‍♂️</span>
            <h3 style="margin: 10px 0; color: #ffb703;">PIG-Inspector</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Суверенная проверка реакции. Поймай баг матрицы за доли секунды.</p>
            <a href="games.php?play=inspector" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ИГРАТЬ</a>
        </div>

        <!-- Карточка 5: Текстовый Квест -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <div style="font-size: 40px; text-align: center;">📟</div>
            <h3 style="margin: 10px 0; color: #ffb703;">Победи Матрицу</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Суверенный текстовый кибер-квест. Обойди корпоративные фильтры.</p>
            <a href="games/pig_matrix_escape/index.php" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">КВЕСТ</a>
        </div>

        <!-- Карточка 6: Кости Судьбы -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <div style="font-size: 40px; text-align: center;">🎲</div>
            <h3 style="margin: 10px 0; color: #ffb703;">Кости Судьбы</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Простая ламповая игра на удачу. Испытай генератор случайных чисел.</p>
            <a href="games/pig_dice/index.php" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ИГРАТЬ</a>
        </div>
      
              <!-- Карточка 7: PIG-RACER V -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">🏎️</span>
            <h3 style="margin: 10px 0; color: #ffb703;">PIG-Racer (Вертикаль)</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Суверенные вертикальные гонки. Обойди барьеры матрицы на полной скорости.</p>
            <a href="games.php?play=racer_v" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ИГРАТЬ</a>
        </div>

              <!-- Карточка 8: PIG-RACER h -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">🏎️</span>
            <h3 style="margin: 10px 0; color: #ffb703;">PIG-Racer (горизонталь)</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Суверенные горизонтальные гонки. Обойди барьеры матрицы на полной скорости.</p>
            <a href="games.php?play=racer_h" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ИГРАТЬ</a>
        </div>

<!-- Карточка 9: Flappy Pig -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">🐷</span>
            <h3 style="margin: 10px 0; color: #ffb703;">Flappy Pig</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Помоги Хрюндику пролететь сквозь жесткие фильтры цензуры.</p>
            <a href="games.php?play=flappy" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ЛЕТЕТЬ</a>
        </div>

        <!-- Карточка 10: Гонки по правилам (NEW) -->
        <div style="border: 2px dashed #ff3333; padding: 20px; border-radius: 8px; text-align: center; background: #1a1a1a; color: #fff;">
            <span style="font-size: 40px;">🚔</span>
            <h3 style="margin: 10px 0; color: #ff3333;">Жиза-Рейсинг</h3>
            <p style="font-size: 0.85rem; color: #aaa; min-height: 40px;">Обгон тихоходов, сплошная, знаки и ГАИ в кустах. Закон подлости на ПК.</p>
            <a href="games.php?play=racer_rules" style="display: inline-block; padding: 8px 15px; background: #ff3333; color: #fff; text-decoration: none; border-radius: 4px; font-weight: bold;">ПО ПРАВИЛАМ</a>
        </div>

      <!-- Карточка 11: Змейка (NEW) -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">🍏</span>
            <h3 style="margin: 10px 0; color: #ffb703;">PIG-Snake</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Ретро-змейка. Собирай яблоки свободы и фарми плоские JSON-рекорды.</p>
            <a href="games.php?play=snake" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ИГРАТЬ</a>
        </div>
      
              <!-- Карточка 12: Космические захватчики (NEW) -->
        <div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
            <span style="font-size: 40px;">💥</span>
            <h3 style="margin: 10px 0; color: #ffb703;">Защита Квадранта</h3>
            <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Космический шутер. Защити flat-file ядро от летящих багов корпораций.</p>
            <a href="games.php?play=invaders" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ОБОРОНА</a>
        </div>

      <!-- Карточка 13: Глобальная Лампочка -->
<div style="border: 2px dashed #ffb703; padding: 20px; border-radius: 8px; text-align: center; background: #222; color: #fff;">
    <span style="font-size: 40px;">💡</span>
    <h3 style="margin: 10px 0; color: #ffb703;">Лампочка</h3>
    <p style="font-size: 0.85rem; color: #ccc; min-height: 40px;">Одна лампочка на всех. Включи или выключи свет для всей планеты.</p>
    <a href="games.php?play=lamp" style="display: inline-block; padding: 8px 15px; background: #ffb703; color: #111; text-decoration: none; border-radius: 4px; font-weight: bold;">ЩЕЛКНУТЬ</a>
</div>

    </div>
</div>

<?php require_once 'core/footer.php'; ?>
