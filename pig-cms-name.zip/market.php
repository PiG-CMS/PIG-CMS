<?php
/* 
 * 🐷 PIG-CMS — Автономный модуль «Доска объявлений»
 * © 2026 pig-cms.name & Доктор Шрам
 */

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/core/config.php';

$dir = __DIR__ . '/data/market_posts/';
if (!is_dir($dir)) { mkdir($dir, 0755, true); }

// ГЕНЕРАЦИЯ КАПЧИ ДЛЯ ЖАЛОБЫ
if (!isset($_SESSION['m_captcha_res'])) {
    $r_num1 = rand(1, 5); $r_num2 = rand(1, 5);
    $_SESSION['m_captcha_text'] = "$r_num1 + $r_num2";
    $_SESSION['m_captcha_res'] = $r_num1 + $r_num2;
}

$alert_message = '';
$salt = $APP_SETTINGS['privacy_salt'] ?? 'pig_market_salt';
$user_hash = substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') . $salt), 0, 24);

// ОБРАБОТКА ПОСТ-ЗАПРОСОВ (Реакции и Жалобы с flock и хэшированием IP)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $post_id = preg_replace('/[^a-zA-Z0-9_-]/', '', trim($_POST['post_id'] ?? ''));
    $file_path = $dir . $post_id . '.json';

    if ($post_id !== '' && file_exists($file_path)) {
        if ($_POST['action'] === 'like_useful') {
            $status_msg = '';
            pig_json_update($file_path, function($p) use ($user_hash, &$status_msg) {
                if (empty($p)) return null;
                if (!isset($p['likes_ip'])) $p['likes_ip'] = [];
                if (!isset($p['like_useful'])) $p['like_useful'] = 0;

                if (in_array($user_hash, $p['likes_ip'], true)) {
                    $status_msg = "<script>alert('Вы уже отмечали это объявление!');</script>";
                    return null;
                }
                $p['likes_ip'][] = $user_hash;
                $p['like_useful']++;
                $status_msg = "<script>alert('Спасибо! Респект учтен.');</script>";
                return $p;
            }, null);
            $alert_message = $status_msg;
        }

        if ($_POST['action'] === 'report') {
            $user_ans = intval($_POST['report_captcha'] ?? 0);
            if ($user_ans !== ($_SESSION['m_captcha_res'] ?? -1)) {
                $alert_message = "<script>alert('Ошибка капчи!');</script>";
            } else {
                $reason_raw = htmlspecialchars(trim($_POST['report_reason'] ?? ''), ENT_QUOTES, 'UTF-8');
                $status_msg = '';
                pig_json_update($file_path, function($p) use ($user_hash, $reason_raw, &$status_msg) {
                    if (empty($p)) return null;
                    $author = strtolower(trim($p['author'] ?? ''));
                    $status = strtolower(trim($p['status'] ?? ''));

                    if ($author === 'admin' || $status === 'admin') {
                        $status_msg = "<script>alert('🐷 На посты Создателя жаловаться бесполезно!');</script>";
                        return null;
                    }
                    if (!isset($p['reports_ip'])) $p['reports_ip'] = [];
                    if (!isset($p['report_reasons'])) $p['report_reasons'] = [];
                    if (!isset($p['report_count'])) $p['report_count'] = 0;

                    if (in_array($user_hash, $p['reports_ip'], true)) {
                        $status_msg = "<script>alert('Вы уже отправляли сигнал по этому объявлению!');</script>";
                        return null;
                    }

                    $p['reports_ip'][] = $user_hash;
                    $p['report_count']++;
                    if ($reason_raw !== '') {
                        $p['report_reasons'][] = date('d.m H:i') . ': ' . mb_substr($reason_raw, 0, 150, 'UTF-8');
                    }
                    $status_msg = "<script>alert('Сигнал принят и передан администратору на проверку.');</script>";
                    return $p;
                }, null);
                $alert_message = $status_msg;
            }

            // Обновляем капчу
            $r_num1 = rand(1, 5); $r_num2 = rand(1, 5);
            $_SESSION['m_captcha_text'] = "$r_num1 + $r_num2"; 
            $_SESSION['m_captcha_res'] = $r_num1 + $r_num2;
        }
    }
}


// СБОР ДАННЫХ ДЛЯ ОБЪЯВЛЕНИЙ (Без автоскрытия по жалобам)
$files = glob($dir . "*.json");
$posts_data = [];
$view_single = isset($_GET['view']) ? trim($_GET['view']) : '';

if (!empty($files)) {
    array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
    foreach ($files as $file) {
        $basename = basename($file, '.json');
        if (!empty($view_single) && $basename !== $view_single) continue;

        $p = json_decode(file_get_contents($file), true);
        if ($p) {
            $p['id'] = $basename;
            $posts_data[] = $p;
        }
    }
}

// Динамические заголовки страниц Маркета
$site_brand = htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS');
$page_title = "Доска объявлений авторов — " . $site_brand;

if (!empty($view_single) && !empty($posts_data)) {
    $page_title = htmlspecialchars($posts_data[0]['title']) . " — Маркет " . $site_brand;
}

include_once __DIR__ . '/core/header.php';
if (!empty($alert_message)) echo $alert_message;

include_once __DIR__ . '/core/market_view.php';

include_once __DIR__ . '/core/footer.php';
?>
