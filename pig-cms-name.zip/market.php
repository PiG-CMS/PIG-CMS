<?php
/* 
 * 🐷 PIG-CMS — Автономный модуль «Доска объявлений»
 * © 2026 pig-cms.name & Доктор Шрам
 */

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/core/config.php';

$dir = __DIR__ . '/data/market_posts/';
if (!is_dir($dir)) { mkdir($dir, 0755, true); }

// ГЕНЕРАЦИЯ КАПЧИ ДЛЯ ЖАЛОБЫ
if (!isset($_SESSION['m_captcha_res'])) {
    $r_num1 = rand(1, 5); $r_num2 = rand(1, 5);
    $_SESSION['m_captcha_text'] = "$r_num1 + $r_num2";
    $_SESSION['m_captcha_res'] = $r_num1 + $r_num2;
}

$alert_message = '';
$user_ip = $_SERVER['REMOTE_ADDR'];

// ОБРАБОТКА ПОСТ-ЗАПРОСОВ (Реакции и Жалобы)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $post_id = trim($_POST['post_id'] ?? '');
    $file_path = $dir . $post_id . '.json';

    if (file_exists($file_path)) {
        $p = json_decode(file_get_contents($file_path), true);
        if ($p) {
            if (!isset($p['likes_ip'])) $p['likes_ip'] = [];
            if (!isset($p['reports_ip'])) $p['reports_ip'] = [];
            if (!isset($p['report_reasons'])) $p['report_reasons'] = [];
            if (!isset($p['like_useful'])) $p['like_useful'] = 0;
            if (!isset($p['report_count'])) $p['report_count'] = 0;

            if ($_POST['action'] === 'like_useful') {
                if (in_array($user_ip, $p['likes_ip'])) {
                    $alert_message = "<script>alert('Вы уже отмечали это объявление!');</script>";
                } else {
                    $p['likes_ip'][] = $user_ip; 
                    $p['like_useful']++;
                    file_put_contents($file_path, json_encode($p, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
                    $alert_message = "<script>alert('Спасибо! Респект учтен.');</script>";
                }
            }

            if ($_POST['action'] === 'report') {
                $user_ans = intval($_POST['report_captcha'] ?? 0);
                $author = strtolower(trim($p['author'] ?? ''));
                $status = strtolower(trim($p['status'] ?? ''));

                if ($user_ans !== $_SESSION['m_captcha_res']) {
                    $alert_message = "<script>alert('Ошибка капчи!');</script>";
                } elseif ($author === 'admin' || $status === 'admin') {
                    // Иммунитет на посты Создателя
                    $alert_message = "<script>alert('🐷 На посты Создателя жаловаться бесполезно!');</script>";
                } elseif (in_array($user_ip, $p['reports_ip'])) {
                    $alert_message = "<script>alert('Вы уже отправляли сигнал по этому объявлению!');</script>";
                } else {
                    $p['reports_ip'][] = $user_ip; 
                    $p['report_count']++;
                    
                    // Записываем причину, если её передали из формы
                    $reason = htmlspecialchars(trim($_POST['report_reason'] ?? ''));
                    if (!empty($reason)) {
                        $p['report_reasons'][] = date('d.m H:i') . ': ' . mb_substr($reason, 0, 150, 'UTF-8');
                    }

                    file_put_contents($file_path, json_encode($p, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
                    $alert_message = "<script>alert('Сигнал принят и передан администратору на проверку.');</script>";
                }
                
                // Обновляем капчу
                $r_num1 = rand(1, 5); $r_num2 = rand(1, 5);
                $_SESSION['m_captcha_text'] = "$r_num1 + $r_num2"; 
                $_SESSION['m_captcha_res'] = $r_num1 + $r_num2;
            }
        }
    }
}

// СБОР ДАННЫХ ДЛЯ ОБЪЯВЛЕНИЙ (Без автоскрытия по жалобам)
$files = glob($dir . "*.json");
$posts_data = [];
$view_single = isset($_GET['view']) ? trim($_GET['view']) : '';

if (!empty($files)) {
    array_multisort(array_map('filemtime', $files), SORT_DESC, $files);
    foreach ($files as $file) {
        $basename = basename($file, '.json');
        if (!empty($view_single) && $basename !== $view_single) continue;

        $p = json_decode(file_get_contents($file), true);
        if ($p) {
            $p['id'] = $basename;
            $posts_data[] = $p;
        }
    }
}

// Динамические заголовки страниц Маркета
$site_brand = htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS');
$page_title = "Доска объявлений авторов — " . $site_brand;

if (!empty($view_single) && !empty($posts_data)) {
    $page_title = htmlspecialchars($posts_data[0]['title']) . " — Маркет " . $site_brand;
}

include_once __DIR__ . '/core/header.php';
if (!empty($alert_message)) echo $alert_message;

include_once __DIR__ . '/core/market_view.php';

include_once __DIR__ . '/core/footer.php';
?>
