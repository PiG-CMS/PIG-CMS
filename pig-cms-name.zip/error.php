<?php
/* 
 * 🐷 PIG-CMS — Единый Универсальный Шлюз Ошибок
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 pig-cms.name & Доктор Шрам
 */

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/core/config.php';

// Считываем код ошибки, по умолчанию выдаем 404
$error_code = isset($_GET['code']) ? intval($_GET['code']) : 404;

// Интеллектуальный массив текстов под каждую ошибку матрицы
$error_database = [
    404 => [
        'title' => '404 — Страница не инфильтрирована',
        'headline' => 'ОШИБКА 404: СТРАНИЦА НЕ НАЙДЕНА',
        'desc' => 'Запрошенный адрес не существует в базе данных PIG-CMS, либо оригинальные цифровые печати файла были перемещены владельцем.'
    ],
    403 => [
        'title' => '403 — Доступ заблокирован',
        'headline' => 'ОШИБКА 403: ВХОД ИНФИЛЬТРИРОВАН',
        'desc' => 'У вашего автомата недостаточно прав для прохода через этот системный шлюз. Доступ выдается администрацией исключительно вручную.'
    ],
    500 => [
        'title' => '500 — Системный затор',
        'headline' => 'ОШИБКА 500: СБОЙ МАТРИЦЫ ЯДРА',
        'desc' => 'На сервере произошел внутренний технический затор. Код не смог обработать JSON-базу. Зайдите позже или напишите Доктору Шраму.'
    ]
];

// Если прилетел неизвестный код, отдаем дефолтный 404
$current_error = $error_database[$error_code] ?? $error_database[404];

$page_title = $current_error['title'];
include_once __DIR__ . '/core/header.php';
?>

<!-- Универсальная брутальная разметка (Стили подхватятся из snyat.css) -->
<div class="error-page-container" style="text-align: center; padding: 60px 20px; font-family: monospace;">
    <h1 class="error-code-num" style="font-size: 80px; color: #dc3545; margin: 0;"><?php echo $error_code; ?></h1>
    <h3 class="error-headline" style="color: #fff; margin: 10px 0 20px 0; text-transform: uppercase;"><?php echo $current_error['headline']; ?></h3>
    <p class="error-description" style="color: #666; max-width: 550px; margin: 0 auto 30px auto; line-height: 1.6; font-size: 14px;"><?php echo $current_error['desc']; ?></p>
    <a href="index.php" class="error-return-btn" style="display: inline-block; background: #28a745; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 13px;">← ВЕРНУТЬСЯ В ХАБ</a>
</div>

<?php 
include_once __DIR__ . '/core/footer.php'; 
?>
