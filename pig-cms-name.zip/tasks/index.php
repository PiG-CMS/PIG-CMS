<?php
/* 
 * 🐷 PIG-CMS 
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

if (session_status() === PHP_SESSION_NONE) { session_start(); }
date_default_timezone_set('Europe/Moscow');
require_once __DIR__ . '/../core/config.php';

$mod_title = isset($ABSURD_MODULE_TITLE) ? $ABSURD_MODULE_TITLE : "Задачи и Промты";
$data_dir = __DIR__ . '/data_posts';
if (!is_dir($data_dir)) { mkdir($data_dir, 0755, true); }

$rubrics = ['Графика и ИИ', 'Видео и Клипы', 'Аудио и Музыка', 'Тексты и Сценарии', 'IT и Скрипты', 'Общие задачи'];
$current_rubric = isset($_GET['rubric']) ? trim($_GET['rubric']) : 'Все';

// --- НАСТРОЙКА УМНОЙ ЦИФРОВОЙ ПАГИНАЦИИ ---
$posts_per_page = 10; 
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($current_page < 1) { $current_page = 1; }

$captcha_error = $_SESSION['task_err'] ?? ''; $success_message = $_SESSION['task_ok'] ?? '';
unset($_SESSION['task_err']); unset($_SESSION['task_ok']);

// СБОР ПОСТОВ ДЛЯ СТРАНИЦЫ
$all_posts = []; $files = glob($data_dir . '/*.json');
if ($files) {
    foreach ($files as $file) {
        $content = json_decode(file_get_contents($file), true);
        if ($content && isset($content['status']) && $content['status'] === 1) { 
            if ($current_rubric === 'Все' || $content['rubric'] === $current_rubric) { $all_posts[] = $content; }
        }
    }
    usort($all_posts, function($a, $b) { return strcmp($b['id'], $a['id']); });
}

$total_posts = count($all_posts); $total_pages = ceil($total_posts / $posts_per_page);
if ($total_pages < 1) { $total_pages = 1; }
if ($current_page > $total_pages) { $current_page = $total_pages; }
$posts = array_slice($all_posts, ($current_page - 1) * $posts_per_page, $posts_per_page);

if (!isset($_SESSION['captcha_num1'])) { $_SESSION['captcha_num1'] = rand(2, 9); $_SESSION['captcha_num2'] = rand(2, 9); }

// 🔥 ДИНАМИЧЕСКИЙ СУВЕРЕННЫЙ ЗАГОЛОВОК
$site_brand = htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS');
$page_title = htmlspecialchars($mod_title) . " — " . $site_brand; 
$is_radio_page = false;
$hub_title = $mod_title; $hub_subtitle = "Пространство сценариев и промтов для авторов хаба";

ob_start(); include_once __DIR__ . '/../core/header.php'; $header_html = ob_get_clean();
echo str_replace('href="assets/', 'href="../assets/', $header_html);
?>
<div style="text-align: center; margin-bottom: 25px;">
    <button class="react-btn" style="background:#ffc107; color:#212529; font-size:15px; padding:12px 30px; border-radius:25px;" onclick="openModal()">+ Поставить задачу авторам</button>
</div>

<div class="rubric-menu">
    <a href="./" class="rubric-link <?php echo ($current_rubric === 'Все') ? 'active' : ''; ?>">Все темы</a>
    <?php foreach ($rubrics as $rub): ?><a href="index.php?rubric=<?php echo urlencode($rub); ?>" class="rubric-link <?php echo ($current_rubric === $rub) ? 'active' : ''; ?>"><?php echo htmlspecialchars($rub); ?></a><?php endforeach; ?>
</div>

<div class="warn-alert">⏱️ Площадка B2B-взаимодействия. Авторы хаба выполняют любые промты и прикрепляют результаты.</div>

<?php if ($captcha_error): ?><div class="sys-msg error" style="background:#4d1818; color:#ffb3b3; padding:10px; border-radius:6px; margin-bottom:15px; text-align:center;"><?php echo $captcha_error; ?></div><?php endif; ?>
<?php if ($success_message): ?><div class="sys-msg success" style="background:#143d14; color:#b3ffb3; padding:10px; border-radius:6px; margin-bottom:15px; text-align:center;"><?php echo $success_message; ?></div><?php endif; ?>


<div class="feed">
    <?php if (empty($posts)): ?>
        <div class="empty-feed"><h3>Лента задач пуста 📭</h3><p>В рубрике «<strong><?php echo htmlspecialchars($current_rubric); ?></strong>» пока нет активных промтов.</p></div>
    <?php else: foreach ($posts as $post): ?>
            <div class="single-post-wrap" id="post-<?php echo $post['id']; ?>" style="margin-bottom: 25px; max-width: 100%;">
                <div class="post-header"><span style="color:#aaa;">👤 От: <b><?php echo htmlspecialchars($post['name']); ?></b></span><span class="post-rubric"><?php echo htmlspecialchars($post['rubric']); ?></span></div>
                <div class="post-title">🎯 Задача: <?php echo htmlspecialchars($post['title']); ?></div>
                <div class="post-text"><?php echo nl2br(htmlspecialchars($post['text'])); ?></div>
                
                <?php if (!empty($post['replies']) && is_array($post['replies'])): ?>
                    <div class="reply-box"><div style="font-size: 12px; color: #ffc107; font-weight: bold; margin-bottom: 8px;">✅ Решения от авторов:</div>
                        <?php foreach ($post['replies'] as $rep): ?>
                            <div class="reply-item"><b>@<?php echo htmlspecialchars($rep['author']); ?>:</b> <?php echo htmlspecialchars($rep['reply_text']); ?><?php if (!empty($rep['reply_url'])): ?><br><a href="<?php echo htmlspecialchars($rep['reply_url']); ?>" target="_blank" style="color: #007bff; text-decoration: none; font-weight: bold; font-size:12px;">🔗 Посмотреть готовую работу →</a><?php endif; ?></div>
                        <?php endforeach; ?></div>
                <?php endif; ?>
                
                <?php if (isset($_SESSION['auth']) && $_SESSION['auth'] === true): ?>
                    <form method="POST" action="../core/task_actions.php" class="reply-author-form"><input type="hidden" name="action" value="author_reply"><input type="hidden" name="post_id" value="<?php echo $post['id']; ?>"><input type="hidden" name="current_page" value="<?php echo $current_page; ?>"><div style="font-size:12px; color:#aaa; font-weight:bold; margin-bottom:8px;">🛠️ Выполнить задание от лица @<?php echo $_SESSION['username']; ?>:</div><input type="text" name="reply_text" placeholder="Что сделано? (Пример: Записал аудио-версию / Сделал арт)" required><input type="url" name="reply_url" placeholder="Ссылка на результат на снять.рус"><button type="submit" class="react-btn" style="padding:6px 15px; font-size:12px;">Прикрепить ответ</button></form>
                <?php endif; ?>
                
                <div class="post-footer"><span>📅 Размещено: <?php echo $post['date']; ?></span><button class="btn-share" onclick="sharePost('<?php echo addslashes(htmlspecialchars($post['title'])); ?>', window.location.origin + window.location.pathname + window.location.search + '#post-<?php echo $post['id']; ?>')">Поделиться промтом 📢</button></div>
            </div>
        <?php endforeach; ?>
        
        <?php if ($total_pages > 1): ?>
            <div class="pagination" style="text-align:center; margin-top:30px; display:flex; justify-content:center; gap:8px;">
                <?php if ($current_page > 1): ?><a href="index.php?rubric=<?php echo urlencode($current_rubric); ?>&page=<?php echo $current_page - 1; ?>" class="page-btn">← Назад</a><?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): if ($i == 1 || $i == $total_pages || ($i >= $current_page - 2 && $i <= $current_page + 2)): ?><a href="index.php?rubric=<?php echo urlencode($current_rubric); ?>&page=<?php echo $i; ?>" class="page-btn <?php echo ($current_page == $i) ? 'active' : ''; ?>"><?php echo $i; ?></a><?php elseif ($i == 2 || $i == $total_pages - 1): ?><span class="page-dots">...</span><?php endif; endfor; ?>
                <?php if ($current_page < $total_pages): ?><a href="index.php?rubric=<?php echo urlencode($current_rubric); ?>&page=<?php echo $current_page + 1; ?>" class="page-btn">Вперед →</a><?php endif; ?>
            </div>
        <?php endif; endif; ?>
</div>

<div class="modal" id="orderModal"><div class="modal-content"><button class="close-modal" onclick="closeModal()">&times;</button><h3>Добавить задачу для авторов 📝</h3><form method="POST" action="../core/task_actions.php"><input type="hidden" name="action" value="add_post"><div class="form-group"><label>Краткая суть задания *</label><input type="text" name="title" class="form-control" placeholder="Например: Сгенерировать неоновый логотип" required></div><div class="form-group"><label>Ваше имя / Ник</label><input type="text" name="name" class="form-control" placeholder="Аноним"></div><div class="form-group"><label>Направление *</label><select name="rubric" class="form-control" required><?php foreach ($rubrics as $rub): ?><option value="<?php echo htmlspecialchars($rub); ?>"><?php echo htmlspecialchars($rub); ?></option><?php endforeach; ?></select></div><div class="form-group"><label>Техническое задание промта *</label><textarea name="text" class="form-control" rows="4" placeholder="Опишите детали, стиль..." required></textarea></div><div class="form-group"><label class="captcha-label">Проверка ботов: <?php echo $_SESSION['captcha_num1'] . ' + ' . $_SESSION['captcha_num2']; ?> = ? *</label><input type="number" name="captcha" class="form-control" placeholder="Ответ цифрами" required></div><button type="submit" class="react-btn" style="width: 100%; border-radius: 6px; margin-top: 10px; background:#28a745;">Отправить задачу на хаб 🚀</button></form></div></div>
<script src="../assets/js/tasks.js"></script>
<?php include_once __DIR__ . '/../core/footer.php'; ?>
