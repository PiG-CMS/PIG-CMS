<?php
/* 
 * 🐷 PIG-CMS — Расширенная Панель Управления
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления PIG-CMS</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .menu-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px; }
        .menu-card { background: #2d2d2d; padding: 20px; border-radius: 6px; text-align: center; border: 1px solid #444; display: flex; flex-direction: column; justify-content: space-between; }
        .menu-card h3 { margin-top: 0; color: #ffc107; }
        .menu-card p { font-size: 13px; color: #ccc; flex-grow: 1; }
        .menu-card a { display: inline-block; background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold; margin-top: 15px; }
        .menu-card a:hover { background: #0056b3; }
        .update-btn { background: #28a745 !important; }
        .update-btn:hover { background: #218838 !important; }
        .logout-link { color: #d9534f; text-decoration: none; font-weight: bold; display: block; text-align: center; margin-top: 20px; }
        @media (max-width: 600px) { .menu-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
<div class="form-wrap" style="<?php 
    if (!isset($_SESSION['auth'])) {
        echo 'max-width: 400px;';
    } else {
        echo (!empty($is_admin)) ? 'max-width: 800px;' : 'max-width: 600px;'; 
    }
?>">
    <h2 style="margin-top:0; text-align:center; color:#fff;">🐷 PIG-CMS</h2>

    <?php if (!empty($message)) echo $message; ?>

    <?php if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true): ?>
        <form method="POST">
            <input type="text" name="username" value="admin" style="display:none;" autocomplete="username">
            <label>Логин:</label>
            <input type="text" name="login" required placeholder="admin">
            <label>Пароль:</label>
            <input type="password" name="pass" required placeholder="1234" autocomplete="current-password">
            <?php if (!empty($_SESSION['captcha_q'])): ?>
                <label style="color:#ffb703;">🛡️ Защита от роботов: сколько будет <?php echo htmlspecialchars($_SESSION['captcha_q']); ?>?</label>
                <input type="number" name="captcha_ans" required placeholder="Введите ответ" autocomplete="off">
            <?php endif; ?>
            <button type="submit" name="login_submit">Войти в Хаб</button>
        </form>
    <?php else: ?>

        <p style="text-align:center; color:#aaa;">Добро пожаловать, <b>@<?php echo htmlspecialchars($_SESSION['username']); ?></b>!</p>

        <?php if (!empty($is_admin)): ?>
            <div class="config-panel-wrap" style="background: #222; border: 1px solid #444; padding: 20px; border-radius: 6px; margin: 20px 0 25px 0; font-family: monospace; text-align: left;">
                <h3 style="margin-top: 0; color: #ffb703; text-transform: uppercase; font-size: 14px; border-bottom: 1px dashed #444; padding-bottom: 10px;">⚙️ Конфигуратор матрицы PIG-CMS.NAME</h3>
                <form method="POST" action="">
                    
                    <div style="margin-bottom: 15px;">
                        <label style="color: #ccc; font-size: 12px; display: block; margin-bottom: 6px; font-weight: bold;">👑 Название Хаба (Бренд):</label>
                        <input type="text" name="site_title" value="<?php echo htmlspecialchars($APP_SETTINGS['site_title'] ?? 'PiG CMS'); ?>" style="width: 100%; padding: 10px; background: #2d2d2d; color: #fff; border: 1px solid #555; border-radius: 4px; font-family: monospace;">
                    </div>

                    <div style="margin-bottom: 15px;">
                        <label style="color: #ccc; font-size: 12px; display: block; margin-bottom: 6px; font-weight: bold;">📝 Слоган / Описание под именем:</label>
                        <input type="text" name="site_slogan" value="<?php echo htmlspecialchars($APP_SETTINGS['site_slogan'] ?? 'PIG-CMS— твоя независимая экосистема'); ?>" style="width: 100%; padding: 10px; background: #2d2d2d; color: #fff; border: 1px solid #555; border-radius: 4px; font-family: monospace;">
                    </div>

                    <div style="margin-bottom: 15px;">
                        <label style="color: #ccc; font-size: 12px; display: block; margin-bottom: 6px; font-weight: bold;">🎯 Режим главной страницы (index.php):</label>
                        <select name="landing_page" style="width: 100%; padding: 10px; background: #2d2d2d; color: #fff; border: 1px solid #555; border-radius: 4px; font-family: monospace;">
                            <option value="aggregator" <?php echo ($APP_SETTINGS['landing_page'] ?? 'aggregator') === 'aggregator' ? 'selected' : ''; ?>>📡 Модульный Агрегатор (Сборная лента)</option>
                            <option value="grid" <?php echo ($APP_SETTINGS['landing_page'] ?? '') === 'grid' ? 'selected' : ''; ?>>📋 Классическая витрина (Сетка постов)</option>
                        </select>
                    </div>

                    <!-- === БЛОК ВЫБОРА ТЕМЫ ОФОРМЛЕНИЯ === -->
                    <div style="margin-bottom: 15px;">
                        <label style="color: #ccc; font-size: 12px; display: block; margin-bottom: 6px; font-weight: bold;">🎨 Тема оформления:</label>
                        <select name="theme_style" style="width: 100%; padding: 10px; background: #2d2d2d; color: #fff; border: 1px solid #555; border-radius: 4px; font-family: monospace;">
                            <?php
                            $current_theme = $APP_SETTINGS['theme_style'] ?? 'pig_pink';
                            $all_themes = [
                                'pig_pink'            => '🐷 Суверенный Розовый',
                                'snyat_matrix'        => '🎬 Матрица Креатива',
                                'light_free'          => '🕊️ Свободный Светлый',
                                'steampunk_reserve'   => '⚙️ Суверенный Стимпанк',
                                'light_blue'          => '🐳 Небесно-Голубой',
                                'cozy_beige'          => '☕ Ламповый Бежевый',
                                'soft_pink'           => '🌸 Нежно-Розовый Зефир',
                                'matrix_terminal'     => '📟 Хакерский Терминал',
                                'pure_pink'           => '🐷 Тотальный Чистый Розовый',
                                'cyber_neon'          => '🌆 Киберпанк Неон',
                                'emerald_forest'      => '🌲 Изумрудный Лес',
                                'sunset_synthwave'    => '🌇 Ретровейв Закат',
                                'nordic_snow'         => '❄️ Скандинавский Снег',
                                'old_newspaper'       => '📰 Газетный Лист',
                                'deep_ocean'          => '🌊 Глубокий Океан',
                                'volcanic_lava'       => '🌋 Вулканическая Лава',
                                'royal_gold'          => '👑 Королевское Золото',
                                'lavender_mist'       => '💜 Лавандовый Туман',
                                'solar_sand'          => '🏜️ Пустынный Песок',
                                'portal_sidebar_left' => '📐 Двухколоночный Портал (Левый сайдбар)',
                                'magazine_two_col'    => '📖 Журнал 2 Колонки (Светлый)',
                                'showcase_three_col'  => '🏛️ Трёхколоночная Витрина (Wide 3-Col)',
                                'retro_bbs_90s'       => '💾 Ретро Веб 90-х (Norton Style)',
                                'compact_feed_list'   => '⚡ Компактная Лента (HackerNews Style)',
                                'portal_sidebar_right'=> '📐 Двухколоночный Портал (Правый сайдбар)',
                                'deep_space_glass'    => '🌌 Глубокий Космос (Glassmorphism)',
                                'brutal_concrete'     => '🧱 Необрутализм (Бетон и Контраст)',
                                'mint_minimal'        => '🌿 Мятный Минимализм',
                                'arcade_cabinet'      => '🕹️ Аркадный Автомат 8-Bit',
                            ];

                            foreach ($all_themes as $t_slug => $t_label) {
                                $sel = ($current_theme === $t_slug) ? 'selected' : '';
                                echo '<option value="' . $t_slug . '" ' . $sel . '>' . $t_label . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="color: #ccc; font-size: 12px; display: block; margin-bottom: 6px; font-weight: bold;">📢 База Ротатора Баннеров (Текст | Ссылка):</label>
                        <?php
                        $textarea_content = "";
                        if (!empty($APP_SETTINGS['banners']) && is_array($APP_SETTINGS['banners'])) {
                            foreach ($APP_SETTINGS['banners'] as $b) {
                                $textarea_content .= $b['text'] . " | " . $b['url'] . "\n";
                            }
                        } else {
                            $textarea_content = "🚀 Добро пожаловать! | index.php?cat=rules\n";
                        }
                        ?>
                        <textarea name="banners_text" rows="4" style="width: 100%; padding: 10px; background: #2d2d2d; color: #fff; border: 1px solid #555; border-radius: 4px; font-family: monospace; resize: vertical; line-height: 1.4;"><?php echo htmlspecialchars($textarea_content); ?></textarea>
                    </div>
                    <button type="submit" name="save_settings" style="width: 100%; padding: 12px; background: #ffb703; color: #111; border: none; font-weight: bold; cursor: pointer; border-radius: 4px; text-transform: uppercase; font-size: 12px;">💾 Применить настройки</button>
                </form>
            </div>
  
              <div style="background: #222; border: 1px solid #444; padding: 15px 20px; border-radius: 6px; margin-bottom: 25px; font-family: monospace; text-align: left;">
                <h4 style="margin: 0 0 10px 0; color: #ff6b6b; font-size: 13px; text-transform: uppercase;">🔐 Смена пароля администратора (Хэширование SHA-256)</h4>
                <form method="POST" action="" style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <input type="text" name="new_admin_pass" required placeholder="Введите новый пароль (мин. 4 символа)" style="flex-grow: 1; min-width: 200px; padding: 8px 10px; background: #2d2d2d; color: #fff; border: 1px solid #555; border-radius: 4px; font-family: monospace;">
                    <button type="submit" name="change_admin_pass" style="padding: 8px 16px; background: #28a745; color: #fff; border: none; font-weight: bold; cursor: pointer; border-radius: 4px; font-family: monospace;">🔒 Зашифровать и сохранить</button>
                </form>
            </div>

        <?php endif; ?>
                  
        <?php
            $mail_file = __DIR__ . '/../data/mail_box.json';
            $unread_mail = 0;
            if (file_exists($mail_file)) {
                $m_list = json_decode(file_get_contents($mail_file), true) ?: [];
                foreach ($m_list as $m_item) {
                    if (($m_item['type'] ?? '') === 'in' && empty($m_item['read'])) {
                        $unread_mail++;
                    }
                }
            }
        ?>
        <div class="menu-card" style="border-color: #00b4d8;">
            <h3 style="color: #00b4d8;">
                📬 Галактическая Почта 
                <?php if ($unread_mail > 0): ?>
                    <span style="background:#d9534f; color:#fff; padding:2px 8px; border-radius:12px; font-size:12px;">+<?php echo $unread_mail; ?></span>
                <?php endif; ?>
            </h3>
            <p>Прямая P2P-переписка с владельцами других сайтов сети PIG-CMS без нагрузки на Главный Хаб.</p>
            <a href="../mail.php" style="background:#00b4d8; color:#111;">Открыть почту ✉️</a>
        </div>
  
        <div class="menu-grid">
            <div class="menu-card">
                <h3>Витрина Портфолио</h3>
                <p>Добавление новых творческих работ, photo, видео и ИИ-артов в основную ленту.</p>
                <a href="snyat_add.php">Открыть витрину</a>
            </div>

            <div class="menu-card">
                <h3>Радио Доктор Шрам</h3>
                <p>Загрузка треков MP3, добавление альтернативных дублей ИИ-исполнения и оригинальных текстов.</p>
                <a href="radio_add.php">Открыть радио</a>
            </div>

            <div class="menu-card">
                <h3>📹 Видео-Хаб инструкции</h3>
                <p>Публикация блогов, уроков, видеоинструкций коллектива и встраивание плееров YouTube/VK.</p>
                <a href="video_add.php">Открыть Видео-Хаб</a>
            </div>

            <div class="menu-card">
                <h3>🛍️ Маркетплейс / Доска</h3>
                <p>Продажа ИИ-артов, кодов, услуг и мерча. Быстрая связь с покупателями напрямую.</p>
                <a href="market_add.php" style="background:#e67e22;">Открыть Доску</a>
            </div>

            <div class="menu-card" style="border-color: #9b5de5;">
                <h3 style="color: #9b5de5;">🧠 Чат-бот «Эволюция»</h3>
                <p>Обучение бота ответам на частые вопросы гостей, наполнение базы знаний.</p>
                <a href="bot_evolution.php" style="background: #9b5de5; color: #fff;">Обучить бота 🚀</a>
            </div>

            <?php if ($is_admin): ?>
                <div class="menu-card" style="border-color: #ffc107;">
                    <h3>🎯 Биржа задач и промтов</h3>
                    <p>Модерация входящих запросов, публикация спецзаданий и прикрепление ответов.</p>
                    <a href="tasks_admin.php" style="background:#ffc107; color:#212529;">Управлять задачами</a>
                </div>
            
                <div class="menu-card" style="border-color: #ffc107;">
                    <h3>👤 Регистрация авторов</h3>
                    <p>Ручное добавление авторов. Аккаунт будет мгновенно занесен в общую базу.</p>
                    <a href="users_add.php" style="background:#ffc107; color:#212529;">Создать автора ➕</a>
                </div>
            <?php endif; ?>
        </div>

        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #333; text-align: center; display: flex; justify-content: center; gap: 15px; flex-wrap: wrap;">
            <a href="../index.php" target="_blank" style="display: inline-block; background: #007bff; color: white; padding: 12px 25px; text-decoration: none; border-radius: 4px; font-weight: bold; font-family: monospace; text-transform: uppercase; font-size: 12px;">👁️ Открыть сайт в новом окне</a>
            <a href="https://pig-cms.name" target="_blank" class="update-btn" style="display: inline-block; background: #28a745; color: white; padding: 12px 25px; text-decoration: none; border-radius: 4px; font-weight: bold; font-family: monospace; text-transform: uppercase; font-size: 12px;">🔄 Проверить обновления</a>
        </div>
  
        <?php 
            $today_file = __DIR__ . '/../data/metrika_logs/' . date('Y-m-d') . '.json';
            $today_data = file_exists($today_file) ? json_decode(file_get_contents($today_file), true) : null;
            $views = $today_data['views'] ?? 0;
            $uniques = $today_data['uniques'] ?? 0;
        ?>
        <div style="margin-top: 20px; padding: 15px; background: #1a1a1a; border: 1px solid #333; border-radius: 6px; text-align: center; font-family: monospace; color: #fff;">
            <h4 style="margin: 0 0 10px 0; color: #ffb703; text-transform: uppercase; font-size: 13px; letter-spacing: 0.5px;">📊 Живая статистика за сегодня</h4>
            <div style="display: flex; justify-content: space-around; font-size: 14px;">
                <div>👀 Просмотры: <b style="color: #007bff;"><?php echo $views; ?></b></div>
                <div>👤 Уникальные юзеры: <b style="color: #28a745;"><?php echo $uniques; ?></b></div>
            </div>
        </div>

        <a href="index.php?logout=1" class="logout-link">🚪 Выйти из Хаба</a>
    <?php endif; ?>
    
    <footer>
        <p style="text-align: center; color: #666; font-size: 12px; margin-top: 30px;">© 2026 PIG-CMS | Поддержка творчества Доктор Шрам</p>
    </footer>
</div>

 <script>
if (window.history && window.history.replaceState) {
    window.history.replaceState(null, '', window.location.pathname);
}
</script>


</body>
</html>
