<?php
/* 
 * 🐷 PIG-CMS — Добавление поста в портфолио (Anti-502 & Clean JSON Edition)
 * [Pi_Ti & Google Hub] — Свободный интернет без матрицы
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/../core/config.php';

// Защита: если не авторизован в админке — отправляем на главную админки
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: index.php');
    exit;
}

// Капча
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['captcha_res'])) {
    $num1 = rand(1, 9); $num2 = rand(1, 9);
    $_SESSION['captcha_num1'] = $num1; $_SESSION['captcha_num2'] = $num2; $_SESSION['captcha_res'] = $num1 + $num2;
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_captcha = intval($_POST['captcha']);
    $title = trim($_POST['title']);
    $category = trim($_POST['category']); 
    
    // Распаковываем описание из Base64 (если сработал транспорт) или берём напрямую
    if (!empty($_POST['description_b64'])) {
        $description = trim(base64_decode($_POST['description_b64']));
    } else {
        $description = trim($_POST['description'] ?? '');
    }

    $img_url = trim($_POST['img_url']);
    $target_url = trim($_POST['target_url']);

    if (empty($img_url)) {
        $img_url = 'logo.jpeg'; 
    }

    if ($user_captcha !== $_SESSION['captcha_res']) {
        $message = "<p style='color:#d9534f; font-weight:bold;'>Ошибка: Неверный ответ капчи!</p>";
    } elseif (!empty($title) && !empty($target_url)) {
        
        $post_id = time() . rand(100,999);

        $postData = [
            'title' => $title,
            'category' => in_array($category, $allowed_categories) ? $category : 'Общее',
            'description' => $description, // Сохраняем чистый текст без двойного htmlspecialchars
            'img_url' => $img_url,
            'target_url' => $target_url,
            'author' => $_SESSION['username'], 
            'like_fire' => 0,
            'like_show' => 0, 
            'like_useful' => 0, 
            'like_heart' => 0,
            'like_ok' => 0,
            'date' => time()
        ];

        $filename = $DIR_SNYAT_POSTS . $post_id . '.json';
        file_put_contents($filename, json_encode($postData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        // Умная генерация карты сайта (если файл лежит в ядре)
        if (file_exists(__DIR__ . '/../core/sitemap_gen.php')) {
            include __DIR__ . '/../core/sitemap_gen.php';
        }
      
        $message = "<p style='color:#28a745; font-weight:bold;'>Успешно опубликовано в хабе!</p>";
        unset($_SESSION['captcha_res']);
    } else {
        $message = "<p style='color:#d9534f;'>Заполните обязательные поля!</p>";
    }
    
    $num1 = rand(1, 9); $num2 = rand(1, 9);
    $_SESSION['captcha_num1'] = $num1; $_SESSION['captcha_num2'] = $num2; $_SESSION['captcha_res'] = $num1 + $num2;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить работу — PiG-CMS</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="form-wrap">
    <h2 style="margin-top:0; margin-bottom:20px; text-align:center; color:#fff;">Новая публикация портфолио</h2>
    
    <?php if(!empty($message)) echo $message; ?>
    
    <form method="POST" id="postForm">
        <label>Название проекта / Заголовок <span class="req">*</span>:</label>
        <input type="text" name="title" required placeholder="Например: Сет неоновых портретов (Cyberpunk style)">

        <label>Направление творчества <span class="req">*</span>:</label>
        <select name="category" required>
            <?php foreach ($allowed_categories as $cat): ?>
                <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
            <?php endforeach; ?>
        </select>

        <label>Описание работы (Чистый текст или примеры кода):</label>
        <textarea id="rawDesc" rows="10" placeholder="Напишите историю создания или детали проекта..."></textarea>
        <input type="hidden" name="description_b64" id="b64Desc">

        <label>Ссылка на обложку-превью (если пусто — будет демо-заглушка logo.jpeg):</label>
        <input type="text" name="img_url" placeholder="https://site.ru или logo.jpeg">

        <label>Целевая ссылка автора (Трафик / Соцсеть / Сайт) <span class="req">*</span>:</label>
        <input type="url" name="target_url" required placeholder="https://pig-cms.name">

        <div class="captcha-wrap">
            <span class="req">*</span> Защита от спама: Сколько будет <?php echo $_SESSION['captcha_num1'] . ' + ' . $_SESSION['captcha_num2']; ?>?
            <input type="number" name="captcha" required placeholder="Ответ цифрой" style="margin-top:10px; margin-bottom:0;">
        </div>
        
        <button type="submit" class="btn-success">Опубликовать в хабе</button>
    </form>
    
    <div class="back-btn"><a href="index.php">← Назад в меню админки</a></div>
</div>

<script>
// Упаковка текста в Base64 (UTF-8) перед отправкой, чтобы фаервол хостинга не кидал 502 на теги <script>
document.getElementById('postForm').addEventListener('submit', function() {
    const raw = document.getElementById('rawDesc').value;
    const bytes = new TextEncoder().encode(raw);
    let binString = '';
    bytes.forEach((b) => { binString += String.fromCharCode(b); });
    document.getElementById('b64Desc').value = btoa(binString);
});
</script>
</body>
</html>
