<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/../core/config.php'; // Проверка авторизации

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: index.php');
    exit;
}

// 🔥 Исправленный путь: джонсоны хранятся строго в папке data/
$json_file = __DIR__ . '/../data/bot_knowledge.json';
$msg = '';

// Загрузка текущей базы знаний
$knowledge = [];
if (file_exists($json_file)) {
    $knowledge = json_decode(file_get_contents($json_file), true) ?: [];
}

// ОБРАБОТКА ДЕЙСТВИЙ (Добавление и Удаление)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Обучение бота новой паре (Окно 1 + Окно 2)
    if (isset($_POST['teach_bot'])) {
        $q = trim(strip_tags($_POST['bot_question'] ?? ''));
        $a = trim(strip_tags($_POST['bot_answer'] ?? ''));

        if (!empty($q) && !empty($a)) {
            $knowledge[] = [
                'question' => $q,
                'answer' => $a
            ];
            file_put_contents($json_file, json_encode($knowledge, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            $msg = "<p style='color:#28a745; font-weight:bold; text-align:center;'>Бот успешно обучен новой фразе!</p>";
        } else {
            $msg = "<p style='color:#d9534f; text-align:center;'>Заполните оба окна для обучения!</p>";
        }
    }
    
    // 2. Удаление правила из базы (Окно 3)
    if (isset($_POST['delete_index'])) {
        $idx = (int)$_POST['delete_index'];
        if (isset($knowledge[$idx])) {
            array_splice($knowledge, $idx, 1);
            file_put_contents($json_file, json_encode($knowledge, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            $msg = "<p style='color:#ffc107; font-weight:bold; text-align:center;'>Запись успешно удалена из памяти бота.</p>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Эволюция ИИ — Управление ботом PIG-CMS</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        body { background: #1a1a1a; color: #fff; font-family: Arial, sans-serif; padding: 20px; }
        .evolution-grid { display: grid; grid-template-columns: 1fr 1fr; grid-gap: 20px; margin-bottom: 25px; }
        .window-box { background: #242424; border: 1px solid #3e444c; border-radius: 8px; padding: 15px; }
        .window-box h3 { margin-top: 0; color: #ffc107; border-bottom: 1px dashed #333; padding-bottom: 8px; font-size: 16px; }
        textarea { width: 100%; height: 100px; background: #1a1a1a; border: 1px solid #565e64; color: #fff; border-radius: 6px; padding: 10px; resize: none; box-sizing: border-box; }
        .full-width-window { background: #242424; border: 1px solid #3e444c; border-radius: 8px; padding: 15px; }
        .btn-teach { background: #28a745; color: white; border: none; padding: 12px; width: 100%; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 15px; margin-top: 10px; transition: 0.2s; }
        .btn-teach:hover { background: #218838; }
        .base-table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }
        .base-table th, .base-table td { border: 1px solid #3e444c; padding: 8px; text-align: left; }
        .base-table th { background: #2d3238; color: #ffc107; }
        .btn-del { background: transparent; border: 1px solid #d9534f; color: #d9534f; padding: 3px 8px; border-radius: 4px; cursor: pointer; font-size: 11px; }
        .btn-del:hover { background: #d9534f; color: white; }
    </style>
</head>
<body>
<div style="max-width: 900px; margin: 0 auto;">

    <h2 style="text-align:center; margin-top:0; color:#fff; font-weight: 300;">⚙️ Модуль «Эволюция» — Обучение бота</h2>
    <p style="text-align:center; color:#aaa; font-size:13px; margin-bottom:20px;">Задавайте правила реагирования для фильтрации очевидных вопросов гостей</p>

    <?php if(!empty($msg)) echo $msg; ?>

    <form method="POST">
        <!-- Блок из 2 Окон (Ввод и Обучение) -->
        <div class="evolution-grid">
            <div class="window-box">
                <h3>🔲 Окно 1: Если гость спрашивает (Ключевая фраза):</h3>
                <textarea name="bot_question" placeholder="Например: как снять жилье" required></textarea>
            </div>
            
            <div class="window-box">
                <h3>🔲 Окно 2: База знаний выдает ответ:</h3>
                <textarea name="bot_answer" placeholder="Введите точный ответ для гостя..." required></textarea>
            </div>
        </div>
        <button type="submit" name="teach_bot" class="btn-teach">Записать знания в память бота 🧠</button>
    </form>

    <br>

    <!-- Окно 3 (Мониторинг базы знаний) -->
    <div class="full-width-window">
        <h3>🔲 Окно 3: Мониторинг и структура текущей памяти бота</h3>
        <?php if(empty($knowledge)): ?>
            <p style="color:#666; font-style:italic; text-align:center; padding: 15px;">Память бота чиста. Обучите его первому правилу выше.</p>
        <?php else: ?>
            <table class="base-table">
                <thead>
                    <tr>
                        <th style="width: 35%;">Входящий триггер (Вопрос)</th>
                        <th>Выдаваемый ответ (Знание)</th>
                        <th style="width: 80px; text-align:center;">Действие</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($knowledge as $index => $item): ?>
                        <tr>
                            <td style="color:#ffe082;"><b><?php echo htmlspecialchars($item['question']); ?></b></td>
                            <td style="color:#ccc;"><?php echo htmlspecialchars($item['answer']); ?></td>
                            <td style="text-align:center;">
                                <form method="POST" style="margin:0;" onsubmit="return confirm('Удалить эту фразу из памяти бота?');">
                                    <input type="hidden" name="delete_index" value="<?php echo $index; ?>">
                                    <button type="submit" class="btn-del">Забыть ❌</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div style="text-align: center; margin-top: 20px;" class="back-btn">
        <a href="index.php" style="color: #aaa; text-decoration: none; font-size: 14px;">← Назад в меню админки</a>
    </div>
</div>
</body>
</html>
