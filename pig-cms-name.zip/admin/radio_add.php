<?php
/* 
 * 🐷 PIG-CMS — Добавление треков на Радио Доктор Шрам
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

require_once __DIR__ . '/../core/config.php';

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: index.php');
    exit;
}

// Защита от прямого входа обычных авторов (пускаем только главного админа)
if (($_SESSION['username'] ?? '') !== ADMIN_LOGIN) { // если в config.php переменная $admin_login — напиши её вместо ADMIN_LOGIN
    header('Location: index.php');
    exit;
}

$message = '';

$galaxy_cfg_file = __DIR__ . '/../data/radio_galaxy.json';
$galaxy_cfg = file_exists($galaxy_cfg_file) ? json_decode(file_get_contents($galaxy_cfg_file), true) : ['allow_broadcast' => false];

if (isset($_POST['save_galaxy_radio'])) {
    $galaxy_cfg['allow_broadcast'] = isset($_POST['allow_broadcast']);
    file_put_contents($galaxy_cfg_file, json_encode($galaxy_cfg, JSON_PRETTY_PRINT));
    $message = $galaxy_cfg['allow_broadcast'] 
        ? "<p style='color:#00ff66; font-weight:bold;'>📡 Галактическое вещание ВКЛЮЧЕНО! Другие сайты могут ловить вашу волну.</p>"
        : "<p style='color:#ffb703; font-weight:bold;'>🔒 Внешнее вещание ОТКЛЮЧЕНО. Радио работает только локально.</p>";
}

if (isset($_POST['add_track_submit'])) {
    $pack_title = trim($_POST['pack_title'] ?? 'Без названия');
    $lyrics     = trim($_POST['lyrics'] ?? '');
    
    $artists_raw = $_POST['artist'] ?? [];
    $titles_raw  = $_POST['title'] ?? [];
    $files       = $_FILES['audio_files'] ?? null;
    
    $audio_tracks = [];
    $track_artists = [];
    $track_titles = [];
    $errors = [];

    if ($files && is_array($files['name'])) {
        for ($i = 0; $i < count($files['name']); $i++) {
            if (empty($files['name'][$i])) continue;

            $artist = trim($artists_raw[$i] ?? 'ИИ-Исполнитель');
            $title  = trim($titles_raw[$i] ?? 'Без названия');
            
            $file_name = time() . '_' . $i . '_' . basename($files['name'][$i]);
            $target_path = $DIR_RADIO_AUDIO . $file_name;
            
            $ext = strtolower(pathinfo($target_path, PATHINFO_EXTENSION));
            if ($ext !== 'mp3') {
                $errors[] = "Вариант №" . ($i + 1) . " («$title»): Разрешены только файлы MP3!";
                continue;
            }

            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                if (move_uploaded_file($files['tmp_name'][$i], $target_path)) {
                    $audio_tracks[] = $file_name;
                    $track_artists[] = $artist;
                    $track_titles[] = $title;
                } else {
                    $errors[] = "Ошибка загрузки файла для варианта №" . ($i + 1);
                }
            }
        }
    }

    if (!empty($audio_tracks)) {
        $track_data = [
            "title"         => $pack_title,
            "lyrics"        => $lyrics,
            "audio_tracks"  => $audio_tracks,
            "artists"       => $track_artists, // Сохраняем массив авторов
            "titles"        => $track_titles,  // Сохраняем массив названий треков
            "created_at"    => time()
        ];
        
        foreach ($audio_tracks as $index => $t_file) {
            $track_data['votes_' . ($index + 1)] = 0;
        }

        $json_file = $DIR_RADIO_POSTS . 'radio_pack_' . time() . '_' . rand(100,999) . '.json';
        file_put_contents($json_file, json_encode($track_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

        $message = "<p style='color:#28a745; font-weight:bold;'>✅ Музыкальный пак успешно запущен в ротацию!</p>";
        if (!empty($errors)) {
            $message .= "<div style='color:#d9534f; font-size:12px; margin-top:5px; text-align:left;'>" . implode('<br>', $errors) . "</div>";
        }
    } else {
        $message = "<p style='color:#d9534f; font-weight:bold;'>❌ Не выбрано ни одного валидного MP3 файла!</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Загрузка музыки — Радио Доктор Шрам</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body style="background: #111; color: #fff; font-family: monospace; padding: 20px;">
<div style="max-width: 500px; margin: 40px auto; background: #222; padding: 20px; border: 1px solid #444; border-radius: 6px;">
    
    <h3 style="color: #ffb703; text-transform: uppercase; margin-top: 0; text-align: center;">
        📻 Создание Пак-Голосования Радио
    </h3>
    <p style="text-align: center; font-size: 12px; color: #aaa;">
        <a href="index.php" style="color: #007bff; text-decoration: none;">← Вернуться в Панель управления</a>
    </p>

  
  <form method="POST" style="background: #16161e; padding: 12px; border: 1px dashed #00ff66; border-radius: 4px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; gap: 10px;">
    <label style="font-size: 12px; color: #00ff66; cursor: pointer; display: flex; align-items: center; gap: 8px;">
        <input type="checkbox" name="allow_broadcast" <?= !empty($galaxy_cfg['allow_broadcast']) ? 'checked' : '' ?>>
        <span>📡 Транслировать волну на другие сайты PIG-CMS</span>
    </label>
    <button type="submit" name="save_galaxy_radio" style="padding: 6px 12px; background: #00ff66; color: #000; border: none; font-weight: bold; border-radius: 4px; cursor: pointer; font-size: 11px;">СОХРАНИТЬ</button>
</form>

  
    <?php echo $message; ?>

    <form method="POST" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 15px; margin-top: 20px;">
        
        <div>
            <label style="display:block; margin-bottom:5px; font-size:12px; color:#ccc;">Общее название релиза / Тема голосования:</label>
            <input type="text" name="pack_title" required placeholder="Например: Гимн Поросёнка (Битва ИИ-версий)" style="width:100%; padding:8px; background:#333; border:1px solid #555; color:#fff; border-radius:4px;">
        </div>

        <div id="dynamic-tracks-container" style="background: #1a1a1a; padding: 12px; border-radius: 4px; border: 1px dashed #555; display: flex; flex-direction: column; gap: 12px;">
            
            <!-- Вариант #1 -->
            <div style="border-bottom: 1px dashed #444; padding-bottom: 10px;">
                <label style="display:block; margin-bottom:5px; font-size:12px; color:#ffc107; font-weight:bold;">Вариант #1</label>
                <input type="text" name="artist[]" required placeholder="Автор / Исполнитель трека" style="width:100%; padding:6px; background:#333; border:1px solid #555; color:#fff; border-radius:4px; margin-bottom:8px; font-size:12px;">
                <input type="text" name="title[]" required placeholder="Название этого варианта" style="width:100%; padding:6px; background:#333; border:1px solid #555; color:#fff; border-radius:4px; margin-bottom:8px; font-size:12px;">
                <input type="file" name="audio_files[]" accept=".mp3" required style="color:#ccc; font-size:12px;">
            </div>

        </div>

        <button type="button" id="addTrackBtn" onclick="addTrack()" style="padding:6px 12px; background:#007bff; color:white; border:none; font-weight:bold; border-radius:4px; cursor:pointer; font-size:11px; align-self: flex-start; text-transform:uppercase;">
            ➕ Добавить еще вариант
        </button>

        <div>
            <label style="display:block; margin-bottom:5px; font-size:12px; color:#ccc;">Текст песни / Стихи автора:</label>
            <textarea name="lyrics" rows="6" placeholder="Вставьте сюда стихи..." style="width:100%; padding:8px; background:#333; border:1px solid #555; color:#fff; border-radius:4px; font-family:monospace; resize:vertical;"></textarea>
        </div>

        <button type="submit" name="add_track_submit" style="padding:12px; background:#ffb703; color:#111; border:none; font-weight:bold; border-radius:4px; cursor:pointer; text-transform:uppercase; margin-top:5px;">
            🚀 Выпустить пак в эфир хаба
        </button>
    </form>
</div>

<script>
var cnt = 2;
function addTrack(){
    if(cnt > 10){ 
        alert('Максимум 10 вариантов!'); 
        return; 
    }
    var container = document.getElementById('dynamic-tracks-container');
    var div = document.createElement('div'); 
    div.style.marginTop = '10px';
    div.style.paddingTop = '10px';
    div.style.borderBottom = '1px dashed #444';
    div.style.paddingBottom = '10px';
    
    div.innerHTML = '<label style="display:block; margin-bottom:5px; font-size:12px; color:#ffc107; font-weight:bold;">Вариант #' + cnt + '</label>' +
                    '<input type="text" name="artist[]" required placeholder="Автор / Исполнитель трека" style="width:100%; padding:6px; background:#333; border:1px solid #555; color:#fff; border-radius:4px; margin-bottom:8px; font-size:12px;">' +
                    '<input type="text" name="title[]" required placeholder="Название этого варианта" style="width:100%; padding:6px; background:#333; border:1px solid #555; color:#fff; border-radius:4px; margin-bottom:8px; font-size:12px;">' +
                    '<input type="file" name="audio_files[]" accept=".mp3" required style="color:#ccc; font-size:12px;">';
    
    container.appendChild(div); 
    cnt++;
    if(cnt > 10) document.getElementById('addTrackBtn').style.display = 'none';
}
</script>
</body>
</html>
