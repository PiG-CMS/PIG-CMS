<?php
/* 
 * 🐷 PIG-CMS — Панель Управления (Ядро логики + Защита от 502)
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

if (isset($_GET['keepalive'])) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    http_response_code(204);
    exit;
}

define('PIG_ADMIN_AREA', true);
require_once __DIR__ . '/../core/config.php';

$message = '';

if (isset($_SESSION['admin_flash_msg'])) {
    $message = $_SESSION['admin_flash_msg'];
    unset($_SESSION['admin_flash_msg']);
}

// =========================================================================
// 💾 PHP-ОБРАБОТЧИК: СОХРАНЕНИЕ НАСТРОЕК В JSON ИЗ АДМИНКИ (С FLOCK, БЕЗ 502)
// =========================================================================
if (isset($_POST['save_settings']) && isset($_SESSION['auth'])) {
    $new_title   = trim($_POST['site_title'] ?? 'PiG CMS');
    $new_slogan  = trim($_POST['site_slogan'] ?? 'PIG-CMS — твоя независимая экосистема');
    $new_landing = trim($_POST['landing_page'] ?? 'aggregator');
    $new_theme   = trim($_POST['theme_style'] ?? 'pig_pink');
    
    $banners_raw = explode("\n", $_POST['banners_text'] ?? '');
    $new_banners = [];
    
    foreach ($banners_raw as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        
        $parts = explode('|', $line);
        $b_text = isset($parts[0]) ? trim($parts[0]) : $line;
        $b_url  = isset($parts[1]) ? trim($parts[1]) : '#';
        
        $new_banners[] = [
            "text" => $b_text,
            "url"  => $b_url
        ];
    }
    
    $saved = pig_json_update($FILE_SETTINGS, function($data) use ($new_title, $new_slogan, $new_landing, $new_theme, $new_banners) {
        $data['site_title']   = $new_title;
        $data['site_slogan']  = $new_slogan;
        $data['landing_page'] = $new_landing;
        $data['theme_style']  = $new_theme;
        $data['banners']      = $new_banners;
        return $data;
    }, $APP_SETTINGS);
    
    if ($saved !== false) {
        $APP_SETTINGS = $saved;
        $message = "<p style='color:#28a745; font-weight:bold; text-align:center;'>✅ Конфигурация PIG-CMS успешно обновлена!</p>";
    } else {
        $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>❌ Ошибка записи в файл app_settings.json!</p>";
    }
}

// ==========================================================
// 🔐 СМЕНА ПАРОЛЯ АДМИНИСТРАТОРА (СОХРАНЕНИЕ ХЭША В DATA/USERS.JSON)
// ===========================================================

if (isset($_POST['change_admin_pass']) && (($_SESSION['username'] ?? '') === 'admin')) {
    $new_admin_pass = trim($_POST['new_admin_pass'] ?? '');
    if (mb_strlen($new_admin_pass) < 4) {
        $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>❌ Пароль должен быть не короче 4 символов!</p>";
    } else {
        $new_hash = pig_hash_pass($new_admin_pass);
        $saved_users = pig_json_update($FILE_USERS, function($u) use ($new_hash) {
            $u['admin'] = $new_hash;
            return $u;
        }, $users);

        if ($saved_users !== false) {
            $users = $saved_users;
            $message = "<p style='color:#28a745; font-weight:bold; text-align:center;'>🔐 Новый пароль зашифрован (SHA-256 + соль) и сохранён!</p>";
        } else {
            $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>❌ Ошибка записи в data/users.json!</p>";
        }
    }
}

// ===========================================================
// 🔒 УМНАЯ ЗАЩИТА ОТ ПОДБОРА ПАРОЛЕЙ (NAT-FRIENDLY + ХЭШИ)
// ===========================================================

$salt = $APP_SETTINGS['privacy_salt'] ?? 'pig_default_salt';
$user_ip_hash = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') . $salt);
$ban_dir = __DIR__ . '/../data/ban_logs/';
$ban_file = $ban_dir . substr($user_ip_hash, 0, 24) . '.json';

$ip_attempts = 0;
if (file_exists($ban_file)) {
    $ban_data = json_decode(file_get_contents($ban_file), true);
    if ($ban_data && (time() - ($ban_data['last_attempt'] ?? 0)) < 900) {
        $ip_attempts = (int)($ban_data['attempts'] ?? 0);
    } else {
        @unlink($ban_file);
    }
}
$session_attempts = (int)($_SESSION['login_attempts'] ?? 0);
$need_captcha = ($ip_attempts >= 3 || $session_attempts >= 2);

if (isset($_POST['login_submit'])) {
    $login = trim($_POST['login'] ?? '');
    $pass  = trim($_POST['pass'] ?? '');

      if ($need_captcha) {
        $expected_captcha = $_SESSION['captcha_ans'] ?? null;
        $user_captcha = trim($_POST['captcha_ans'] ?? '');
        if ($expected_captcha === null || (string)$expected_captcha !== $user_captcha) {
            $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>🛡️ Неверный ответ на проверочный пример! Попробуйте снова.</p>";
            goto generate_captcha;
        }
    }

    $auth_ok = false;
    if (array_key_exists($login, $users)) {
        $auth_ok = pig_verify_pass($pass, $users[$login]);
    }

       if ($auth_ok) {
        if (file_exists($ban_file)) { @unlink($ban_file); }
        unset($_SESSION['login_attempts'], $_SESSION['captcha_ans'], $_SESSION['captcha_q']);
        $_SESSION['auth'] = true;
        $_SESSION['username'] = $login;
        $message = "<p style='color:#28a745; font-weight:bold; text-align:center;'>✅ Вход выполнен успешно!</p>";
    } else {  
      
        $_SESSION['login_attempts'] = $session_attempts + 1;
        $updated_ban = pig_json_update($ban_file, function($data) {
            $attempts = ((time() - ($data['last_attempt'] ?? 0)) < 900) ? ($data['attempts'] ?? 0) : 0;
            return [
                'attempts'     => $attempts + 1,
                'last_attempt' => time()
            ];
        }, ['attempts' => 0, 'last_attempt' => 0]);

        $total_att = max($_SESSION['login_attempts'], $updated_ban['attempts'] ?? 1);
        $need_captcha = ($total_att >= 3);
        $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>❌ Неверный логин или пароль!" . ($need_captcha ? " Включена защита от перебора." : "") . "</p>";
    }
}

generate_captcha:
if ($need_captcha && empty($_SESSION['auth'])) {
    $a = random_int(2, 9);
    $b = random_int(2, 9);
    $_SESSION['captcha_ans'] = $a + $b;
    $_SESSION['captcha_q'] = "$a + $b";
} else {
    unset($_SESSION['captcha_ans'], $_SESSION['captcha_q']);
}

if (isset($_GET['logout'])) {
    unset($_SESSION['auth'], $_SESSION['username']);
    session_write_close();
    header('Location: index.php', true, 303);
    exit;
}

$is_admin = (isset($_SESSION['username']) && $_SESSION['username'] === 'admin');

include_once __DIR__ . '/admin_template.php';
