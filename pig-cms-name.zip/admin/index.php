<?php
/* 
 * 🐷 PIG-CMS — Панель Управления (Ядро логики)
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

// Подключаем конфигурацию ядра экосистемы (пути, сессии, массивы)
require_once __DIR__ . '/../core/config.php';

// Глобальный путь к конфигурационному файлу матрицы настроек
$FILE_SETTINGS = __DIR__ . '/../data/app_settings.json';

// Автоматическая генерация конфигурации, если JSON-файл отсутствует
if (!file_exists($FILE_SETTINGS)) {
    $default_settings = [
        "site_title" => "PiG CMS",
        "site_slogan" => "PIG-CMS— твоя независимая экосистема",
        "landing_page" => "aggregator",
        "theme_style" => "pig_pink",
        "banners" => [
            ["text" => "🚀 Добро пожаловать в Матрицу Творчества! — Доктор Шрам", "url" => "index.php?cat=rules"]
        ]
    ];
    file_put_contents($FILE_SETTINGS, json_encode($default_settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// Принудительно считываем свежие настройки из базы
$APP_SETTINGS = json_decode(file_get_contents($FILE_SETTINGS), true);
$message = '';

// =========================================================================
// 💾 PHP-ОБРАБОТЧИК: СУВЕРЕННОЕ СОХРАНЕНИЕ НАСТРОЕК В JSON ИЗ АДМИНКИ
// =========================================================================
if (isset($_POST['save_settings']) && isset($_SESSION['auth'])) {
    // 🔥 ХВАТАЕМ НАШИ НОВЫЕ ПЕРЕМЕННЫЕ УПРАВЛЕНИЯ БРЕНДОМ И СЛОГАНОМ
    $new_title   = trim($_POST['site_title'] ?? 'PiG CMS');
    $new_slogan  = trim($_POST['site_slogan'] ?? 'PIG-CMS— твоя независимая экосистема');
    $new_landing = trim($_POST['landing_page'] ?? 'aggregator');
    $new_theme   = trim($_POST['theme_style'] ?? 'pig_pink');
    
    // Парсим текстовое поле ротатора баннеров построчно
    $banners_raw = explode("\n", $_POST['banners_text'] ?? '');
    $new_banners = [];
    
    foreach ($banners_raw as $line) {
        $line = trim($line);
        if (empty($line)) continue; // Игнорируем пустые строки
        
        $parts = explode('|', $line);
        
        // Безопасный парсинг индексов с автоматической защитой от пустых строк
        $b_text = isset($parts[0]) ? trim($parts[0]) : $line;
        $b_url  = isset($parts[1]) ? trim($parts[1]) : '#';
        
        $new_banners[] = [
            "text" => $b_text,
            "url"  => $b_url
        ];
    }
    
    // Перезаписываем глобальный рабочий массив настроек хаба
    $APP_SETTINGS['site_title']  = $new_title;
    $APP_SETTINGS['site_slogan'] = $new_slogan;
    $APP_SETTINGS['landing_page'] = $new_landing;
    $APP_SETTINGS['theme_style']  = $new_theme;
    $APP_SETTINGS['banners']      = $new_banners;
    
    // Синхронизируем изменения с физическим JSON-файлом на сервере Majordomo
    if (file_put_contents($FILE_SETTINGS, json_encode($APP_SETTINGS, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT))) {
        $message = "<p style='color:#28a745; font-weight:bold; text-align:center;'>✅ Конфигурация PIG-CMS успешно обновлена!</p>";
    } else {
        $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>❌ Ошибка записи в файл app_settings.json!</p>";
    }
}

// =========================================================================
// 🔒 ЗАЩИТА ОТ ПОДБОРА ПАРОЛЕЙ И СИСТЕМА ВХОДА ДЛЯ АВТОРОВ ХАБА
// =========================================================================
if (isset($_POST['login_submit'])) {
    $login = trim($_POST['login'] ?? '');
    $pass = trim($_POST['pass'] ?? '');
    $user_ip = $_SERVER['REMOTE_ADDR'];
    
    $ban_dir = __DIR__ . '/../data/ban_logs/';
    if (!is_dir($ban_dir)) { mkdir($ban_dir, 0755, true); }
    $ban_file = $ban_dir . md5($user_ip) . '.json';

    // Проверяем статус временной блокировки по IP за частые ошибки
    if (file_exists($ban_file)) {
        $ban_data = json_decode(file_get_contents($ban_file), true);
        if ($ban_data && $ban_data['attempts'] >= 3) {
            $time_left = $ban_data['ban_until'] - time();
            if ($time_left > 0) {
                $minutes = ceil($time_left / 60);
                $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>⛔ ДОСТУП БЛОКИРОВАН ЗА ПОДБОР. Осталось: $minutes мин.</p>";
                goto render_page; // Экстренный прыжок на рендеринг страницы без валидации
            } else {
                unset($ban_data); @unlink($ban_file); // Время бана вышло — затираем лог
            }
        }
    }

    // Сверяем учетные данные с массивом доступов из core/config.php
    if (array_key_exists($login, $users) && $users[$login] === $pass) {
        if (file_exists($ban_file)) { @unlink($ban_file); }
        $_SESSION['auth'] = true;
        $_SESSION['username'] = $login;
        header('Location: index.php');
        exit;
    } else {
        // Накапливаем счетчик неудачных попыток входа для защиты
        $ban_data = file_exists($ban_file) ? json_decode(file_get_contents($ban_file), true) : ['attempts' => 0];
        $ban_data['attempts']++;
        $ban_data['last_ip'] = $user_ip;
        
        if ($ban_data['attempts'] >= 3) {
            $ban_data['ban_until'] = time() + 3600; // Бан на 1 час
            $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>⛔ ПРЕВЫШЕН ЛИМИТ ПОПЫТОК. Автобан на 1 час!</p>";
        } else {
            $left = 3 - $ban_data['attempts'];
            $message = "<p style='color:#d9534f; font-weight:bold; text-align:center;'>Неверный пароль! Осталось попыток: $left</p>";
        }
        file_put_contents($ban_file, json_encode($ban_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
}

render_page:

// Модуль безопасного уничтожения административной сессии
if (isset($_GET['logout'])) {
    unset($_SESSION['auth']);
    unset($_SESSION['username']);
    header('Location: index.php');
    exit;
}

// Проверяем, является ли пользователь главным ROOT-администратором сети
$is_admin = (isset($_SESSION['username']) && $_SESSION['username'] === 'admin');

// 🔥 ПОДКЛЮЧАЕМ НАШ ВЫНЕСЕННЫЙ ФАЙЛ СТРУКТУРНОЙ ВЕРСТКИ ИНТЕРФЕЙСА
include_once __DIR__ . '/admin_template.php';
