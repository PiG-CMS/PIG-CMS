<?php
/* 
 * 🐷 PIG-CMS 
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026  & Доктор Шрам
 */

require_once __DIR__ . '/../core/config.php';

// Жесткая проверка авторизации в единой системе админки
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: index.php');
    exit;
}

// Путь к базе данных промтов, которая находится в нашей нейтральной папке tasks/
$data_dir = __DIR__ . '/../tasks/data_posts';
if (!is_dir($data_dir)) { mkdir($data_dir, 0755, true); }

$current_file = basename($_SERVER['SCRIPT_NAME']);

// ОБРАБОТКА ДЕЙСТВИЙ МОДЕРАТОРА (Одобрить / Удалить)
if (isset($_GET['id']) && isset($_GET['go'])) {
    $id = preg_replace('/[^0-9_]/', '', $_GET['id']);
    $file = $data_dir . '/post_' . $id . '.json';
    
    if (file_exists($file)) {
        if ($_GET['go'] === 'approve') {
            $content = json_decode(file_get_contents($file), true);
            $content['status'] = 1; // Переводим статус в одобрен
            file_put_contents($file, json_encode($content, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        } elseif ($_GET['go'] === 'delete') {
            unlink($file); // Удаляем файл промта с сервера
        }
    }
    header('Location: ' . $current_file); exit;
}

// ДОБАВЛЕНИЕ ОФИЦИАЛЬНОГО ОТВЕТА АДМИНИСТРАЦИИ НА ЗАДАНИЕ
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_reply') {
    $id = preg_replace('/[^0-9_]/', '', $_POST['post_id']);
    $file = $data_dir . '/post_' . $id . '.json';
    
    $reply_text = trim(strip_tags($_POST['reply_text'] ?? ''));
    $reply_url  = trim(strip_tags($_POST['reply_url'] ?? ''));

    if (file_exists($file) && !empty($reply_text)) {
        $content = json_decode(file_get_contents($file), true);
        if (!isset($content['replies'])) { $content['replies'] = []; }
        
        // Прикрепляем ответ с короной админа
        $content['replies'][] = [
            'author' => $_SESSION['username'] . ' 👑',
            'reply_text' => $reply_text,
            'reply_url' => $reply_url
        ];
        
        file_put_contents($file, json_encode($content, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    header('Location: ' . $current_file); exit;
}

// Сбор постов, которые еще не прошли модерацию (status = 0)
$pending_posts = [];
$files = glob($data_dir . '/*.json');
if ($files) {
    foreach ($files as $file) {
        $content = json_decode(file_get_contents($file), true);
        if ($content && isset($content['status']) && $content['status'] === 0) {
            $pending_posts[] = $content;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Модерация Заданий — PIG-CMS</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<div class="form-wrap" style="max-width: 650px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #333; padding-bottom: 10px;">
        <h3 style="margin: 0; color: #ffc107;">🎯 Промты на модерации (<?php echo count($pending_posts); ?>)</h3>
        <a href="index.php" style="color: #a6b0b9; font-size: 13px; text-decoration:none; font-weight:bold;">← В меню админки</a>
    </div>

    <?php if (empty($pending_posts)): ?>
        <p style="text-align: center; color: #a6b0b9; padding: 20px 0;">Новых творческих задач от пользователей нет. Лента чиста! 👌</p>
    <?php else: ?>
        <?php foreach ($pending_posts as $p): ?>
            <div style="background: #1f1f1f; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #333; border-left: 4px solid #ffc107;">
                <div style="font-size:12px; color:#a6b0b9; margin-bottom:5px;">👤 От: <?php echo htmlspecialchars($p['name']); ?> | 📂 Рубрика: <?php echo htmlspecialchars($p['rubric']); ?> | 📅 <?php echo $p['date']; ?></div>
                <div style="font-weight:bold; font-size:16px; margin-bottom:5px; color:#fff;">🎬 Заголовок: <?php echo htmlspecialchars($p['title']); ?></div>
                <div style="font-size:14px; white-space:pre-wrap; color:#e9ecef; margin-bottom:15px; line-height:1.4;"><?php echo htmlspecialchars($p['text']); ?></div>
                
                <!-- Форма быстрого ответа администрации -->
                <form method="POST" style="background:#2d2d2d; padding:10px; border-radius:6px; margin-bottom:15px; border:1px solid #444;">
                    <input type="hidden" name="action" value="add_reply">
                    <input type="hidden" name="post_id" value="<?php echo $p['id']; ?>">
                    <label style="font-size:12px; color:#ffc107; margin-bottom:5px;">Выполнить задачу (Ответ администрации):</label>
                    <input type="text" name="reply_text" placeholder="Комментарий выполнения (Например: Ролик готов!)" style="width:100%; padding:6px; margin-bottom:5px; background:#1a1a1a; border:1px solid #444; color:#fff; border-radius:4px;">
                    <input type="url" name="reply_url" placeholder="Ссылка на результат на снять.рус" style="width:100%; padding:6px; margin-bottom:8px; background:#1a1a1a; border:1px solid #444; color:#fff; border-radius:4px;">
                    <button type="submit" style="padding:5px 12px; font-size:12px; width:auto; background:#28a745; color:#fff; border:0; border-radius:4px; font-weight:bold; cursor:pointer;">Добавить ответ</button>
                </form>

                <div style="display:flex; gap:10px;">
                    <a href="?id=<?php echo $p['id']; ?>&go=approve" style="background:#007bff; color:#fff; padding:8px 15px; border-radius:4px; text-decoration:none; font-weight:bold; font-size:13px; text-align:center; flex-grow:1;">👍 Одобрить и выпустить на сайт</a>
                    <a href="?id=<?php echo $p['id']; ?>&go=delete" style="background:#dc3545; color:#fff; padding:8px 15px; border-radius:4px; text-decoration:none; font-weight:bold; font-size:13px; text-align:center;" onclick="return confirm('Удалить промт навсегда?')">🗑️ Удалить</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <div style="text-align:center; font-size:11px; color:#565e64; margin-top:20px; font-weight:bold;">
        © 2026 PIG-CMS v1.0 [TASKS-ENGINE] <br>
        Единая экосистема распределения творческих задач хаба
    </div>
</div>

</body>
</html>
