<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/../core/config.php';

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: index.php');
    exit;
}

$data_dir = __DIR__ . '/../data/video_posts/';
if (!is_dir($data_dir)) mkdir($data_dir, 0755, true);

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $video_url = trim($_POST['video_url']);
    $poster_url = trim($_POST['poster_url'] ?? '');
    $description = trim($_POST['description']);

    if (!empty($title) && !empty($video_url)) {
        $post_id = time() . rand(100, 999);
        
        $videoData = [
            'title' => $title,
            'video_url' => $video_url,
            'poster_url' => $poster_url,
            'description' => $description,
            'author' => $_SESSION['username'],
            'date' => time()
        ];

        file_put_contents($data_dir . $post_id . '.json', json_encode($videoData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        if (file_exists(__DIR__ . '/../core/sitemap_gen.php')) { include __DIR__ . '/../core/sitemap_gen.php'; }
        
        $message = "<p style='color:#28a745; font-weight:bold;'>Видео успешно добавлено в хаб!</p>";
    } else {
        $message = "<p style='color:#d9534f;'>Заполните обязательные поля!</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Добавить видеоинструкцию — Панель</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="form-wrap">
    <h2 style="text-align:center; margin-top:0;">Новая видео-публикация</h2>
    <?php if(!empty($message)) echo $message; ?>
    <form method="POST">
        <label>Название видео / Заголовок инструкции *:</label>
        <input type="text" name="title" required placeholder="Например: Как настроить цвет у ПиГ КМС">

        <label>Ссылка на видео (прямая ссылка на файл) *:</label>
        <input type="url" name="video_url" required placeholder="https://PIG-CMS.name...">

        <label>Ссылка на обложку-превью (необязательно, подтянется авто если есть имя-poster.jpg):</label>
        <input type="text" name="poster_url" placeholder="/media/images/cover.jpg">

        <label>Описание видео (детали, таймкоды, ссылки):</label>
        <textarea name="description" rows="8" placeholder="Опишите суть видео-урока или блога..."></textarea>

        <button type="submit" class="btn-success">Опубликовать видео-лекцию</button>
    </form>
    <div class="back-btn"><a href="index.php">← Назад в меню админки</a></div>
</div>
</body>
</html>
