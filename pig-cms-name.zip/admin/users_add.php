<?php
/* 
 * 🐷 PIG-CMS
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * Свободный интернет без матричных алгоритмов
 * © 2026 pig-cms.name & Доктор Шрам
 */

require_once __DIR__ . '/../core/config.php';

if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: index.php');
    exit;
}

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $new_login = trim(strip_tags($_POST['new_login'] ?? ''));
    $new_pass  = trim(strip_tags($_POST['new_pass'] ?? ''));

    if (!empty($new_login) && !empty($new_pass)) {
        if (array_key_exists($new_login, $users)) {
            $msg = "<p style='color:#d9534f; font-weight:bold;'>Ошибка: Автор с таким логином уже зарегистрирован!</p>";
        } else {
            $hashed_pass = pig_hash_pass($new_pass);
            $saved = pig_json_update($FILE_USERS, function($u) use ($new_login, $hashed_pass) {
                $u[$new_login] = $hashed_pass;
                return $u;
            }, $users);

            if ($saved !== false) {
                $users = $saved;
                $msg = "<p style='color:#28a745; font-weight:bold;'>Автор успешно зарегистрирован в B2B-ХАБЕ!</p>";
            } else {
                $msg = "<p style='color:#d9534f; font-weight:bold;'>Ошибка записи в базу пользователей!</p>";
            }
        }
    } else {
        $msg = "<p style='color:#d9534f;'>Заполните все обязательные поля!</p>";
    }
}
?>
    
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация авторов — B2B-ХАБ</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
<div class="form-wrap" style="max-width: 450px;">
    <h2 style="text-align:center; margin-top:0; color:#fff;">Регистрация автора</h2>
    <p style="text-align:center; color:#aaa; font-size:13px; margin-bottom:20px;">Новый аккаунт будет мгновенно занесен в общую базу доступов хаба</p>
    
    <?php if(!empty($msg)) echo $msg; ?>
    
    <form method="POST">
        <label>Логин / Ник автора (латиница и цифры):</label>
        <input type="text" name="new_login" required placeholder="Например: photo_pro" autocomplete="off">
        
        <label>Пароль доступа для автора:</label>
        <input type="text" name="new_pass" required placeholder="Придумайте надежный пароль" autocomplete="off">
        
        <button type="submit" name="add_user" class="btn-success">Выдать доступ в B2B-ХАБ 🚀</button>
    </form>
    <div class="back-btn"><a href="index.php">← Назад в меню админки</a></div>
</div>
</body>
</html>
