<?php
/* 
 * 🐷 PIG-CMS  — Публикация и удаление объявлений в Маркете
 * © 2026 pig-cms.name & Доктор Шрам
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Защита шлюза
if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
    header('Location: index.php'); exit;
}

require_once __DIR__ . '/../core/config.php';
$dir = __DIR__ . '/../data/market_posts/';
$username = $_SESSION['username'] ?? 'Admin';
$is_admin = ($username === 'admin');
$message = '';

// ==================== ЛОГИКА УДАЛЕНИЯ ОБЪЯВЛЕНИЯ ====================
if (isset($_GET['delete'])) {
    $delete_id = trim($_GET['delete']);
    $target_file = $dir . $delete_id . '.json';

    if (file_exists($target_file)) {
        $p_data = json_decode(file_get_contents($target_file), true);
        
        // Жесткая проверка прав: сносить может либо сам автор, либо root-админ
        if ($is_admin || (isset($p_data['author']) && $p_data['author'] === $username)) {
            @unlink($target_file);
            
            // Сразу пинаем генератор карты сайта для обновления SEO
            if (file_exists(__DIR__ . '/../core/sitemap_gen.php')) { include __DIR__ . '/../core/sitemap_gen.php'; }
            
            header('Location: market_add.php?msg=success');
            exit;
        } else {
            $message = "<p style='color:#dc3545; text-align:center;'>⛔ ОШИБКА: У вас нет прав на удаление чужого товара!</p>";
        }
    }
}

if (isset($_GET['msg']) && $_GET['msg'] === 'success') {
    $message = "<p style='color:#28a745; font-weight:bold; text-align:center;'>Объявление успешно стерто из базы данных!</p>";
}

// ==================== ЛОГИКА ДОБАВЛЕНИЯ ОБЪЯВЛЕНИЯ ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_submit'])) {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $img_url = trim($_POST['img_url'] ?? '');
    $target_url = trim($_POST['target_url'] ?? '');

    if (!empty($title) && !empty($img_url) && !empty($target_url)) {
        $post_id = time() . rand(100, 999);
        $postData = [
            'title' => $title,
            'description' => mb_substr($description, 0, 2000, 'UTF-8'),
            'img_url' => $img_url,
            'target_url' => $target_url,
            'author' => $username,
            'date' => time()
        ];

        if (!is_dir($dir)) mkdir($dir, 0755, true);
        file_put_contents($dir . $post_id . '.json', json_encode($postData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        if (file_exists(__DIR__ . '/../core/sitemap_gen.php')) { include __DIR__ . '/../core/sitemap_gen.php'; }
        $message = "<p style='color:#28a745; font-weight:bold; text-align:center;'>Объявление выставлено в маркет!</p>";
    } else { 
        $message = "<p style='color:#dc3545; text-align:center;'>Заполните обязательные поля!</p>"; 
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Управление объявлениями — PIG-CMS</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body style="background:#0b0b0b; color:#fff; font-family:monospace; padding:20px;">
<div style="max-width:550px; margin:0 auto; background:#111; padding:20px; border:1px solid #222; border-radius:6px;">
    
    <h3 style="margin-top:0; color:#e67e22; text-align:center;">🛍️ МАРКЕТПЛЕЙС АВТОРА</h3>
    <?php if($message) echo $message; ?>
    
    <!-- ФОРМА ДОБАВЛЕНИЯ -->
    <form method="POST" style="display:flex; flex-direction:column; gap:12px; border-bottom:1px dashed #333; padding-bottom:20px; margin-bottom:20px;">
        <label>Что продаем *:<br><input type="text" name="title" required style="width:100%; background:#1a1a1a; border:1px solid #333; color:#fff; padding:6px; margin-top:4px; font-family:monospace;"></label>
        <label>Описание, цена, контакты:<br><textarea name="description" rows="4" style="width:100%; background:#1a1a1a; border:1px solid #333; color:#fff; padding:6px; margin-top:4px; font-family:monospace;"></textarea></label>
        <label>Ссылка на превью (URL) *:<br><input type="url" name="img_url" required style="width:100%; background:#1a1a1a; border:1px solid #333; color:#fff; padding:6px; margin-top:4px; font-family:monospace;"></label>
        <label>Куда гнать покупателя (ЛС/ТГ) *:<br><input type="url" name="target_url" required style="width:100%; background:#1a1a1a; border:1px solid #333; color:#fff; padding:6px; margin-top:4px; font-family:monospace;"></label>
        <button type="submit" name="add_submit" style="background:#e67e22; color:#fff; border:none; padding:10px; font-weight:bold; cursor:pointer; font-family:monospace; text-transform:uppercase;">Выставить на доску</button>
    </form>

    <!-- СПИСОК АКТИВНЫХ ОБЪЯВЛЕНИЙ -->
    <h4 style="color:#666; margin:0 0 10px 0; font-size:12px;">📋 Ваши активные объявления в маркете:</h4>
    <?php
    $files = glob($dir . "*.json");
    $has_posts = false;
    if (!empty($files)) {
        echo '<ul style="list-style:none; padding:0; margin:0; display:flex; flex-direction:column; gap:8px; font-size:12px;">';
        foreach ($files as $f) {
            $d = json_decode(file_get_contents($f), true);
            if ($d) {
                $post_author = $d['author'] ?? 'Admin';
                
                // Автор видит только своё, админ — всё
                if ($is_admin || $post_author === $username) {
                    $has_posts = true;
                    $fid = basename($f, '.json');
                    echo '<li style="background:#1a1a1a; padding:8px; display:flex; justify-content:space-between; align-items:center; border-radius:4px;">';
                    echo '<span>🛍️ ' . htmlspecialchars($d['title']) . '</span>';
                    echo '<a href="market_add.php?delete=' . $fid . '" onclick="return confirm(\'Точно удалить товар?\')" style="color:#dc3545; text-decoration:none; font-weight:bold; border:1px solid #dc3545; padding:2px 6px; border-radius:3px; background:transparent;">❌ Удалить</a>';
                    echo '</li>';
                }
            }
        }
        echo '</ul>';
    }
    if (!$has_posts) {
        echo '<p style="color:#444; margin:0; font-size:12px; text-align:center;">У вас пока нет активных объявлений на доске.</p>';
    }
    ?>

    <div style="text-align:center; margin-top:20px;"><a href="index.php" style="color:#666; text-decoration:none; font-size:12px;">← Вернуться в админку</a></div>
</div>
</body>
</html>
