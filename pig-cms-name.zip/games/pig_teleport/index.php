<?php
/*
 * 🪐 PIG-TELEPORT — Межсайтовый Телепорт и Оборона Квадранта
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME ★ Доктор Шрам
 */

if (!defined('PIG_HUB')) require_once __DIR__ . '/../../core/config.php';

$settings_path = __DIR__ . '/../../data/app_settings.json';
$settings = file_exists($settings_path) ? (json_decode(file_get_contents($settings_path), true) ?: []) : [];
$my_host = strtolower(preg_replace('/^www\./i', '', $_SERVER['HTTP_HOST'] ?? ''));
$message = '';

// 1. Включение щита
if (isset($_POST['activate_guard'])) {
    $settings['guard_until'] = time() + 86400;
    file_put_contents($settings_path, json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    $message = "<p class='tele-alert success'>🐷 КУПОЛ ЗАРЯЖЕН на 24 часа!</p>";
}

$hub = defined('PIG_HUB') ? rtrim(PIG_HUB, '/') : 'https://pig-cms.name';
$time_left = intval($settings['guard_until'] ?? 0) - time();
?>
<link rel="stylesheet" href="/assets/css/teleport.css?v=<?= time() ?>">

<div class="tele-container">
    <a href="games.php" class="back-link-tele">📂 [ВИТРИНА PIG-ARCADE]</a>
    <h1 class="tele-title">🪐 PIG-TELEPORT 🪐</h1>

    <div class="tele-log" id="tele-log">
        📡 <b>ЛОГ КВАДРАНТА:</b> Сканирование варп-каналов... Щит действует 24 часа.
    </div>

    <div id="raid-result"><?= $message ?></div>

    <h3 style="color:#fff;margin-top:20px;">🛡️ ОБОРОНА ХАБА</h3>
    <?php if ($time_left > 0): ?>
        <div class="tele-badge shield-up">🔒 КУПОЛ АКТИВЕН: <?= floor($time_left / 3600) ?>ч. <?= floor(($time_left % 3600) / 60) ?>мин.</div>
        <form method="POST"><button type="submit" name="activate_guard" class="btn-tele-guard btn-recharge">🔄 ОБНОВИТЬ СТОРОЖА (24 ЧАСА)</button></form>
    <?php else: ?>
        <div class="tele-badge shield-down">🔓 КУПОЛ ОТКЛЮЧЕН! СЕКТОР УЯЗВИМ!</div>
        <form method="POST"><button type="submit" name="activate_guard" class="btn-tele-guard">🚨 НАНЯТЬ СТОРОЖА</button></form>
    <?php endif; ?>

    <h3 style="color:#fff;margin-top:25px;">🛸 ЦЕЛИ ДЛЯ НАБЕГА</h3>
    <div id="planets-list"><p style="color:#888;font-size:13px;">⏳ Загрузка радара Квадранта...</p></div>
</div>

<script>
const MY_HOST = <?= json_encode($my_host) ?>;
const RADAR_URL = <?= json_encode($hub . '/api/galaxy_list.php') ?>;

function esc(s) {
    return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

async function attackPlanet(url, title) {
    const box = document.getElementById('raid-result');
    box.innerHTML = `<p class='tele-alert' style='color:#66ccff;'>🚀 Отправляем Хрюндиков на <b>${esc(title)}</b>...</p>`;
    const endpoint = url.replace(/\/$/, '') + '/core/pig_net.php?action=portal';
    try {
        const r = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ thief_site: MY_HOST })
        });
        const res = await r.json();
        if (res.status === 'success' && res.allowed === true) {
            box.innerHTML = `<p class='tele-alert success'>🚀 НАБЕГ НА [${esc(title)}]: ${esc(res.message)} (+${parseInt(res.loot || 0)} Хрюн-койнов!)</p>`;
        } else {
            box.innerHTML = `<p class='tele-alert' style='color:#ff6666;'>🛡️ ОХРАНА [${esc(title)}]: ${esc(res.message || 'Набег отбит!')}</p>`;
        }
    } catch (e) {
        box.innerHTML = `<p class='tele-alert' style='color:#ffaa00;'>📡 Планета [${esc(title)}] не отвечает (узел спит или устарела версия ядра).</p>`;
    }
}

fetch(RADAR_URL)
    .then(r => r.json())
    .then(list => {
        const now = Math.floor(Date.now() / 1000);
        const targets = (list || []).filter(p => {
            try { return new URL(p.url).hostname.replace(/^www\./, '').toLowerCase() !== MY_HOST; }
            catch (e) { return false; }
        });
        document.getElementById('tele-log').innerHTML = `📡 <b>ЛОГ КВАДРАНТА:</b> В радиусе прыжка планет: <b>${targets.length}</b>. Щит действует 24 часа.`;
        const box = document.getElementById('planets-list');
        if (!targets.length) {
            box.innerHTML = `<p style="color:#888;font-size:13px;">🌌 Соседних планет пока не обнаружено.</p>`;
            return;
        }
        box.innerHTML = targets.map(p => {
            const shield = parseInt(p.guard_until || 0) > now;
            return `<div style="border:1px solid #333;padding:12px;margin:10px 0;border-radius:8px;display:flex;justify-content:space-between;align-items:center;text-align:left;">
                <div>
                    <b style="color:#fff;">🪐 ${esc(p.title || 'Планета')}</b><br>
                    <small style="color:${shield ? '#ff6666' : '#00ff88'};">${shield ? '🛡️ Под куполом' : '🔓 Щиты отключены'}</small>
                </div>
                <button type="button" onclick='attackPlanet(${JSON.stringify(p.url)}, ${JSON.stringify(p.title || "Планета")})' class="btn-tele-guard" style="padding:8px 14px;margin:0;font-size:12px;">🚀 В НАБЕГ!</button>
            </div>`;
        }).join('');
    })
    .catch(() => {
        document.getElementById('planets-list').innerHTML = `<p style="color:#ffaa00;font-size:13px;">📡 Радар временно недоступен.</p>`;
    });
</script>
