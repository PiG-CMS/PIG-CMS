<?php
session_start();
/* 
 * 🐷 PIG-INSPECTOR — Игра на букву "I" для сборки слова P-I-G
 * [Pi_Ti & Google Hub] ★ [People, Internet, Global]
 * © 2026 PIG-CMS.NAME & Доктор Шрам
 */

$leaderboard_file = 'data/games_posts/inspector_top.json';

// Шлюз AJAX-рекордов
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_score') {
    $name = htmlspecialchars(trim($_POST['name'] ?? 'Анонимный Инспектор'));
    $score = intval($_POST['score'] ?? 9999); // Счет — это время реакции в мс
    
    $status = 'guest';
    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
        $status = ($_SESSION['username'] === 'admin') ? 'admin' : 'author';
        $name = $_SESSION['username'];
    }
    
    $leaderboard = [];
    if (file_exists($leaderboard_file)) {
        $leaderboard = json_decode(file_get_contents($leaderboard_file), true) ?: [];
    }
    
    $leaderboard[] = ['name' => $name, 'score' => $score, 'date' => date('d.m.Y H:i'), 'status' => $status];
    
    // Сортировка: чем МЕНЬШЕ миллисекунд, тем выше место!
    usort($leaderboard, function($a, $b) { return $a['score'] <=> $b['score']; });
    $leaderboard = array_slice($leaderboard, 0, 10);
    
    if (!is_dir('data/games_posts/')) {
        mkdir('data/games_posts/', 0777, true);
    }
    file_put_contents($leaderboard_file, json_encode($leaderboard, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    header('Content-Type: application/json');
    echo json_encode($leaderboard);
    exit;
}

$top_players = [];
if (file_exists($leaderboard_file)) {
    $top_players = json_decode(file_get_contents($leaderboard_file), true) ?: [];
}
?>

<script src="/games/js/score_sender.js?v=<?= time() ?>" defer></script>

<div class="game-container" style="max-width: 600px; margin: 30px auto; text-align: center; font-family: monospace;">
    <a href="/games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h1>🕵️‍♂️ PIG-INSPECTOR 🕵️‍♂️</h1>
    <p>Поймай ПиГ-инспектора! Жми на кнопку «СТАРТ», дождись появления внезапного ПиГа 🐷 и кликни по нему максимально быстро!</p>
    
    <div style="background: #222; color: #fff; padding: 20px; border-radius: 10px; min-height: 200px; display: flex; flex-direction: column; justify-content: center; align-items: center; position: relative;">
        <button id="start-inspect-btn" style="padding: 12px 24px; background: #ffb703; color: #111; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 1.1rem;">СТАРТ ТЕСТА</button>
        
        <!-- Заменили злую кляксу на маскота ПиГ -->
        <div id="bug-target" style="display: none; font-size: 60px; cursor: pointer; user-select: none; position: absolute;">🐷</div>
        <h3 id="inspect-status" style="color: #aaa; margin-top: 15px;"></h3>
    </div>

    <!-- Блок рекорда -->
    <div id="record-block" style="display: none; margin-top: 20px; background: #222222; padding: 20px; border-radius: 10px; border: 1px solid #ffb703;">
        <h3 style="margin-top: 0; color: #ffb703; text-transform: uppercase; font-size: 1rem;">🎉 Отличная реакция! Запиши результат</h3>
        <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
            <input type="text" id="player-name" placeholder="Твое имя" value="<?= $_SESSION['username'] ?? '' ?>" <?= isset($_SESSION['auth']) ? 'disabled style="padding: 10px; background: #111; color: #28a745; border: 1px solid #28a745; border-radius: 4px;"' : 'style="padding: 10px; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px;"' ?>>
            <button id="send-score-btn" style="padding: 10px 20px; background: #ffb703; color: #111; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">ОТПРАВИТЬ</button>
        </div>
    </div>

    <!-- Таблица ТОП-10 -->
    <div style="margin-top: 20px; text-align: left; background: #222222; padding: 15px; border-radius: 10px; border: 1px solid #444;">
        <h3 style="text-align: center; margin-top: 0; color: #ffb703;">🏆 ТОП-10 СВЕРХБЫСТРЫХ ИНСПЕКТОРОВ</h3>
        <ol id="leaderboard-list" style="padding-left: 20px; color: #ffffff; margin: 0;">
            <?php if (empty($top_players)): ?>
                <li style="color: #aaaaaa;">Таблица пуста. Зафиксируй первый баг!</li>
            <?php else: ?>
                <?php foreach ($top_players as $player): ?>
                    <?php 
                    $status = $player['status'] ?? 'guest';
                    $badge = ($status === 'admin') ? '<span style="background: #dc3545; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight:bold;">АДМИН</span>' : (($status === 'author') ? '<span style="background: #28a745; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight:bold;">АВТОР</span>' : '<span style="background: #555; color: #ccc; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px;">ГОСТЬ</span>');
                    ?>
                    <li style="margin-bottom: 8px; color: #ffffff;">
                        <?= $badge ?> <strong style="color: #ffb703;"><?= htmlspecialchars($player['name']) ?></strong> — 
                        <span style="color: #fff; font-weight: bold;"><?= $player['score'] ?> мс</span> 
                        <span style="color: #888888; font-size: 0.8rem;">(<?= $player['date'] ?>)</span>
                    </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ol>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const startBtn = document.getElementById("start-inspect-btn");
    const bug = document.getElementById("bug-target");
    const status = document.getElementById("inspect-status");
    const recordBlock = document.getElementById("record-block");
    const sendBtn = document.getElementById("send-score-btn");
    
    let startTime, delayTimer;
    let reactionTime = 0;

    startBtn.addEventListener("click", () => {
        startBtn.style.display = "none";
        recordBlock.style.display = "none";
        status.innerText = "Сканирование эфира... Жди появления ПиГа...";
        status.style.color = "#ffb703";
        
        // Случайная задержка появления бага от 2 до 5 секунд
        const randomDelay = Math.floor(Math.random() * 3000) + 2000;
        
        delayTimer = setTimeout(() => {
            status.innerText = "🚨 ПИГ ОБНАРУЖЕН! ЛОВИ ЕГО!";
            status.style.color = "#ff3333";
            
            // Рандомим позицию смайлика внутри контейнера
            bug.style.top = (Math.random() * 100 + 40) + "px";
            bug.style.left = (Math.random() * 70 + 15) + "%";
            bug.style.display = "block";
            
            startTime = new Date().getTime();
        }, randomDelay);
    });

    bug.addEventListener("click", () => {
        const endTime = new Date().getTime();
        bug.style.display = "none";
        
        reactionTime = endTime - startTime;
        status.innerText = `🎯 ПиГ пойман за ${reactionTime} миллисекунд!`;
        status.style.color = "#28a745";
        
        startBtn.innerText = "ПОПРОБОВАТЬ СНОВА";
        startBtn.style.display = "inline-block";
        recordBlock.style.display = "block";
    });

    sendBtn.addEventListener("click", () => {
        const name = document.getElementById("player-name").value.trim() || "Анонимный Инспектор";
        // Шлём результат в созданный score_sender.js, передавая ID новой игры "inspector"
        sendPigGameScore("inspector", name, reactionTime, () => {
            alert("Результат занесён в реестр инспекторов!");
            recordBlock.style.display = "none";
        });
    });
});
</script>
