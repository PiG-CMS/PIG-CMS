<?php
/* 
 * 🐷 PIG-CMS — СУВЕРЕННЫЕ ВЕРТИКАЛЬНЫЕ ГОНКИ (БЭКЕНД И ИНТЕРФЕЙС)
 * © 2026 pig-cms.name & PiTi
 */

$leaderboard_file = 'data/games_posts/racer_top.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_score') {
    $name = htmlspecialchars(trim($_POST['name'] ?? 'Анонимный Гонщик'));
    $score = intval($_POST['score'] ?? 0);
    
    $status = 'guest';
    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
        $status = ($_SESSION['username'] === 'admin') ? 'admin' : 'author';
        $name = $_SESSION['username'];
    }
    
    $leaderboard = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
    $leaderboard[] = ['name' => $name, 'score' => $score, 'date' => date('d.m.Y H:i'), 'status' => $status];
    
    usort($leaderboard, function($a, $b) { return $b['score'] <=> $a['score']; });
    $leaderboard = array_slice($leaderboard, 0, 10);
    
    if (!is_dir('data/games_posts/')) { mkdir('data/games_posts/', 0777, true); }
    file_put_contents($leaderboard_file, json_encode($leaderboard, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    header('Content-Type: application/json');
    echo json_encode($leaderboard);
    exit;
}

$top_players = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
?>

<div id="pig-game-area" style="max-width: 500px; margin: 20px auto; text-align: center; font-family: monospace; background: #111; padding: 15px; border-radius: 8px; border: 2px solid #ffb703; position: relative;">
    <button id="fs-btn" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; background: #ffb703; border: none; cursor: pointer; font-weight: bold; font-size: 0.8rem; z-index: 10;">📺 НА ВЕСЬ ЭКРАН</button>
    
    <a href="games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h2 style="color: #ffb703; margin-top: 10px;">🏎️ PIG-RACER: ОБХОД МАТРИЦЫ 🏎️</h2>
    <p style="color: #888; font-size: 0.8rem;">Стрелки Влево/Вправо, кнопки A/D или Тап по краям экрана.</p>
    
    <canvas id="raceCanvas" width="360" height="450" style="background: #222; display: block; margin: 0 auto; border: 2px solid #444; max-width: 100%;"></canvas>
    
    <div id="score-board" style="color: #fff; margin-top: 10px; font-size: 1.2rem;">Очки: <span id="current-score">0</span></div>
    <button id="start-race-btn" style="margin-top: 10px; padding: 10px 20px; background: #00ff66; border: none; font-weight: bold; cursor: pointer; border-radius: 4px; font-family: monospace;">ПОГНАЛИ</button>

    <!-- Форма рекорда -->
    <div id="record-block" style="display: none; margin-top: 20px; background: #222222; padding: 20px; border-radius: 10px; border: 1px solid #ffb703;">
        <h3 style="margin-top: 0; color: #ffb703; text-transform: uppercase; font-size: 1rem;">🎉 Запиши рекорд в JSON!</h3>
        <?php if (isset($_SESSION['auth']) && $_SESSION['auth'] === true): ?>
            <p style="color: #aaa; font-size: 13px; margin: 10px 0;">Вы авторизованы как <b style="color:#28a745;">@<?= $_SESSION['username'] ?></b>.</p>
        <?php endif; ?>
        <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
            <input type="text" id="player-name" placeholder="Никнейм" value="<?= $_SESSION['username'] ?? '' ?>" <?= isset($_SESSION['auth']) ? 'disabled style="padding: 10px; background: #222; color: #28a745; border: 1px solid #28a745; border-radius: 4px; flex-grow: 1; font-family: monospace; font-weight:bold;"' : 'style="padding: 10px; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px; flex-grow: 1; font-family: monospace; outline: none;"' ?>>
            <button id="send-score-btn" style="padding: 10px 20px; background: #ffb703; color: #111; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-family: monospace;">ОТПРАВИТЬ</button>
        </div>
    </div>

    <!-- Таблица лидеров -->
    <div style="margin-top: 20px; text-align: left; background: #222222; padding: 15px; border-radius: 10px; border: 1px solid #444;">
        <h3 style="text-align: center; margin-top: 0; color: #ffb703;">🏆 ТОП ГОНЩИКОВ ХАБА</h3>
        <ol id="leaderboard-list" style="padding-left: 20px; color: #ffffff; margin: 0;">
            <?php if (empty($top_players)): ?>
                <li style="color: #aaaaaa;">Таблица пуста. Стань первым!</li>
            <?php else: ?>
                <?php foreach ($top_players as $player): ?>
                    <?php 
                        $status = $player['status'] ?? 'guest';
                        $badge = ($status === 'admin') ? '<span style="background: #dc3545; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight:bold;">АДМИН</span>' : (($status === 'author') ? '<span style="background: #28a745; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight:bold;">АВТОР</span>' : '<span style="background: #555; color: #ccc; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px;">ГОСТЬ</span>');
                    ?>
                    <li style="margin-bottom: 8px; color: #ffffff;">
                        <?= $badge ?> <strong style="color: #ffb703;"><?= htmlspecialchars($player['name']) ?></strong> — 
                        <span style="color: #fff; font-weight: bold;"><?= $player['score'] ?> очков</span> 
                        <span style="color: #888888; font-size: 0.8rem;">(<?= $player['date'] ?>)</span>
                    </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ol>
    </div>
</div>

<!-- Подключаем универсальный движок гонок и транспорт -->
<script src="games/js/score_sender.js" defer></script>
<script src="games/js/pig_racer_engine.js" defer></script>
