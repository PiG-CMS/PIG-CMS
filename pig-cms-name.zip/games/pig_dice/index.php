<?php
/* 
 * 🕹️ PIG-ARCADE — Кости Судьбы (index.php)
 * [Pi_Ti & Google Hub] ★ © 2026 PIG-CMS.NAME
 */
require_once '../../core/config.php';
$page_title = "Кости Судьбы — PIG-ARCADE";
include_once '../../core/header.php';
?>
<div class="single-post-wrap" style="max-width: 500px; margin: 40px auto; text-align: center; font-family: monospace;">
    <h2 style="color: #ffb703;">🎲 КОСТИ СУДЬБЫ (PIG-DICE)</h2>
    <p style="color: #ccc; font-size: 13px;">Бросьте вызов случайным числам суверенного генератора!</p>
    
    <div style="display: flex; justify-content: center; gap: 30px; margin: 30px 0;">
        <div style="background: #111; border: 2px solid #ffb703; border-radius: 12px; width: 80px; height: 80px; font-size: 40px; line-height: 80px; color: #fff;" id="dice-1">⚀</div>
        <div style="background: #111; border: 2px solid #ffb703; border-radius: 12px; width: 80px; height: 80px; font-size: 40px; line-height: 80px; color: #fff;" id="dice-2">⚀</div>
    </div>
    
    <div id="dice-result" style="font-size: 18px; font-weight: bold; color: #ffc107; margin-bottom: 25px; min-height: 24px;">Нажмите кнопку, чтобы сделать бросок!</div>
    <button class="page-btn" onclick="rollDice()" style="padding: 12px 30px; font-size: 14px; text-transform: uppercase;">🎲 Бросить кости</button>
</div>

<script>
const diceFaces = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
function rollDice() {
    const r1 = Math.floor(Math.random() * 6);
    const r2 = Math.floor(Math.random() * 6);
    document.getElementById("dice-1").innerText = diceFaces[r1];
    document.getElementById("dice-2").innerText = diceFaces[r2];
    const total = (r1 + 1) + (r2 + 1);
    document.getElementById("dice-result").innerText = "Вы выбили: " + total + " очков!";
}
</script>
<?php include_once '../../core/footer.php'; ?>
