/* 
 * 🐷 PIG-CLICKER — Локальная экономика и UI кликера
 * © 2026 pig-cms.name & Доктор Шрам
 */
document.addEventListener("DOMContentLoaded", () => {
    let coins = parseInt(localStorage.getItem("pig_coins")) || 0;
    let clickPower = parseInt(localStorage.getItem("pig_power")) || 1;
    let autoPower = parseInt(localStorage.getItem("pig_auto")) || 0;
    let clickCost = parseInt(localStorage.getItem("pig_click_cost")) || 15;
    let autoCost = parseInt(localStorage.getItem("pig_auto_cost")) || 50;

    const coinsCountEl = document.getElementById("coins-count");
    const clickPowerEl = document.getElementById("click-power");
    const cpsEl = document.getElementById("cps");
    const pigBtn = document.getElementById("pig-button");
    const buyClickBtn = document.getElementById("buy-click");
    const buyAutoBtn = document.getElementById("buy-auto");
    const clickCostEl = document.getElementById("click-cost");
    const autoCostEl = document.getElementById("auto-cost");

    function updateUI() {
        coinsCountEl.innerText = coins;
        clickPowerEl.innerText = clickPower;
        cpsEl.innerText = autoPower;
        clickCostEl.innerText = clickCost;
        autoCostEl.innerText = autoCost;
        
        localStorage.setItem("pig_coins", coins);
        localStorage.setItem("pig_power", clickPower);
        localStorage.setItem("pig_auto", autoPower);
        localStorage.setItem("pig_click_cost", clickCost);
        localStorage.setItem("pig_auto_cost", autoCost);
    }

    pigBtn.addEventListener("click", () => {
        coins += clickPower;
        pigBtn.style.transform = "scale(0.85)";
        setTimeout(() => pigBtn.style.transform = "scale(1)", 50);
        updateUI();
    });

    buyClickBtn.addEventListener("click", () => {
        if (coins >= clickCost) {
            coins -= clickCost;
            clickPower += 1;
            clickCost = Math.floor(clickCost * 1.5);
            updateUI();
        } else { alert("Не хватает хрю-коинов!"); }
    });

    buyAutoBtn.addEventListener("click", () => {
        if (coins >= autoCost) {
            coins -= autoCost;
            autoPower += 1;
            autoCost = Math.floor(autoCost * 1.6);
            updateUI();
        } else { alert("Не хватает хрю-коинов!"); }
    });

    setInterval(() => {
        if (autoPower > 0) {
            coins += autoPower;
            updateUI();
        }
    }, 1000);

    // Переключаем на оптимизированный транспорт рекордов
    document.getElementById("send-score-btn").addEventListener("click", () => {
        const name = document.getElementById("player-name").value.trim() || "Анонимный Хрюк";
        sendPigGameScore("clicker", name, coins, () => {
            alert("Рекорд успешно сохранен в ТОП-10!");
        });
    });

    // ЛОГИКА АКТИВАЦИИ ЧИТ-КОДОВ (Теперь строго ВНУТРИ контекста игры)
    const promoBtn = document.getElementById("promo-btn");
    if (promoBtn) {
        promoBtn.addEventListener("click", () => {
            const promoInput = document.getElementById("promo-input");
            const codeValue = promoInput.value.trim();

            if (!codeValue) return;

            const formData = new FormData();
            formData.append("action", "use_promo");
            formData.append("code", codeValue);

            fetch("/games.php?play=clicker", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    coins += parseInt(data.bonus); // Теперь переменная coins доступна и видна!
                    updateUI();                   // Функция updateUI() тоже успешно вызывается!
                    
                    let remainsText = (parseInt(data.remains) > 0) 
                        ? `Налетай! Осталось всего активаций: ${data.remains}` 
                        : `Ты забрал ПОСЛЕДНИЙ код из раздачи! Больше лимита нет.`;
                    
                    alert(`🔥 Чит-код успешно активирован! Начислено +${data.bonus} 🪙\n⚠️ ${remainsText}`);
                    promoInput.value = "";
                } else {
                    alert(`❌ Ошибка: ${data.message}`);
                }
            })
            .catch(err => {
                console.error(err);
                alert("Ошибка связи с сервером кодов или сбой обработки данных");
            });
        });
    }

    updateUI();
});
