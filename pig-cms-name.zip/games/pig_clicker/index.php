<?php

session_start();

/* 
 * 🐷 PIG-CMS — PIG-CLICKER Бэкенд
 * © 2026 pig-cms.name & Доктор Шрам
 */

$leaderboard_file = 'data/games_posts/pig_clicker_top.json';

// Жесткий шлюз для AJAX-запросов (сохранение рекорда)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_score') {
    $name = htmlspecialchars(trim($_POST['name'] ?? 'Анонимный Хрюк'));
    $score = intval($_POST['score'] ?? 0);
    
    $status = 'guest';
    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
        $status = ($_SESSION['username'] === 'admin') ? 'admin' : 'author';
        $name = $_SESSION['username'];
    }
    
    $leaderboard = [];
    if (file_exists($leaderboard_file)) {
        $leaderboard = json_decode(file_get_contents($leaderboard_file), true) ?: [];
    }
    
    $leaderboard[] = [
        'name' => $name, 
        'score' => $score, 
        'date' => date('d.m.Y H:i'),
        'status' => $status
    ];
    
    usort($leaderboard, function($a, $b) { return $b['score'] <=> $a['score']; });
    $leaderboard = array_slice($leaderboard, 0, 10);
    
    if (!is_dir('data/games_posts/')) {
        mkdir('data/games_posts/', 0777, true);
    }
    file_put_contents($leaderboard_file, json_encode($leaderboard, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    header('Content-Type: application/json');
    echo json_encode($leaderboard);
    exit;
}

// Жесткий шлюз для проверки чит-кодов (ДОСТУП ТОЛЬКО ДЛЯ АВТОРОВ И АДМИНОВ + 1 В РУКИ)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'use_promo') {
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $promo_file = 'data/games_posts/promo_codes.json';

    // Защита №1: Гостям вход воспрещен
    if (!isset($_SESSION['auth']) || $_SESSION['auth'] !== true) {
        if (ob_get_length()) ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Чит-коды доступны строго авторизованным авторам PIG-CMS!']);
        exit;
    }

    $current_user = $_SESSION['username']; // Берем ник вошедшего автора/админа

    if (!file_exists($promo_file)) {
        if (ob_get_length()) ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Система кодов временно недоступна']);
        exit;
    }

    $codes = json_decode(file_get_contents($promo_file), true) ?: [];

    if (isset($codes[$code])) {
        // Инициализируем массив юзеров, если его забыли создать в JSON вручную
        if (!isset($codes[$code]['users']) || !is_array($codes[$code]['users'])) {
            $codes[$code]['users'] = [];
        }

        // Защита №2: Проверка на повторную активацию этим же хряком
        if (in_array($current_user, $codes[$code]['users'])) {
            if (ob_get_length()) ob_clean();
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Ты уже активировал этот чит-код ранее! Никакого дубляжа.']);
            exit;
        }

        $current_limit = intval($codes[$code]['limit'] ?? 0);
        
        if ($current_limit <= 0) {
            if (ob_get_length()) ob_clean();
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Общий лимит кодов в раздаче полностью ЗАКОНЧИЛСЬ!']);
            exit;
        } else {
            // Уменьшаем лимит и записываем наглого хряка в историю кода
            $codes[$code]['limit'] = $current_limit - 1;
            $codes[$code]['users'][] = $current_user; 
            
            file_put_contents($promo_file, json_encode($codes, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            
            if (ob_get_length()) ob_clean();
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true, 
                'bonus' => $codes[$code]['bonus'],
                'remains' => $codes[$code]['limit']
            ]);
            exit;
        }
    } else {
        if (ob_get_length()) ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Такого чит-кода не существует!']);
    }
    exit;
}

$top_players = [];
if (file_exists($leaderboard_file)) {
    $top_players = json_decode(file_get_contents($leaderboard_file), true) ?: [];
}
?>


<div class="game-container" style="max-width: 600px; margin: 30px auto; text-align: center; font-family: monospace;">
    <a href="/games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h1>🐷 PIG-CLICKER 🐷</h1>
    
    <div style="background: #222; color: #fff; padding: 20px; border-radius: 10px;">
        <h2 style="color: #ffb703;">Баланс: <span id="coins-count">0</span> 🪙</h2>
        <p style="font-size: 0.9rem; color: #aaa;">Сила клика: +<span id="click-power">1</span> | Авто-кликер: +<span id="cps">0</span>/сек</p>
        <div id="pig-button" style="font-size: 80px; cursor: pointer; user-select: none; transition: transform 0.1s; display: inline-block; margin: 20px 0;">🐷</div>
        
        <div style="margin-top: 20px; border-top: 1px solid #444; padding-top: 15px;">
            <button id="buy-click" style="padding: 10px; margin: 5px; background: #333; color: #fff; border: 1px solid #555; cursor: pointer;">💪 Качнуть клик (<span id="click-cost">15</span>)</button>
            <button id="buy-auto" style="padding: 10px; margin: 5px; background: #333; color: #fff; border: 1px solid #555; cursor: pointer;">🤖 Купить раба (<span id="auto-cost">50</span>)</button>
        </div>

        <!-- КРАСИВОЕ ПОЛЕ ДЛЯ ЧИТ-КОДОВ -->
        <div style="margin-top: 15px; border-top: 1px dashed #555; padding-top: 15px; display: flex; gap: 8px; justify-content: center;">
            <input type="text" id="promo-input" placeholder="Введите чит-код..." style="padding: 6px 10px; background: #111; color: #ffb703; border: 1px solid #444; border-radius: 4px; font-family: monospace; outline: none; width: 160px; text-transform: uppercase;">
            <button id="promo-btn" style="padding: 6px 12px; background: #ffb703; color: #111; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-family: monospace;">ВВОД</button>
        </div>
    </div>
  
    <!-- Блок фиксации рекорда -->
    <div style="margin-top: 20px; background: #222222; padding: 20px; border-radius: 10px; border: 1px solid #ffb703;">
        <h3 style="margin-top: 0; color: #ffb703; text-transform: uppercase; font-size: 1rem;">Зафиксировать рекорд в JSON</h3>
        <?php if (isset($_SESSION['auth']) && $_SESSION['auth'] === true): ?>
            <p style="color: #aaa; font-size: 13px; margin: 10px 0 0 0;">Вы авторизованы как <b style="color:#28a745;">@<?= $_SESSION['username'] ?></b>.</p>
        <?php endif; ?>

        <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
            <input type="text" id="player-name" placeholder="Твое имя/ник" value="<?= $_SESSION['username'] ?? '' ?>" <?= isset($_SESSION['auth']) ? 'disabled style="padding: 10px; background: #222; color: #28a745; border: 1px solid #28a745; border-radius: 4px; flex-grow: 1; font-family: monospace; font-weight:bold;"' : 'style="padding: 10px; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px; flex-grow: 1; font-family: monospace; outline: none;"' ?>>
            <button id="send-score-btn" style="padding: 10px 20px; background: #ffb703; color: #111; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-family: monospace;">ОТПРАВИТЬ</button>
        </div>
    </div>

    <!-- Лидерборд -->
    <div style="margin-top: 20px; text-align: left; background: #222222; padding: 15px; border-radius: 10px; border: 1px solid #444;">
        <h3 style="text-align: center; margin-top: 0; color: #ffb703;">🏆 ТОП-10 ХРЯКОВ</h3>
        <ol id="leaderboard-list" style="padding-left: 20px; color: #ffffff; margin: 0;">
            <?php if (empty($top_players)): ?>
                <li style="color: #aaaaaa;">Таблица пуста. Стань первым!</li>
            <?php else: ?>
                <?php foreach ($top_players as $player): ?>
                    <?php 
                    $p_status = $player['status'] ?? ($player['role'] ?? 'guest');
                    if ($p_status === 'admin') {
                        $badge = '<span style="background: #dc3545; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight: bold;">АДМИН</span>';
                    } elseif ($p_status === 'author') {
                        $badge = '<span style="background: #28a745; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight: bold;">АВТОР</span>';
                    } else {
                        $badge = '<span style="background: #555; color: #ccc; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight: bold;">ГОСТЬ</span>';
                    }
                    ?>
                    <li style="margin-bottom: 8px; color: #ffffff;">
                        <?= $badge ?> <strong style="color: #ffb703;"><?= htmlspecialchars($player['name']) ?></strong> — 
                        <span style="color: #fff; font-weight: bold;"><?= $player['score'] ?> 🪙</span> 
                        <span style="color: #888888; font-size: 0.8rem;">(<?= $player['date'] ?>)</span>
                    </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ol>
    </div>
</div>

<!-- ПОДКЛЮЧЕНИЕ СКРИПТОВ С ХИТРЫМ СБРОСОМ КЭША -->
<script src="/games/js/score_sender.js?v=<?= time() ?>"></script>
<script src="/games/pig_clicker/clicker.js?v=<?= time() ?>"></script>
