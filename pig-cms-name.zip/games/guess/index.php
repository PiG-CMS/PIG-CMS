<?php
/* 
 * 🐷 PIG-CMS — УГАДАЙ ЧИСЛО Бэкенд
 * © 2026 pig-cms.name & Доктор Шрам
 */

$leaderboard_file = 'data/games_posts/guess_top.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_score') {
    $name = htmlspecialchars(trim($_POST['name'] ?? 'Анонимный Мыслитель'));
    $attempts = intval($_POST['score'] ?? 99);
    
    $status = 'guest';
    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
        $status = ($_SESSION['username'] === 'admin') ? 'admin' : 'author';
        $name = $_SESSION['username'];
    }
    
    $leaderboard = [];
    if (file_exists($leaderboard_file)) {
        $leaderboard = json_decode(file_get_contents($leaderboard_file), true) ?: [];
    }
    
    $leaderboard[] = [
        'name' => $name, 
        'score' => $attempts, 
        'date' => date('d.m.Y H:i'),
        'status' => $status
    ];
    
    // Сортировка: меньше попыток = выше место
    usort($leaderboard, function($a, $b) { return $a['score'] <=> $b['score']; });
    $leaderboard = array_slice($leaderboard, 0, 10);
    
    if (!is_dir('data/games_posts/')) {
        mkdir('data/games_posts/', 0777, true);
    }
    file_put_contents($leaderboard_file, json_encode($leaderboard, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    header('Content-Type: application/json');
    echo json_encode($leaderboard);
    exit;
}

$top_players = [];
if (file_exists($leaderboard_file)) {
    $top_players = json_decode(file_get_contents($leaderboard_file), true) ?: [];
}
?>

<script src="games/js/score_sender.js" defer></script>

<div class="game-container" style="max-width: 600px; margin: 30px auto; text-align: center; font-family: monospace;">
    <a href="games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h1>🎲 УГАДАЙ ЧИСЛО 🎲</h1>
    <p>Компьютер загадал число от 1 до 100. Сможешь угадать его за минимальное число ходов?</p>
    
    <div style="background: #222; color: #fff; padding: 20px; border-radius: 10px;">
        <h3 id="game-status" style="color: #ffb703;">Игра началась! Введи число:</h3>
        <p style="font-size: 0.9rem; color: #aaa;">Попыток использовано: <span id="attempts-count">0</span></p>
        
        <div style="margin: 20px 0;">
            <input type="number" id="user-guess" min="1" max="100" style="padding: 10px; width: 80px; text-align: center; font-size: 1.2rem; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px;">
            <button id="guess-btn" style="padding: 10px 20px; background: #ffb703; color: #111; border: none; font-weight: bold; cursor: pointer; margin-left: 10px; border-radius: 4px;">ПРОВЕРИТЬ</button>
        </div>
        <button id="reset-game-btn" style="padding: 5px 10px; background: #444; color: #ccc; border: none; cursor: pointer; font-size: 0.8rem; border-radius: 4px;">Сбросить и перезагадать</button>
    </div>

    <!-- Форма отправки рекорда -->
    <div id="record-block" style="display: none; margin-top: 20px; background: #222222; padding: 20px; border-radius: 10px; border: 1px solid #ffb703;">
        <h3 style="margin-top: 0; color: #ffb703; text-transform: uppercase; font-size: 1rem;">🎉 Ты победил! Запиши рекорд в JSON</h3>
        <?php if (isset($_SESSION['auth']) && $_SESSION['auth'] === true): ?>
            <p style="color: #aaa; font-size: 13px; margin: 10px 0;">Вы авторизованы как <b style="color:#28a745;">@<?= $_SESSION['username'] ?></b>.</p>
        <?php endif; ?>

        <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
            <input type="text" id="player-name" placeholder="Твое имя/ник" value="<?= $_SESSION['username'] ?? '' ?>" <?= isset($_SESSION['auth']) ? 'disabled style="padding: 10px; background: #222; color: #28a745; border: 1px solid #28a745; border-radius: 4px; flex-grow: 1; font-family: monospace; font-weight:bold;"' : 'style="padding: 10px; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px; flex-grow: 1; font-family: monospace; outline: none;"' ?>>
            <button id="send-score-btn" style="padding: 10px 20px; background: #ffb703; color: #111; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-family: monospace;">ОТПРАВИТЬ</button>
        </div>
    </div>

    <!-- Таблица лидеров -->
    <div style="margin-top: 20px; text-align: left; background: #222222; padding: 15px; border-radius: 10px; border: 1px solid #444;">
        <h3 style="text-align: center; margin-top: 0; color: #ffb703;">🏆 ТОП УМНИКОВ (Меньше попыток = лучше!)</h3>
        <ol id="leaderboard-list" style="padding-left: 20px; color: #ffffff; margin: 0;">
            <?php if (empty($top_players)): ?>
                <li style="color: #aaaaaa;">Таблица пуста. Стань первым!</li>
            <?php else: ?>
                <?php foreach ($top_players as $player): ?>
                    <?php 
                        $status = $player['status'] ?? 'guest';
                        $badge = ($status === 'admin') ? '<span style="background: #dc3545; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight:bold;">АДМИН</span>' : (($status === 'author') ? '<span style="background: #28a745; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight:bold;">АВТОР</span>' : '<span style="background: #555; color: #ccc; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px;">ГОСТЬ</span>');
                    ?>
                    <li style="margin-bottom: 8px; color: #ffffff;">
                        <?= $badge ?> <strong style="color: #ffb703;"><?= htmlspecialchars($player['name']) ?></strong> — 
                        <span style="color: #fff; font-weight: bold;"><?= $player['score'] ?> поп.</span> 
                        <span style="color: #888888; font-size: 0.8rem;">(<?= $player['date'] ?>)</span>
                    </li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ol>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    let secretHiddenNumber = Math.floor(Math.random() * 100) + 1;
    let attempts = 0;
    let gameOver = false;

    const statusEl = document.getElementById("game-status");
    const attemptsEl = document.getElementById("attempts-count");
    const guessInput = document.getElementById("user-guess");
    const guessBtn = document.getElementById("guess-btn");
    const recordBlock = document.getElementById("record-block");
    const resetBtn = document.getElementById("reset-game-btn");

    function initGame() {
        secretHiddenNumber = Math.floor(Math.random() * 100) + 1;
        attempts = 0;
        gameOver = false;
        statusEl.innerText = "Игра началась! Введи число:";
        statusEl.style.color = "#ffb703";
        attemptsEl.innerText = attempts;
        guessInput.value = "";
        guessInput.disabled = false;
        guessBtn.disabled = false;
        recordBlock.style.display = "none";
    }

    guessBtn.addEventListener("click", () => {
        if (gameOver) return;
        
        const userValue = parseInt(guessInput.value);
        if (isNaN(userValue) || userValue < 1 || userValue > 100) {
            alert("Введи корректное число от 1 до 100!");
            return;
        }

        attempts++;
        attemptsEl.innerText = attempts;

        if (userValue === secretHiddenNumber) {
            statusEl.innerText = `🎯 УГАДАЛ! Это было число ${secretHiddenNumber}!`;
            statusEl.style.color = "#28a745";
            gameOver = true;
            guessInput.disabled = true;
            guessBtn.disabled = true;
            recordBlock.style.display = "block";
        } else if (userValue < secretHiddenNumber) {
            statusEl.innerText = "🔻 Мало! Бери выше.";
            statusEl.style.color = "#ff3333";
        } else {
            statusEl.innerText = "🔺 Много! Бери ниже.";
            statusEl.style.color = "#ff3333";
        }
        guessInput.value = "";
        guessInput.focus();
    });

    resetBtn.addEventListener("click", initGame);

    // Новая чистая отправка через единую систему
    document.getElementById("send-score-btn").addEventListener("click", () => {
        const name = document.getElementById("player-name").value.trim() || "Анонимный Мыслитель";
        sendPigGameScore("guess", name, attempts, () => {
            alert("Результат записан в таблицу!");
            recordBlock.style.display = "none";
        });
    });
});
</script>

<script src="/games/js/score_sender.js" defer></script>