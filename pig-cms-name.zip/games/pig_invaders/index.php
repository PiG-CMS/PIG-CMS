<?php
/* 
 * 🐷 PIG-CMS — ЗАЩИТА КВАДРАНТА (ЦЕЛЬНЫЙ ИНДЕКС)
 * © 2026 pig-cms.name & PiTi
 */

// Путь к JSON-файлу рекордов для этой игры
$leaderboard_file = 'data/games_posts/invaders_top.json';

// Логика AJAX-сохранения рекорда
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_score') {
    $name = htmlspecialchars(trim($_POST['name'] ?? 'Анонимный Защитник'));
    $score = intval($_POST['score'] ?? 0);
    
    // Проверяем авторизацию в CMS (админ, автор или гость)
    $status = (isset($_SESSION['auth']) && $_SESSION['auth'] === true) ? (($_SESSION['username'] === 'admin') ? 'admin' : 'author') : 'guest';
    if ($status !== 'guest') $name = $_SESSION['username'];
    
    // Загружаем текущую таблицу лидеров из JSON
    $leaderboard = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
    $leaderboard[] = ['name' => $name, 'score' => $score, 'date' => date('d.m.Y H:i'), 'status' => $status];
    
    // Сортировка: больше сбитых багов = выше место
    usort($leaderboard, function($a, $b) { return $b['score'] <=> $a['score']; });
    $leaderboard = array_slice($leaderboard, 0, 10);
    
    if (!is_dir('data/games_posts/')) mkdir('data/games_posts/', 0777, true);
    file_put_contents($leaderboard_file, json_encode($leaderboard, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    header('Content-Type: application/json');
    echo json_encode($leaderboard);
    exit;
}

// Загрузка рекордов для первичного вывода на страницу
$top_players = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
?>

<div id="pig-game-area-invaders" style="max-width: 450px; margin: 20px auto; text-align: center; font-family: monospace; background: #111; padding: 15px; border-radius: 8px; border: 2px solid #00ff66; position: relative;">
    <button id="fs-btn-invaders" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; background: #00ff66; color: #000; border: none; cursor: pointer; font-weight: bold; font-size: 0.8rem; z-index: 10;">📺 НА ВЕСЬ ЭКРАН</button>
    
    <a href="games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h2 style="color: #00ff66; margin-top: 10px;">💥 ЗАЩИТА КВАДРАНТА PIG-NET 💥</h2>
    <p style="color: #aaa; font-size: 0.8rem;">Стрелки/AD — движение. Пробел — огонь. На мобилках используй пульт ниже:</p>
    
    <!-- Игровой холст -->
    <canvas id="invadersCanvas" width="360" height="400" style="background: #111; display: block; margin: 0 auto; border: 2px solid #333; max-width: 100%;"></canvas>
    <div id="score-board-invaders" style="color: #fff; margin-top: 10px; font-size: 1.2rem;">Уничтожено багов: <span id="current-score-invaders">0</span></div>
    
    <!-- Единственный наэкранный пульт управления кораблём -->
    <div style="display: flex; gap: 10px; justify-content: center; margin: 15px 0;">
        <button id="btn-inv-l" style="padding: 15px 30px; background: #333; color: #00ff66; border: 1px solid #00ff66; border-radius: 4px; font-weight: bold; font-size: 1.2rem; cursor: pointer;">◀ ВЛЕВО</button>
        <button id="btn-inv-r" style="padding: 15px 30px; background: #333; color: #00ff66; border: 1px solid #00ff66; border-radius: 4px; font-weight: bold; font-size: 1.2rem; cursor: pointer;">ВПРАВО ▶</button>
    </div>
    
    <!-- Кнопка старта -->
    <button id="start-invaders-btn" style="padding: 10px 20px; background: #00ff66; color: #000; border: none; font-weight: bold; cursor: pointer; border-radius: 4px; width: 100%;">ЗАПУСТИТЬ ОБОРОНУ</button>

    <!-- Блок сохранения рекорда в JSON -->
    <div id="record-block-invaders" style="display: none; margin-top: 20px; background: #222222; padding: 20px; border-radius: 10px; border: 1px solid #00ff66;">
        <h3 style="margin-top: 0; color: #00ff66; text-transform: uppercase; font-size: 1rem;">🎉 Сохранить лог обороны в JSON</h3>
        <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
            <input type="text" id="player-name-invaders" placeholder="Никнейм" value="<?= $_SESSION['username'] ?? '' ?>" style="padding: 10px; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px; flex-grow: 1; font-family: monospace;">
            <button id="send-score-btn-invaders" style="padding: 10px 20px; background: #00ff66; color: #000; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">ОТПРАВИТЬ</button>
        </div>
    </div>

    <!-- Таблица ТОП-10 из JSON базы данных -->
    <div style="margin-top: 20px; text-align: left; background: #222222; padding: 15px; border-radius: 10px; border: 1px solid #333;">
        <h3 style="text-align: center; margin-top: 0; color: #00ff66;">🏆 КИБЕР-ГВАРДИЯ ХАБА</h3>
        <ol id="leaderboard-list" style="padding-left: 20px; color: #ffffff; margin: 0;">
            <?php if (empty($top_players)): ?>
                <li style="color: #aaaaaa;">Таблица чиста от багов. Стань первым!</li>
            <?php else: ?>
                <?php foreach ($top_players as $player): ?>
                    <li style="margin-bottom: 8px;"><strong><?= htmlspecialchars($player['name']) ?></strong> — <?= $player['score'] ?> багов</li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ol>
    </div>
</div>

<!-- ПОДКЛЮЧЕНИЕ СКРИПТОВ (Без дублирования внутренней логики) -->
<script src="games/js/score_sender.js" defer></script>
<script src="games/js/pig_invaders.js" defer></script>
