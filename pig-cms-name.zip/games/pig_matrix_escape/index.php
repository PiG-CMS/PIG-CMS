<?php
/* 
 * 🕹️ PIG-ARCADE — Текстовый Квест (index.php)
 * [Pi_Ti & Google Hub] ★ © 2026 PIG-CMS.NAME
 */
require_once '../../core/config.php';
$page_title = "Побег из Матрицы Алгоритмов — PIG-ARCADE";
include_once '../../core/header.php';
?>
<div class="single-post-wrap" style="max-width: 600px; margin: 40px auto; font-family: monospace; text-align: center;">
    <h2 style="color: #ffb703;">📟 ПОБЕГ ИЗ МАТРИЦЫ АЛГОРИТМОВ</h2>
    <div id="quest-screen" style="background: #111; padding: 20px; border-radius: 6px; border: 1px solid #333; min-height: 150px; text-align: left; color: #33ff33; margin-bottom: 20px; line-height: 1.5;">
        Загрузка суверенного протокола... Вы очнулись в запертой серверной. Корпоративные алгоритмы пытаются поглотить ваше творчество. На столе мигает старый терминал, а в углу жужжит вентиляцией серверная стойка. Что делаете?
    </div>
    <div id="quest-actions" style="display: flex; flex-direction: column; gap: 10px;">
        <button class="react-btn" onclick="nextStep(1)" style="width:100%; text-align:left;">1. Подойти к терминалу и ввести команду обхода блокировки.</button>
        <button class="react-btn" onclick="nextStep(2)" style="width:100%; text-align:left;">2. Попробовать выдернуть силовой кабель из серверной стойки.</button>
    </div>
</div>

<script>
const story = {
    1: { text: "Вы вводите `sudo rm -rf matrix`. Экран бешено мигает! Алгоритмы отступают, открывая секретную дверь в стене. Вы на свободе! Свободный интернет спасен. Вы победили!", ends: true },
    2: { text: "Вы дергаете кабель, но срабатывает резервный генератор! Вас бьет легким током, а системы защиты блокируют все выходы намертво. Вы поглощены алгоритмами корпораций. Игра окончена.", ends: true }
};
function nextStep(id) {
    const node = story[id];
    document.getElementById("quest-screen").innerText = node.text;
    const actions = document.getElementById("quest-actions");
    if (node.ends) {
        actions.innerHTML = '<a href="../../games.php" class="page-btn" style="text-align:center; width:100%;">🔄 Вернуться в игровой хаб</a>';
    }
}
</script>
<?php include_once '../../core/footer.php'; ?>
