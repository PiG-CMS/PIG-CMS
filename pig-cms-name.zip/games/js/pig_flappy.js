/* 
 * 🐷 PIG-CMS — LOGIC FOR FLAPPY PIG
 * © 2026 pig-cms.name & PiTi
 */
document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("flappyCanvas");
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const fsBtn = document.getElementById("fs-btn-f");
    const gameArea = document.getElementById("pig-game-area-f");
    const startBtn = document.getElementById("start-flappy-btn");
    const scoreEl = document.getElementById("current-score-f");
    const recordBlock = document.getElementById("record-block-f");
    const sendScoreBtn = document.getElementById("send-score-btn-f");
    const playerNameInput = document.getElementById("player-name-f");

    let gameInterval;
    let score = 0;
    let gameOver = true;

    // Параметры свинки
    let pig = { x: 50, y: 200, radius: 16, gravity: 0.25, velocity: 0, jump: 4.6 };
    let pipes = [];
    const pipeWidth = 50;
    const pipeGap = 110; // Ширина пролета между трубами
    let frameCount = 0;

    // Фуллскрин режим
    fsBtn.addEventListener("click", () => {
        if (!document.fullscreenElement) {
            gameArea.requestFullscreen().then(() => {
                fsBtn.innerText = "✖ СВЕРНУТЬ";
                canvas.style.height = "70vh";
            }).catch(() => alert("Фуллскрин не поддерживается"));
        } else {
            document.exitFullscreen();
        }
    });

    document.addEventListener("fullscreenchange", () => {
        if (!document.fullscreenElement) {
            fsBtn.innerText = "📺 НА ВЕСЬ ЭКРАН";
            canvas.style.height = "auto";
        }
    });

    // Управление прыжком
    const makeJump = () => {
        if (!gameOver) pig.velocity = -pig.jump;
    };

    window.addEventListener("keydown", (e) => {
        if (e.code === "Space" || e.code === "ArrowUp") {
            e.preventDefault();
            makeJump();
        }
    });
    canvas.addEventListener("touchstart", (e) => {
        e.preventDefault();
        makeJump();
    });

    function update() {
        if (gameOver) return;

        pig.velocity += pig.gravity;
        pig.y += pig.velocity;

        // Падение на землю или вылет за потолок
        if (pig.y + pig.radius > canvas.height || pig.y - pig.radius < 0) {
            endGame();
        }

        // Спавн труб каждые 110 кадров
        frameCount++;
        if (frameCount % 110 === 0) {
            let minHeight = 40;
            let maxHeight = canvas.height - pipeGap - minHeight;
            let topHeight = Math.floor(Math.random() * (maxHeight - minHeight + 1)) + minHeight;
            pipes.push({ x: canvas.width, top: topHeight, passed: false });
        }

        pipes.forEach((pipe, index) => {
            pipe.x -= 2; // Скорость движения труб

            // Если труба улетела за экран
            if (pipe.x + pipeWidth < 0) {
                pipes.splice(index, 1);
            }

            // Начисление очков
            if (!pipe.passed && pipe.x + pipeWidth / 2 < pig.x) {
                pipe.passed = true;
                score++;
                scoreEl.innerText = score;
            }

            // Проверка столкновений (Хрюндик круглый, трубы прямоугольные)
            let closestX = Math.max(pipe.x, Math.min(pig.x, pipe.x + pipeWidth));
            
            // Верхняя труба
            let closestYTop = Math.min(pig.y, pipe.top);
            let distanceXTop = pig.x - closestX;
            let distanceYTop = pig.y - closestYTop;
            let collisionTop = (distanceXTop * distanceXTop + distanceYTop * distanceYTop) < (pig.radius * pig.radius);

            // Нижняя труба
            let closestYBottom = Math.max(pig.y, pipe.top + pipeGap);
            let distanceXBottom = pig.x - closestX;
            let distanceYBottom = pig.y - closestYBottom;
            let collisionBottom = (distanceXBottom * distanceXBottom + distanceYBottom * distanceYBottom) < (pig.radius * pig.radius);

            if (collisionTop || collisionBottom) {
                endGame();
            }
        });
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 1. Рисуем трубы (Стены матрицы)
        ctx.fillStyle = "#dc3545";
        pipes.forEach(pipe => {
            // Верхняя
            ctx.fillRect(pipe.x, 0, pipeWidth, pipe.top);
            // Нижняя
            ctx.fillRect(pipe.x, pipe.top + pipeGap, pipeWidth, canvas.height - (pipe.top + pipeGap));
        });

        // 2. Рисуем летающего Хрюндика
        ctx.fillStyle = "#ffb703";
        ctx.beginPath();
        ctx.arc(pig.x, pig.y, pig.radius, 0, Math.PI * 2);
        ctx.fill();

        // Глазик и пятачок для ламповости
        ctx.fillStyle = "#000";
        ctx.fillRect(pig.x + 6, pig.y - 6, 3, 3); // Глаз
        ctx.fillStyle = "#e6a100";
        ctx.fillRect(pig.x + 10, pig.y - 1, 5, 4); // Пятачок
    }

    function gameLoop() {
        update();
        draw();
    }

    function endGame() {
        gameOver = true;
        clearInterval(gameInterval);
        recordBlock.style.display = "block";
        startBtn.style.display = "inline-block";
        startBtn.innerText = "ИГРАТЬ СНОВА";
    }

    startBtn.addEventListener("click", () => {
        recordBlock.style.display = "none";
        startBtn.style.display = "none";
        score = 0;
        scoreEl.innerText = score;
        pig.y = 200;
        pig.velocity = 0;
        pipes = [];
        frameCount = 0;
        gameOver = false;
        clearInterval(gameInterval);
        gameInterval = setInterval(gameLoop, 1000 / 60);
    });

    sendScoreBtn.addEventListener("click", () => {
        const name = playerNameInput.value.trim() || "Анонимный Мыслитель";
        if (typeof sendPigGameScore === "function") {
            sendPigGameScore("flappy", name, score, () => {
                alert("Твой полет задокументирован в JSON!");
                recordBlock.style.display = "none";
            });
        } else {
            alert("Ошибка транспорта рекордов!");
        }
    });
});
