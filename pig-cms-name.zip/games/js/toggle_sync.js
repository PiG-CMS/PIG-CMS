/* 
 * 🐷 PIG-CMS — Универсальный синхронизатор игр-переключателей
 * © 2026 pig-cms.name & Доктор Шрам
 */

document.addEventListener("DOMContentLoaded", () => {
    const app = document.getElementById("toggle-game-app");
    if (!app) return;

    const gameSlug = app.dataset.game; // берем 'lamp' из data-game="lamp"
    const toggleBtn = document.getElementById("toggle-btn");
    const roomBox = document.getElementById("lamp-room");
    const stateIcon = document.getElementById("state-icon");
    const stateTitle = document.getElementById("state-title");
    const clicksCount = document.getElementById("clicks-count");
    const lastUser = document.getElementById("last-user");
    const lastTime = document.getElementById("last-time");

    let isBusy = false;

    // Функция отрисовки нового состояния на экране
    function renderState(data) {
        if (data.is_on) {
            roomBox.style.background = "#332b00";
            roomBox.style.borderColor = "#ffb703";
            roomBox.style.boxShadow = "0 0 35px rgba(255, 183, 3, 0.3)";
            stateIcon.style.filter = "drop-shadow(0 0 25px #ffb703)";
            stateTitle.innerText = "СВЕТ ГОРИТ!";
            stateTitle.style.color = "#ffb703";
            toggleBtn.innerText = "ВЫКЛЮЧИТЬ СВЕТ";
            toggleBtn.style.background = "#dc3545";
        } else {
            roomBox.style.background = "#16161e";
            roomBox.style.borderColor = "#444";
            roomBox.style.boxShadow = "none";
            stateIcon.style.filter = "grayscale(100%) opacity(0.3)";
            stateTitle.innerText = "В КОМНАТЕ ТЕМНО";
            stateTitle.style.color = "#666";
            toggleBtn.innerText = "ВКЛЮЧИТЬ СВЕТ";
            toggleBtn.style.background = "#28a745";
        }

        clicksCount.innerText = data.clicks;
        lastUser.innerText = data.last_user;
        lastTime.innerText = data.last_time;
    }

    // Отправка запроса на сервер
    function sendAction(actionType) {
        if (isBusy) return;
        isBusy = true;

        const formData = new FormData();
        formData.append("action", actionType);

        fetch(`games.php?play=${gameSlug}`, {
            method: "POST",
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            renderState(data);
        })
        .catch(err => console.error("Ошибка связи с сервером:", err))
        .finally(() => {
            isBusy = false;
        });
    }

    // Клик по кнопке
    toggleBtn.addEventListener("click", () => {
        sendAction("toggle_state");
    });

    // Живой радар: каждые 4 секунды проверяем, не щелкнул ли кто-то другой
    setInterval(() => {
        sendAction("check_state");
    }, 4000);
});
