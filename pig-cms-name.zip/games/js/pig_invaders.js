/* 
 * 🐷 PIG-CMS — ЛОГИКА ИГРЫ ЗАЩИТА КВАДРАНТА (ЦЕЛЬНЫЙ ИСПРАВЛЕННЫЙ)
 * © 2026 pig-cms.name & PiTi
 */
document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("invadersCanvas"); 
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const startBtn = document.getElementById("start-invaders-btn");
    const scoreEl = document.getElementById("current-score-invaders");
    const recordBlock = document.getElementById("record-block-invaders");
    const sendScoreBtn = document.getElementById("send-score-btn-invaders");
    const playerNameInput = document.getElementById("player-name-invaders");
    
    // Кнопка фуллскрина и сам игровой контейнер
    const fsBtn = document.getElementById("fs-btn-invaders");
    const gameArea = document.getElementById("pig-game-area-invaders");

    // Игровые переменные
    let gameInterval, score = 0, gameOver = true;
    let player = { x: 160, y: 360, w: 40, h: 20, speed: 8 }; 
    let bullets = []; 
    let enemies = []; 
    let keys = {}; 

    // ХЕНДЛЕР КНОПКИ «НА ВЕСЬ ЭКРАН» (ЧИНУ ТУТ!)
    fsBtn.addEventListener("click", () => {
        if (!document.fullscreenElement) {
            gameArea.requestFullscreen().then(() => {
                fsBtn.innerText = "✖ СВЕРНУТЬ";
                canvas.style.height = "70vh"; // Растягиваем холст в фуллскрине
            }).catch(() => alert("Фуллскрин не поддерживается вашим браузером"));
        } else {
            document.exitFullscreen();
        }
    });

    // Отслеживание выхода из фуллскрина кнопкой ESC
    document.addEventListener("fullscreenchange", () => {
        if (!document.fullscreenElement) {
            fsBtn.innerText = "📺 НА ВЕСЬ ЭКРАН";
            canvas.style.height = "auto"; // Возвращаем исходный размер
        }
    });

    // Управление клавиатурой
    window.addEventListener("keydown", (e) => { 
        const key = e.key.toLowerCase();
        if (key === "arrowleft" || key === "a" || key === "ф") keys["left"] = true; 
        if (key === "arrowright" || key === "d" || key === "в") keys["right"] = true; 
        if (e.code === "Space" && !gameOver) { e.preventDefault(); fire(); } 
    });

    window.addEventListener("keyup", (e) => { 
        const key = e.key.toLowerCase();
        if (key === "arrowleft" || key === "a" || key === "ф") keys["left"] = false; 
        if (key === "arrowright" || key === "d" || key === "в") keys["right"] = false; 
    });
    
    // Наэкранные кнопки пульта
    document.getElementById("btn-inv-l").addEventListener("click", () => { 
        if (!gameOver) { player.x = Math.max(0, player.x - 30); fire(); } 
    });
    document.getElementById("btn-inv-r").addEventListener("click", () => { 
        if (!gameOver) { player.x = Math.min(canvas.width - player.w, player.x + 30); fire(); } 
    });
    
    canvas.addEventListener("touchstart", () => { if (!gameOver) fire(); });

    function fire() { 
        if (bullets.length < 5) { 
            bullets.push({ x: player.x + 18, y: player.y, w: 4, h: 10 }); 
        } 
    }

    function spawn() { 
        if (Math.random() < 0.02 && enemies.length < 5) { 
            enemies.push({ x: Math.random() * (canvas.width - 30), y: -30, w: 30, h: 20, speed: 2 }); 
        } 
    }

    function loop() {
        if (gameOver) return;

        if (keys["left"] && player.x > 0) player.x -= player.speed; 
        if (keys["right"] && player.x < canvas.width - player.w) player.x += player.speed;

        bullets.forEach((b, i) => { 
            b.y -= 6; 
            if (b.y < 0) bullets.splice(i, 1); 
        });

        enemies.forEach((e, ei) => {
            e.y += e.speed; 
            if (e.y > canvas.height) endGame(); 

            bullets.forEach((b, bi) => { 
                if (b.x < e.x + e.w && b.x + b.w > e.x && b.y < e.y + e.h && b.y + b.h > e.y) { 
                    enemies.splice(ei, 1); 
                    bullets.splice(bi, 1); 
                    score++; 
                    scoreEl.innerText = score; 
                } 
            });

            if (player.x < e.x + e.w && player.x + player.w > e.x && player.y < e.y + e.h && player.y + player.h > e.y) endGame();
        });

        spawn(); 

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#00ff66"; ctx.fillRect(player.x, player.y, player.w, player.h);
        ctx.fillStyle = "#ffb703"; bullets.forEach(b => ctx.fillRect(b.x, b.y, b.w, b.h));
        ctx.fillStyle = "#dc3545"; enemies.forEach(e => ctx.fillRect(e.x, e.y, e.w, e.h));
    }

    function endGame() { 
        gameOver = true; 
        clearInterval(gameInterval); 
        recordBlock.style.display = "block"; 
        startBtn.style.display = "inline-block"; 
        startBtn.innerText = "ПЕРЕЗАПУСТИТЬ ОБОРОНУ"; 
    }

    startBtn.addEventListener("click", () => { 
        recordBlock.style.display = "none"; startBtn.style.display = "none"; 
        score = 0; scoreEl.innerText = score; gameOver = false; 
        player.x = 160; bullets = []; enemies = []; 
        clearInterval(gameInterval); 
        gameInterval = setInterval(loop, 1000 / 60); 
    });

    sendScoreBtn.addEventListener("click", () => { 
        sendPigGameScore("invaders", playerNameInput.value.trim(), score, () => recordBlock.style.display = "none"); 
    });
});
