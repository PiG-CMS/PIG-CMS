/* 
 * 🐷 PIG-CMS — ЛОГИКА ИГРЫ ЖИЗА-РЕЙСИНГ (ОПТИМИЗИРОВАННАЯ СБОРКА)
 * © 2026 pig-cms.name & PiTi
 */
document.addEventListener("DOMContentLoaded", () => {
    const canvas = document.getElementById("rulesCanvas"); 
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const startBtn = document.getElementById("start-rules-btn");
    const scoreEl = document.getElementById("current-score-rules");
    const recordBlock = document.getElementById("record-block-rules");
    const brakeBtn = document.getElementById("btn-brake");
    const btnLeft = document.getElementById("btn-rules-l");
    const btnRight = document.getElementById("btn-rules-r");
    
    const fsBtn = document.getElementById("fs-btn-rules");
    const gameArea = document.getElementById("pig-game-area-rules");

    let animId = null;
    let score = 0;
    let gameOver = true;
    let roadOffset = 0;
    let lineTimer = 0;
    let roadLineType = "solid"; 
    let isBraking = false; 
    
    let player = { x: 175, targetX: 175, y: 320, w: 40, h: 60 };
    let obstacles = [];

    // Фуллскрин
    if (fsBtn && gameArea) {
        fsBtn.addEventListener("click", () => {
            if (!document.fullscreenElement) {
                gameArea.requestFullscreen().then(() => { 
                    fsBtn.innerText = "✖ СВЕРНУТЬ"; 
                    canvas.style.height = "60vh";
                }).catch(() => alert("Браузер заблокировал переход в фуллскрин"));
            } else { 
                document.exitFullscreen(); 
            }
        });
        
        document.addEventListener("fullscreenchange", () => {
            if (!document.fullscreenElement) { 
                fsBtn.innerText = "📺 НА ВЕСЬ ЭКРАН"; 
                canvas.style.height = "auto";
            }
        });
    }

    const moveLeft = (e) => { 
        if (e) e.preventDefault();
        if (!gameOver) player.targetX = 75; 
    };
    const moveRight = (e) => { 
        if (e) e.preventDefault();
        if (!gameOver) player.targetX = 175; 
    };

    // Мгновенный отклик на планшете (touchstart) + поддержка мыши
    if (btnLeft) {
        btnLeft.addEventListener("touchstart", moveLeft, { passive: false });
        btnLeft.addEventListener("mousedown", moveLeft);
    }
    if (btnRight) {
        btnRight.addEventListener("touchstart", moveRight, { passive: false });
        btnRight.addEventListener("mousedown", moveRight);
    }

    window.addEventListener("keydown", (e) => {
        if (gameOver) return;
        const key = e.key.toLowerCase();
        if (key === "arrowleft" || key === "a" || key === "ф") moveLeft();
        if (key === "arrowright" || key === "d" || key === "в") moveRight();
        if (key === "arrowdown" || key === "s" || key === "ы") isBraking = true;
    });
    window.addEventListener("keyup", (e) => { 
        const key = e.key.toLowerCase();
        if (key === "arrowdown" || key === "s" || key === "ы") isBraking = false; 
    });
    
    if (brakeBtn) {
        brakeBtn.addEventListener("mousedown", () => isBraking = true); 
        brakeBtn.addEventListener("mouseup", () => isBraking = false);
        brakeBtn.addEventListener("mouseleave", () => isBraking = false);
        brakeBtn.addEventListener("touchstart", (e) => { e.preventDefault(); isBraking = true; }, { passive: false }); 
        brakeBtn.addEventListener("touchend", () => isBraking = false);
        brakeBtn.addEventListener("touchcancel", () => isBraking = false);
    }

    function spawnObstacle() {
        if (Math.random() < 0.025 && obstacles.length < 3) {
            // Защита, чтобы машины не спавнились друг на друге
            const tooClose = obstacles.some(o => o.y < 110);
            if (tooClose) return;

            let onLeftLane = Math.random() < 0.4;
            let type = (roadLineType === "solid" && onLeftLane && Math.random() < 0.5) ? "gai" : (Math.random() < 0.3 ? "truck" : "car");
            
            obstacles.push({ 
                x: type === "gai" ? 5 : (onLeftLane ? 75 : 175), 
                y: -80, 
                w: type === "gai" ? 30 : 38, 
                h: type === "truck" ? 75 : 55, 
                type: type, 
                speed: type === "gai" ? 0 : (type === "truck" ? 1.2 : 2.5) 
            });
        }
    }

    function loop() {
        if (gameOver) return;
        
        let speed = isBraking ? 1.5 : 4.5;
        score += isBraking ? 1 : 3; 
        if (scoreEl) scoreEl.innerText = Math.floor(score / 20);
        
        player.x += (player.targetX - player.x) * 0.25;
        
        lineTimer++; 
        if (lineTimer > 180) { 
            roadLineType = roadLineType === "solid" ? "dashed" : "solid"; 
            lineTimer = 0; 
        }
        roadOffset += speed;
        if (roadOffset > 40) roadOffset -= 40;

        // Идем с конца массива, чтобы удаление через splice не ломало цикл
        for (let i = obstacles.length - 1; i >= 0; i--) {
            let obs = obstacles[i];
            obs.y += obs.speed + (isBraking ? 0.5 : 2.5);
            
            if (obs.y > canvas.height + 20) {
                obstacles.splice(i, 1);
                continue;
            }
            
            // Проверка ГАИ на сплошной
            if (player.x < 130 && roadLineType === "solid" && obs.type === "gai" && Math.abs(player.y - obs.y) < 110) {
                endGame("Экипаж ДПС оформил протокол за сплошную!");
                return;
            }
            // Проверка столкновения
            if (player.x < obs.x + obs.w && player.x + player.w > obs.x && player.y < obs.y + obs.h && player.y + player.h > obs.y) {
                endGame("Тотальное ДТП в потоке!");
                return;
            }
        }
        
        spawnObstacle(); 
        
        // 1. Фон асфальта и обочин
        ctx.fillStyle = "#444"; 
        ctx.fillRect(0, 0, canvas.width, canvas.height); 
        ctx.fillStyle = "#777"; 
        ctx.fillRect(0, 0, 40, canvas.height); 
        ctx.fillRect(canvas.width - 40, 0, 40, canvas.height); 
        
              // 2. Разметка (исправленный setLineDash с параметрами штриха!)
        ctx.strokeStyle = "#fff"; 
        ctx.lineWidth = 4;
        ctx.beginPath();
        if (roadLineType === "solid") {
            ctx.setLineDash([]);
        } else {
            ctx.setLineDash([20, 20]);
            ctx.lineDashOffset = -roadOffset;
        }
        ctx.moveTo(canvas.width / 2, 0); 
        ctx.lineTo(canvas.width / 2, canvas.height); 
        ctx.stroke();
        ctx.setLineDash([]); // Сброс пунктира
      

        // 3. Машина игрока
        ctx.fillStyle = isBraking ? "#ff3333" : "#ffb703"; 
        ctx.fillRect(player.x, player.y, player.w, player.h);
        ctx.fillStyle = "#111"; 
        ctx.fillRect(player.x + 5, player.y + 12, player.w - 10, 15);

        // 4. Препятствия и ГАИ
        for (let i = 0; i < obstacles.length; i++) {
            let obs = obstacles[i];
            if (obs.type === "gai") {
                ctx.fillStyle = "#0056b3"; 
                ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
                ctx.fillStyle = (Math.floor(score / 6) % 2 === 0) ? "#ff3333" : "#00d4ff"; 
                ctx.fillRect(obs.x + 6, obs.y + 15, obs.w - 12, 8);
            } else {
                ctx.fillStyle = obs.type === "truck" ? "#28a745" : "#dc3545"; 
                ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
                // Лобовое стекло у трафика
                ctx.fillStyle = "#222";
                ctx.fillRect(obs.x + 5, obs.y + obs.h - 20, obs.w - 10, 10);
            }
        }

        animId = requestAnimationFrame(loop);
    }

    function endGame(reason) { 
        gameOver = true; 
        if (animId) cancelAnimationFrame(animId);
        alert("🚨 " + reason); 
        if (recordBlock) recordBlock.style.display = "block"; 
        if (startBtn) { 
            startBtn.style.display = "inline-block"; 
            startBtn.innerText = "ПОГНАЛИ СНОВА"; 
        }
    }

    if (startBtn) {
        startBtn.addEventListener("click", () => { 
            if (recordBlock) recordBlock.style.display = "none"; 
            startBtn.style.display = "none"; 
            score = 0; 
            if (scoreEl) scoreEl.innerText = "0"; 
            gameOver = false; 
            player.x = 175; 
            player.targetX = 175; 
            obstacles = []; 
            roadLineType = "solid"; 
            lineTimer = 0;
            isBraking = false;
            if (animId) cancelAnimationFrame(animId);
            animId = requestAnimationFrame(loop);
        });
    }

    const sendBtn = document.getElementById("send-score-btn-rules");
    const nameInput = document.getElementById("player-name-rules");
    if (sendBtn && nameInput) {
        sendBtn.addEventListener("click", () => { 
            if (typeof sendPigGameScore === "function") {
                sendPigGameScore("racer_rules", nameInput.value.trim(), Math.floor(score / 20), () => {
                    if (recordBlock) recordBlock.style.display = "none";
                }); 
            }
        });
    }
});
