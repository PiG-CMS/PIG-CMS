/* 
 * 🐷 PIG-CMS — Универсальный движок гонок (Вертикаль & Горизонталь)
 * © 2026 pig-cms.name & PiTi
 */
document.addEventListener("DOMContentLoaded", () => {
    // 1. ОПРЕДЕЛЯЕМ ТИП ИГРЫ ПО НАЛИЧИЮ ХОЛСТА НА СТРАНИЦЕ
    const canvasV = document.getElementById("raceCanvas");
    const canvasH = document.getElementById("raceCanvasH");
    
    if (!canvasV && !canvasH) return; // Если гонки не запущены, выходим

    const isHorizontal = !!canvasH;
    const canvas = isHorizontal ? canvasH : canvasV;
    const ctx = canvas.getContext("2d");
    
    // Подтягиваем нужные ID элементов в зависимости от плоскости
    const suffix = isHorizontal ? "-h" : "";
    const fsBtn = document.getElementById("fs-btn" + suffix);
    const gameArea = document.getElementById(isHorizontal ? "pig-game-area-h" : "pig-game-area");
    const startBtn = document.getElementById("start-race-btn" + suffix);
    const scoreEl = document.getElementById(isHorizontal ? "current-score-h" : "current-score");
    const recordBlock = document.getElementById(isHorizontal ? "record-block-h" : "record-block");
    const sendScoreBtn = document.getElementById("send-score-btn" + suffix);
    const playerNameInput = document.getElementById(isHorizontal ? "player-name-h" : "player-name");

    let gameInterval;
    let score = 0;
    let gameOver = true;
    let obstacles = [];
    let keys = {};

    // Начальные настройки игрока под каждый режим
    let player = isHorizontal 
        ? { x: 40, y: 130, w: 60, h: 40, speed: 6 } // Горизонталь (двигается вверх/вниз)
        : { x: 160, y: 380, w: 40, h: 60, speed: 6 }; // Вертикаль (двигается влево/вправо)

    // 2. УПРАВЛЕНИЕ И ФУЛЛСКРИН (Общие для двух игр)
    fsBtn.addEventListener("click", () => {
        if (!document.fullscreenElement) {
            gameArea.requestFullscreen().then(() => {
                fsBtn.innerText = "✖ СВЕРНУТЬ";
                canvas.style.height = isHorizontal ? "65vh" : "70vh";
            }).catch(() => alert("Фуллскрин не поддерживается"));
        } else {
            document.exitFullscreen();
        }
    });

    document.addEventListener("fullscreenchange", () => {
        if (!document.fullscreenElement) {
            fsBtn.innerText = "📺 НА ВЕСЬ ЭКРАН";
            canvas.style.height = "auto";
        }
    });

    window.addEventListener("keydown", (e) => keys[e.code] = true);
    window.addEventListener("keyup", (e) => keys[e.code] = false);
    
    // Мобильные тапы
    canvas.addEventListener("touchstart", (e) => {
        if (gameOver) return;
        const rect = canvas.getBoundingClientRect();
        if (isHorizontal) {
            const touchY = e.touches[0].clientY - rect.top;
            player.y = touchY < rect.height / 2 ? Math.max(0, player.y - 40) : Math.min(canvas.height - player.h, player.y + 40);
        } else {
            const touchX = e.touches[0].clientX - rect.left;
            player.x = touchX < rect.width / 2 ? Math.max(0, player.x - 40) : Math.min(canvas.width - player.w, player.x + 40);
        }
    });

    // 3. ЛОГИКА ОБНОВЛЕНИЯ КООРДИНАТ
    function update() {
        if (gameOver) return;

        if (isHorizontal) {
            if ((keys["ArrowUp"] || keys["KeyW"]) && player.y > 0) player.y -= player.speed;
            if ((keys["ArrowDown"] || keys["KeyS"]) && player.y < canvas.height - player.h) player.y += player.speed;

            if (Math.random() < 0.02 && obstacles.length < 4) {
                obstacles.push({ x: canvas.width + 40, y: Math.random() * (canvas.height - 40), w: 40, h: 45, speed: 4 + score * 0.1 });
            }
        } else {
            if ((keys["ArrowLeft"] || keys["KeyA"]) && player.x > 0) player.x -= player.speed;
            if ((keys["ArrowRight"] || keys["KeyD"]) && player.x < canvas.width - player.w) player.x += player.speed;

            if (Math.random() < 0.02 && obstacles.length < 4) {
                obstacles.push({ x: Math.random() * (canvas.width - 40), y: -40, w: 45, h: 40, speed: 4 + score * 0.1 });
            }
        }

        obstacles.forEach((obs, index) => {
            if (isHorizontal) {
                obs.x -= obs.speed;
                if (obs.x < -obs.w) { obstacles.splice(index, 1); score++; scoreEl.innerText = score; }
            } else {
                obs.y += obs.speed;
                if (obs.y > canvas.height) { obstacles.splice(index, 1); score++; scoreEl.innerText = score; }
            }

            // Коллизия
            if (player.x < obs.x + obs.w && player.x + player.w > obs.x && player.y < obs.y + obs.h && player.y + player.h > obs.y) {
                gameOver = true;
                clearInterval(gameInterval);
                recordBlock.style.display = "block";
                startBtn.style.display = "inline-block";
                startBtn.innerText = "ИГРАТЬ СНОВА";
            }
        });
    }

    // 4. ОТРИСОВКА КАДРА
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        ctx.strokeStyle = "#444";
        ctx.lineWidth = 4;
        ctx.beginPath();
        if (isHorizontal) {
            ctx.moveTo(0, canvas.height / 2); ctx.lineTo(canvas.width, canvas.height / 2);
        } else {
            ctx.moveTo(canvas.width / 2, 0); ctx.lineTo(canvas.width / 2, canvas.height);
        }
        ctx.stroke();

        // Машина игрока
        ctx.fillStyle = "#ffb703";
        ctx.fillRect(player.x, player.y, player.w, player.h);
        ctx.fillStyle = "#222";
        if (isHorizontal) {
            ctx.fillRect(player.x + 35, player.y + 5, 15, player.h - 10);
        } else {
            ctx.fillRect(player.x + 5, player.y + 15, player.w - 10, 25);
        }

        // Препятствия
        ctx.fillStyle = "#dc3545";
        obstacles.forEach(obs => { ctx.fillRect(obs.x, obs.y, obs.w, obs.h); });
    }

    function gameLoop() { update(); draw(); }

    // Кнопка старта
    startBtn.addEventListener("click", () => {
        recordBlock.style.display = "none";
        startBtn.style.display = "none";
        score = 0;
        scoreEl.innerText = score;
        gameOver = false;
        
        if (isHorizontal) { player.y = 130; } else { player.x = 160; }
        obstacles = [];
        clearInterval(gameInterval);
        gameInterval = setInterval(gameLoop, 1000 / 60);
    });

    // Отправка рекорда
    sendScoreBtn.addEventListener("click", () => {
        const name = playerNameInput.value.trim() || "Анонимный Мыслитель";
        const gameId = isHorizontal ? "racer_h" : "racer_v";
        if (typeof sendPigGameScore === "function") {
            sendPigGameScore(gameId, name, score, () => {
                alert("Твой рекорд сохранен в JSON!");
                recordBlock.style.display = "none";
            });
        } else {
            alert("Ошибка связи: проверь score_sender.js!");
        }
    });
});
