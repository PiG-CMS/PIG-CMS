/* 
 * 🐷 PIG-CMS — ЛОГИКА ИГРЫ PIG-SNAKE (ЦЕЛЬНЫЙ СКРИПТ)
 * © 2026 pig-cms.name & PiTi
 */
document.addEventListener("DOMContentLoaded", () => {
    // Получаем холст игры
    const canvas = document.getElementById("snakeCanvas"); 
    if (!canvas) return; // Если холста нет на странице, отключаем скрипт

    const ctx = canvas.getContext("2d");
    
    // Элементы интерфейса (кнопки, очки, рекорды)
    const startBtn = document.getElementById("start-snake-btn"); 
    const scoreEl = document.getElementById("current-score-s"); 
    const recordBlock = document.getElementById("record-block-s"); 
    const sendScoreBtn = document.getElementById("send-score-btn-s"); 
    const playerNameInput = document.getElementById("player-name-s"); 

    // Системные переменные игры
    let gameInterval; // Таймер игрового цикла
    let score = 0; // Текущие очки игрока
    let gameOver = true; // Флаг состояния игры

    // Настройки сетки (размер клетки 20х20 пикселей)
    const gridSize = 20; 
    const tileCount = canvas.width / gridSize; // Количество клеток по горизонтали/вертикали

    // Координаты змейки и еды
    let snake = []; 
    let food = { x: 5, y: 5 }; 
    let dx = gridSize; // Смещение змейки по X (по умолчанию ползет вправо)
    let dy = 0; // Смещение змейки по Y

    // ФУНКЦИЯ ИЗМЕНЕНИЯ НАПРАВЛЕНИЯ (с защитой от разворота в самого себя)
    const setDir = (x, y) => { 
        if (gameOver) return;
        // Змейка не может поползти влево, если уже ползет вправо, и наоборот
        if ((x !== 0 && dx === 0) || (y !== 0 && dy === 0)) { 
            dx = x; 
            dy = y; 
        } 
    };

    // Слушатель клавиатуры (Стрелочки и WASD)
    window.addEventListener("keydown", (e) => {
        if (gameOver) return;
        const key = e.key.toLowerCase();
        if (key === "arrowup" || key === "w" || key === "ц") setDir(0, -gridSize);   // ВВЕРХ
        if (key === "arrowdown" || key === "s" || key === "ы") setDir(0, gridSize);   // ВНИЗ
        if (key === "arrowleft" || key === "a" || key === "ф") setDir(-gridSize, 0);  // ВЛЕВО
        if (key === "arrowright" || key === "d" || key === "в") setDir(gridSize, 0);  // ВПРАВО
    });

    // ПРИВЯЗКА НАЭКРАННЫХ КНОПОК ПУЛЬТА (Для смартфонов)
    document.getElementById("btn-u").addEventListener("click", () => setDir(0, -gridSize)); // Кнопка ВВЕРХ
    document.getElementById("btn-d").addEventListener("click", () => setDir(0, gridSize));  // Кнопка ВНИЗ
    document.getElementById("btn-l").addEventListener("click", () => setDir(-gridSize, 0)); // Кнопка ВЛЕВО
    document.getElementById("btn-r").addEventListener("click", () => setDir(gridSize, 0));  // Кнопка ВПРАВО

    // Генератор случайного спавна яблок свободы
    function spawnFood() { 
        food.x = Math.floor(Math.random() * tileCount) * gridSize; 
        food.y = Math.floor(Math.random() * tileCount) * gridSize; 
    }

    // ГЛАВНЫЙ СИСТЕМНЫЙ КРУГ ИГРЫ
    function main() {
        // Проверка выхода за границы экрана холста
        if (snake[0].x < 0 || snake[0].x >= canvas.width || snake[0].y < 0 || snake[0].y >= canvas.height) {
            return endGame();
        }

        // Проверка врезания в собственный хвост
        for (let i = 1; i < snake.length; i++) { 
            if (snake[i].x === snake[0].x && snake[i].y === snake[0].y) return endGame(); 
        }

        // Рассчитываем новые координаты головы
        const head = { x: snake[0].x + dx, y: snake[0].y + dy }; 
        snake.unshift(head); // Добавляем новую голову вперед массива

        // Если съели еду
        if (snake[0].x === food.x && snake[0].y === food.y) { 
            score++; 
            scoreEl.innerText = score; // Обновляем счет на экране
            spawnFood(); // Спавним новое яблоко
        } else { 
            snake.pop(); // Если еду не ели, убираем хвост (сохраняем длину)
        }

        // ОТРИСОВКА КАДРА НА ЭКРАНЕ
        ctx.clearRect(0, 0, canvas.width, canvas.height); // Очищаем экран
        
        // Рисуем Красное Яблоко
        ctx.fillStyle = "#dc3545"; 
        ctx.fillRect(food.x, food.y, gridSize - 2, gridSize - 2);

        // Рисуем Змейку Хрюндика
        snake.forEach((part, index) => { 
            // Голова золотая, тело зеленое
            ctx.fillStyle = (index === 0) ? "#ffb703" : "#00ff66"; 
            ctx.fillRect(part.x, part.y, gridSize - 2, gridSize - 2); 
        });
    }

    // Окончание игры (Проигрыш)
    function endGame() { 
        gameOver = true; 
        clearInterval(gameInterval); // Останавливаем таймер
        recordBlock.style.display = "block"; // Показываем форму рекорда
        startBtn.style.display = "inline-block"; // Показываем кнопку Старт заново
    }

    // Запуск игры по кнопке СТАРТ
    startBtn.addEventListener("click", () => { 
        recordBlock.style.display = "none"; 
        startBtn.style.display = "none"; 
        score = 0; 
        scoreEl.innerText = score; 
        gameOver = false; 
        dx = gridSize; 
        dy = 0; 
        
        // Начальная позиция змейки (две клетки)
        snake = [{ x: 160, y: 200 }, { x: 140, y: 200 }]; 
        spawnFood(); 
        
        clearInterval(gameInterval); 
        // 140 миллисекунд — комфортная скорость, змейка больше не летит как бешеная
        gameInterval = setInterval(main, 140); 
    });

    // Отправка рекорда в JSON базу данных через score_sender.js
    document.getElementById("send-score-btn-s").addEventListener("click", () => { 
        if (typeof sendPigGameScore === "function") { 
            sendPigGameScore("snake", playerNameInput.value.trim(), score, () => recordBlock.style.display = "none"); 
        } 
    });
});
