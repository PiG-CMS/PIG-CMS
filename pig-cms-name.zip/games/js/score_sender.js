/* 
 * 🐷 PIG-CMS — Универсальный AJAX-транспорт для рекордов PIG-GAMES
 * © 2026 pig-cms.name & Доктор Шрам
 */

function sendPigGameScore(gamePlayId, playerName, playerScore, callbackSuccess) {
    const formData = new FormData();
    formData.append("action", "save_score");
    formData.append("name", playerName);
    formData.append("score", playerScore);

    fetch("/games.php?play=" + gamePlayId, {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Автоматически обновляем UI таблицы на странице, если контейнер существует
        renderPigLeaderboard(gamePlayId, data);
        if (callbackSuccess) callbackSuccess(data);
    })
    .catch(err => alert("Ошибка связи с сервером PIG-GAMES"));
}

// Универсальный рендеринг таблицы ТОП-10 для вёрстки обеих игр
function renderPigLeaderboard(gamePlayId, data) {
    const list = document.getElementById("leaderboard-list");
    if (!list) return;

    list.innerHTML = "";
    if (!data || data.length === 0) {
        list.innerHTML = '<li style="color: #aaaaaa;">Таблица пуста. Стань первым!</li>';
        return;
    }

    data.forEach(player => {
        let badge = '';
        const status = player.status || 'guest';
        
        // Маппинг цветных бейджей под стилистику PIG-CMS
        if (status === 'admin') {
            badge = '<span style="background: #dc3545; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight: bold;">АДМИН</span>';
        } else if (status === 'author') {
            badge = '<span style="background: #28a745; color: #fff; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px; font-weight: bold;">АВТОР</span>';
        } else {
            badge = '<span style="background: #555; color: #ccc; padding: 1px 5px; border-radius: 3px; font-size: 0.7rem; margin-right: 5px;">ГОСТЬ</span>';
        }

        // Форматирование счета (очки для кликера, попытки для угадайки)
        const scoreSuffix = (gamePlayId === 'clicker') ? `${player.score} 🪙` : `${player.score} поп.`;

        list.innerHTML += `<li style="margin-bottom: 8px; color: #ffffff;">
            ${badge} <strong style="color: #ffb703;">${escapeHtml(player.name)}</strong> — 
            <span style="color: #fff; font-weight: bold;">${scoreSuffix}</span> 
            <span style="color: #888888; font-size: 0.8rem;">(${player.date})</span>
        </li>`;
    });
}

function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}
