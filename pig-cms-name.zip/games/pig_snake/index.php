<?php
/* 
 * 🐷 PIG-CMS — PIG-SNAKE (БЭКЕНД И ИНТЕРФЕЙС)
 */
$leaderboard_file = 'data/games_posts/snake_top.json';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_score') {
    $name = htmlspecialchars(trim($_POST['name'] ?? 'Анонимный Змеелов'));
    $score = intval($_POST['score'] ?? 0);
    $status = (isset($_SESSION['auth']) && $_SESSION['auth'] === true) ? (($_SESSION['username'] === 'admin') ? 'admin' : 'author') : 'guest';
    if ($status !== 'guest') $name = $_SESSION['username'];
    $leaderboard = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
    $leaderboard[] = ['name' => $name, 'score' => $score, 'date' => date('d.m.Y H:i'), 'status' => $status];
    usort($leaderboard, function($a, $b) { return $b['score'] <=> $a['score']; });
    $leaderboard = array_slice($leaderboard, 0, 10);
    if (!is_dir('data/games_posts/')) mkdir('data/games_posts/', 0777, true);
    file_put_contents($leaderboard_file, json_encode($leaderboard, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    header('Content-Type: application/json'); echo json_encode($leaderboard); exit;
}
$top_players = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
?>
<div id="pig-game-area-s" style="max-width: 450px; margin: 20px auto; text-align: center; font-family: monospace; background: #111; padding: 15px; border-radius: 8px; border: 2px solid #ffb703; position: relative;">
    <button id="fs-btn-s" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; background: #ffb703; border: none; cursor: pointer; font-weight: bold; font-size: 0.8rem; z-index: 10;">📺 НА ВЕСЬ ЭКРАН</button>
    <a href="games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h2 style="color: #ffb703; margin-top: 10px;">🍏 PIG-SNAKE 🍏</h2>
    <canvas id="snakeCanvas" width="360" height="360" style="background: #222; display: block; margin: 0 auto; border: 2px solid #444; max-width: 100%;"></canvas>
    <div id="score-board-s" style="color: #fff; margin-top: 10px; font-size: 1.2rem;">Длина: <span id="current-score-s">0</span></div>
    
    <!-- Мобильный пульт управления для Змейки -->
    <div style="margin: 15px auto; width: 180px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 5px;">
        <div></div><button id="btn-u" style="padding: 15px; background: #444; color: #fff; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">▲</button><div></div>
        <button id="btn-l" style="padding: 15px; background: #444; color: #fff; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">◀</button>
        <button id="btn-d" style="padding: 15px; background: #444; color: #fff; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">▼</button>
        <button id="btn-r" style="padding: 15px; background: #444; color: #fff; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">▶</button>
    </div>
    
    <button id="start-snake-btn" style="padding: 10px 20px; background: #00ff66; border: none; font-weight: bold; cursor: pointer; border-radius: 4px; font-family: monospace; width: 100%;">СТАРТ</button>
    <div id="record-block-s" style="display: none; margin-top: 20px; background: #222222; padding: 20px; border-radius: 10px; border: 1px solid #ffb703;">
        <h3 style="margin-top: 0; color: #ffb703; text-transform: uppercase; font-size: 1rem;">🎉 Рекорд сохранен!</h3>
        <div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px;">
            <input type="text" id="player-name-s" value="<?= $_SESSION['username'] ?? '' ?>" style="padding: 10px; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px; flex-grow: 1; font-family: monospace;">
            <button id="send-score-btn-s" style="padding: 10px 20px; background: #ffb703; color: #111; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">ОТПРАВИТЬ</button>
        </div>
    </div>
    <div style="margin-top: 20px; text-align: left; background: #222222; padding: 15px; border-radius: 10px; border: 1px solid #444;">
        <ol id="leaderboard-list" style="padding-left: 20px; color: #ffffff; margin: 0;"></ol>
    </div>
</div>
<script src="games/js/score_sender.js" defer></script>
<script src="games/js/pig_snake.js" defer></script>
