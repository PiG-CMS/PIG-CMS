<?php
/* 
 * 🐷 PIG-CMS — ЖИЗА-РЕЙСИНГ (ИНДЕКС С КНОПКОЙ ФУЛЛСКРИНА)
 * © 2026 pig-cms.name & PiTi
 */
$leaderboard_file = 'data/games_posts/racer_rules_top.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_score') {
    $name = htmlspecialchars(trim($_POST['name'] ?? 'Анонимный Лихач'));
    $score = intval($_POST['score'] ?? 0);
    $status = (isset($_SESSION['auth']) && $_SESSION['auth'] === true) ? (($_SESSION['username'] === 'admin') ? 'admin' : 'author') : 'guest';
    if ($status !== 'guest') $name = $_SESSION['username'];
    
    $leaderboard = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
    $leaderboard[] = ['name' => $name, 'score' => $score, 'date' => date('d.m.Y H:i'), 'status' => $status];
    usort($leaderboard, function($a, $b) { return $b['score'] <=> $a['score']; });
    $leaderboard = array_slice($leaderboard, 0, 10);
    
    if (!is_dir('data/games_posts/')) mkdir('data/games_posts/', 0777, true);
    file_put_contents($leaderboard_file, json_encode($leaderboard, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    header('Content-Type: application/json'); echo json_encode($leaderboard); exit;
}
$top_players = file_exists($leaderboard_file) ? json_decode(file_get_contents($leaderboard_file), true) ?: [] : [];
?>

<div id="pig-game-area-rules" style="max-width: 450px; margin: 20px auto; text-align: center; font-family: monospace; background: #111; padding: 15px; border-radius: 8px; border: 2px solid #ff3333; position: relative;">
    <!-- ВОТ ОНА: Кнопка фуллскрина в верхнем правом углу -->
    <button id="fs-btn-rules" style="position: absolute; top: 10px; right: 10px; padding: 5px 10px; background: #ff3333; color: #fff; border: none; cursor: pointer; font-weight: bold; font-size: 0.8rem; z-index: 10;">📺 НА ВЕСЬ ЭКРАН</button>
    
    <a href="games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h2 style="color: #ff3333; margin-top: 10px;">🚔 СВИНЬЯ ЗА РУЛЕМ: ЖИЗА 🚔</h2>
    
    <canvas id="rulesCanvas" width="300" height="400" style="background: #333; display: block; margin: 0 auto; border: 2px solid #555; max-width: 100%;"></canvas>
    
    <div id="score-board-rules" style="color: #fff; margin-top: 10px; font-size: 1.2rem;">Удачный обгон: <span id="current-score-rules">0</span> км</div>
    
    <div style="display: flex; gap: 10px; justify-content: center; margin: 15px 0;">
        <button id="btn-rules-l" style="padding: 15px 20px; background: #222; color: #ff3333; border: 1px solid #ff3333; border-radius: 4px; font-weight: bold; font-size: 1.1rem; cursor: pointer; flex: 1;">◀ ВСТРЕЧКА</button>
        <button id="btn-rules-r" style="padding: 15px 20px; background: #222; color: #28a745; border: 1px solid #28a745; border-radius: 4px; font-weight: bold; font-size: 1.1rem; cursor: pointer; flex: 1;">ПОПУТНАЯ ▶</button>
    </div>

    <button id="btn-brake" style="margin-bottom: 15px; padding: 18px; background: #dc3545; color: #fff; font-weight: bold; font-size: 1.2rem; border: none; border-radius: 6px; cursor: pointer; width: 100%; user-select: none;">🛑 СБАВИТЬ ГАЗ (ТОРМОЗ)</button>
    <button id="start-rules-btn" style="padding: 15px; background: #28a745; color: #fff; border: none; font-weight: bold; cursor: pointer; border-radius: 4px; width: 100%;">ЖАТЬ НАГЛО В ПОЛ</button>

    <div id="record-block-rules" style="display: none; margin-top: 20px; background: #222222; padding: 20px; border-radius: 10px; border: 1px solid #ff3333;">
        <h3 style="color:#ff3333; margin-top:0;">🚨 Попался взводу ДПС!</h3>
        <div style="display: flex; gap: 10px; justify-content: center;">
            <input type="text" id="player-name-rules" value="<?= $_SESSION['username'] ?? '' ?>" style="padding: 10px; background: #111; color: #fff; border: 1px solid #444; border-radius: 4px; flex-grow: 1;">
            <button id="send-score-btn-rules" style="padding: 10px 20px; background: #ff3333; color: #fff; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">В ТОП</button>
        </div>
    </div>
    
    <div style="margin-top: 20px; text-align: left; background: #222222; padding: 15px; border-radius: 10px; border: 1px solid #444;">
        <ol id="leaderboard-list" style="padding-left: 20px; color: #ffffff; margin: 0;"></ol>
    </div>
</div>
<script src="games/js/score_sender.js" defer></script>
<script src="games/js/pig_racer_rules.js?v=2" defer></script>

