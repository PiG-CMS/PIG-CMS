<?php
/* 
 * 🐷 PIG-CMS — ГЛОБАЛЬНАЯ ЛАМПОЧКА
 * © 2026 pig-cms.name & Доктор Шрам
 */

$state_file = 'data/games_posts/lamp_state.json';

$default_state = [
    'is_on'     => false,
    'clicks'    => 0,
    'last_user' => 'Никто еще не щелкал',
    'last_time' => date('d.m.Y H:i:s')
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'toggle_state') {
        $who = 'Анонимный Прохожий';
        if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
            $who = '@' . $_SESSION['username'];
        }
        
        $state = pig_json_update($state_file, function($current) use ($who) {
            $current['is_on']     = empty($current['is_on']);
            $current['clicks']    = (int)($current['clicks'] ?? 0) + 1;
            $current['last_user'] = $who;
            $current['last_time'] = date('d.m.Y H:i:s');
            return $current;
        }, $default_state);
    } else {
        $saved = file_exists($state_file) ? json_decode(file_get_contents($state_file), true) : null;
        $state = is_array($saved) ? array_merge($default_state, $saved) : $default_state;
    }
    
    echo json_encode($state, JSON_UNESCAPED_UNICODE);
    exit;
}

$saved = file_exists($state_file) ? json_decode(file_get_contents($state_file), true) : null;
$state = is_array($saved) ? array_merge($default_state, $saved) : $default_state;
?>

<script src="games/js/toggle_sync.js" defer></script>

<div id="toggle-game-app" data-game="lamp" style="max-width: 600px; margin: 30px auto; text-align: center; font-family: monospace; padding: 0 15px;">
    <a href="games.php" style="color: #666; text-decoration: none; display: inline-block; margin-bottom: 15px;">← Назад к списку игр</a>
    <h1>💡 ГЛОБАЛЬНАЯ ЛАМПОЧКА 💡</h1>
    <p style="color: #aaa;">Одна лампочка на всю Вселенную PIG-CMS. Включишь ты — загорится у всех. Выключит кто-то другой — погаснет и у тебя.</p>
    
    <div id="lamp-room" style="background: <?= $state['is_on'] ? '#332b00' : '#16161e' ?>; border: 2px dashed <?= $state['is_on'] ? '#ffb703' : '#444' ?>; padding: 40px 20px; border-radius: 12px; transition: all 0.3s ease; box-shadow: <?= $state['is_on'] ? '0 0 35px rgba(255, 183, 3, 0.3)' : 'none' ?>;">
        
        <!-- Визуал лампочки -->
        <div id="state-icon" style="font-size: 90px; line-height: 1; margin-bottom: 20px; filter: <?= $state['is_on'] ? 'drop-shadow(0 0 25px #ffb703)' : 'grayscale(100%) opacity(0.3)' ?>; transition: all 0.3s ease;">
            💡
        </div>
        
        <h2 id="state-title" style="color: <?= $state['is_on'] ? '#ffb703' : '#666' ?>; margin: 10px 0;">
            <?= $state['is_on'] ? 'СВЕТ ГОРИТ!' : 'В КОМНАТЕ ТЕМНО' ?>
        </h2>
        
        <button id="toggle-btn" style="margin-top: 20px; padding: 15px 35px; font-size: 1.1rem; font-weight: bold; font-family: monospace; border: none; border-radius: 6px; cursor: pointer; background: <?= $state['is_on'] ? '#dc3545' : '#28a745' ?>; color: #fff; text-transform: uppercase;">
            <?= $state['is_on'] ? 'ВЫКЛЮЧИТЬ СВЕТ' : 'ВКЛЮЧИТЬ СВЕТ' ?>
        </button>
    </div>

    <!-- Инфо-блок кто последний щелкал -->
    <div style="margin-top: 20px; background: #222; padding: 15px; border-radius: 10px; border: 1px solid #444; color: #ccc; font-size: 0.9rem;">
        <p style="margin: 5px 0;">Всего щелчков выключателем: <strong id="clicks-count" style="color: #ffb703;"><?= $state['clicks'] ?></strong></p>
        <p style="margin: 5px 0;">Последний рубильник дергал: <strong id="last-user" style="color: #00ff66;"><?= htmlspecialchars($state['last_user']) ?></strong></p>
        <p style="margin: 5px 0; font-size: 0.8rem; color: #777;">Время последнего изменения: <span id="last-time"><?= $state['last_time'] ?></span></p>
    </div>
</div>
